// Quản lý nhóm trong chương trình, lịch sử đăng ký chương trình và lịch sử phân công mentor (chỉ HR chỉnh sửa).
// Dùng lại programRequest/escapeHtml/setText từ programs.js, core.js, work-scope.js.
let pgProgramId = null,
  pgGroupId = null,
  pgGroups = [],
  pgMembers = [],
  pgProgramInterns = [];

function pgJson(body, method = "POST") {
  return {
    method,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  };
}
function pgFormat(value) {
  return value ? String(value).slice(0, 16).replace("T", " ") : "—";
}
const PG_EVENT = {
  ADDED: "Thêm vào chương trình",
  REMOVED: "Gỡ khỏi chương trình",
  GROUP_JOINED: "Vào nhóm",
  GROUP_LEFT: "Rời nhóm",
};
function pgEventLabel(e) {
  const base = PG_EVENT[e.eventType] || e.eventType;
  return e.detail ? `${base}: ${e.detail}` : base;
}
// Mô tả ngắn các lịch họp bị ảnh hưởng từ kết quả xem trước (dry run).
function pgImpactText(r) {
  if (!r.updatedMeetings) return "";
  const names = (r.meetings || [])
    .slice(0, 5)
    .map((m) => `• ${m.title}${m.status === "CANCELLED" ? " (sẽ bị hủy vì hết người)" : ""} – ${m.startAt}`)
    .join("\n");
  return `Thay đổi này sẽ cập nhật ${r.updatedMeetings} lịch họp chưa diễn ra (gửi lời mời/thông báo hủy cho người liên quan):\n${names}${r.meetings.length > 5 ? "\n…" : ""}\n\n`;
}
function pgGroup() {
  return pgGroups.find((g) => Number(g.id) === Number(pgGroupId)) || null;
}

async function programGroupOpen(programId) {
  pgProgramId = Number(programId);
  pgGroupId = null;
  const program = programItems.find((p) => Number(p.id) === pgProgramId);
  setText("pgTitle", `Nhóm – ${program ? program.name : ""}`);
  setText("pgError", "");
  setText("pgResult", "");
  document.getElementById("pgNewName").value = "";
  document.getElementById("pgMembersPanel").style.display = "none";
  document.getElementById("programGroupModal").style.display = "flex";
  await programGroupReload();
}
function programGroupClose() {
  document.getElementById("programGroupModal").style.display = "none";
}

async function programGroupReload() {
  try {
    const [groups, ungrouped, history] = await Promise.all([
      programRequest(`/programs/${pgProgramId}/groups`),
      programRequest(`/programs/${pgProgramId}/ungrouped-interns`),
      programRequest(`/programs/${pgProgramId}/enrollment-history`),
    ]);
    pgGroups = groups;
    document.getElementById("pgRows").innerHTML = groups.length
      ? groups
          .map(
            (g) => `<tr>
              <td>${escapeHtml(g.name)}${g.description ? `<span class="fr-sub">${escapeHtml(g.description)}</span>` : ""}</td>
              <td>${Number(g.memberCount)}</td>
              <td><div class="program-actions">
                <button class="btn btn-sm btn-soft" onclick="programGroupMembers(${Number(g.id)})">Thành viên</button>
                <button class="btn btn-sm btn-soft-gray" onclick="programGroupRename(${Number(g.id)})">Đổi tên</button>
                <button class="btn btn-sm btn-soft-danger" onclick="programGroupDelete(${Number(g.id)})">Xóa</button>
              </div></td></tr>`,
          )
          .join("")
      : '<tr><td colspan="3">Chương trình chưa có nhóm. Nhập tên ở trên để tạo nhóm đầu tiên.</td></tr>';
    setText(
      "pgUngrouped",
      ungrouped.length
        ? `${ungrouped.length} thực tập sinh chưa có nhóm chính: ${ungrouped
            .slice(0, 8)
            .map((i) => i.fullName)
            .join(", ")}${ungrouped.length > 8 ? "…" : ""}`
        : "Mọi thực tập sinh trong chương trình đều đã có nhóm chính.",
    );
    document.getElementById("pgHistory").innerHTML = history.length
      ? history
          .map(
            (e) =>
              `<tr><td>${escapeHtml(pgFormat(e.createdAt))}</td><td>${escapeHtml(e.fullName)}</td><td>${escapeHtml(pgEventLabel(e))}</td></tr>`,
          )
          .join("")
      : '<tr><td colspan="3">Chưa có sự kiện.</td></tr>';
    if (pgGroupId && !pgGroup()) {
      pgGroupId = null;
      document.getElementById("pgMembersPanel").style.display = "none";
    }
  } catch (err) {
    setText("pgError", err.message);
  }
}

async function programGroupCreate() {
  const input = document.getElementById("pgNewName");
  setText("pgError", "");
  setText("pgResult", "");
  try {
    await programRequest(
      `/programs/${pgProgramId}/groups`,
      pgJson({ name: input.value }),
    );
    input.value = "";
    await programGroupReload();
  } catch (err) {
    setText("pgError", err.message);
  }
}
async function programGroupRename(id) {
  const group = pgGroups.find((g) => Number(g.id) === Number(id));
  const name = prompt("Tên nhóm mới:", group ? group.name : "");
  if (name === null) return;
  setText("pgError", "");
  try {
    await programRequest(`/groups/${Number(id)}`, pgJson({ name }, "PUT"));
    await programGroupReload();
  } catch (err) {
    setText("pgError", err.message);
  }
}
async function programGroupDelete(id) {
  const group = pgGroups.find((g) => Number(g.id) === Number(id));
  if (
    !confirm(
      `Xóa nhóm "${group ? group.name : ""}"? Các lịch họp theo nhóm này sẽ chuyển sang lịch chọn tay (giữ nguyên người tham dự).`,
    )
  )
    return;
  setText("pgError", "");
  try {
    await programRequest(`/groups/${Number(id)}`, { method: "DELETE" });
    if (Number(pgGroupId) === Number(id)) pgGroupId = null;
    document.getElementById("pgMembersPanel").style.display = "none";
    await programGroupReload();
  } catch (err) {
    setText("pgError", err.message);
  }
}

async function programGroupMembers(id) {
  pgGroupId = Number(id);
  setText("pgError", "");
  setText("pgResult", "");
  document.getElementById("pgMembersPanel").style.display = "";
  const group = pgGroup();
  setText("pgMembersTitle", `Thành viên nhóm: ${group ? group.name : ""}`);
  document.getElementById("pgPrimary").checked = true;
  document.getElementById("pgMove").checked = false;
  await programGroupLoadMentors();
  await programGroupMembersReload();
}
async function programGroupLoadMentors() {
  const select = document.getElementById("pgMentor");
  try {
    const res = await fetch(`${API_BASE}/mentors`, { headers: authHeaders() }).then(
      (r) => r.json().catch(() => []),
    );
    const mentors = Array.isArray(res) ? res : [];
    select.innerHTML =
      '<option value="">-- Gỡ mentor của cả nhóm --</option>' +
      mentors
        .map(
          (m) =>
            `<option value="${Number(m.id)}">${escapeHtml(m.fullName)}${m.department ? ` (${escapeHtml(m.department)})` : ""}</option>`,
        )
        .join("");
    select.value = "";
  } catch (err) {
    setText("pgError", err.message);
  }
}
async function programGroupAssignMentor() {
  const value = document.getElementById("pgMentor").value;
  setText("pgError", "");
  setText("pgResult", "");
  if (!pgMembers.length)
    return setText("pgError", "Nhóm chưa có thành viên để phân công mentor.");
  try {
    const send = (confirmed) =>
      programRequest(
        `/groups/${pgGroupId}/mentor`,
        pgJson(
          {
            mentor_id: value ? Number(value) : null,
            ...(confirmed ? { confirm_warnings: true } : {}),
          },
          "PUT",
        ),
      );
    let result;
    try {
      result = await send(false);
    } catch (err) {
      if (err.code !== "NEEDS_CONFIRMATION" || !confirmAssignmentWarnings(err.warnings))
        throw err;
      result = await send(true);
    }
    setText(
      "pgResult",
      result.updated
        ? `Đã cập nhật mentor cho ${result.updated} thực tập sinh${result.unchanged ? ` (${result.unchanged} người không đổi)` : ""}.`
        : "Không có thay đổi nào.",
    );
  } catch (err) {
    setText("pgError", err.message);
  }
}
async function programGroupApplyRoadmap(kind) {
  const source = Number(document.getElementById("pgRoadmapSource").value);
  setText("pgError", "");
  setText("pgResult", "");
  if (!source) return setText("pgError", "Chọn thực tập sinh có lộ trình để sao chép.");
  const where = kind === "group" ? "cả nhóm" : "cả chương trình";
  if (!confirm(`Sao chép lộ trình của người này cho ${where}? Người đã có lộ trình sẽ được giữ nguyên.`))
    return;
  try {
    const r = await programRequest(
      kind === "group" ? `/groups/${pgGroupId}/roadmap` : `/programs/${pgProgramId}/roadmap`,
      pgJson({ source_intern_id: source }),
    );
    setText(
      "pgResult",
      `Đã áp dụng lộ trình (${r.phases} giai đoạn) cho ${r.applied} người; ${r.skipped} người đã có lộ trình được giữ nguyên.`,
    );
  } catch (err) {
    setText("pgError", err.message);
  }
}
async function programGroupMembersReload() {
  try {
    [pgMembers, pgProgramInterns] = await Promise.all([
      programRequest(`/groups/${pgGroupId}/members`),
      programRequest(`/programs/${pgProgramId}/interns`),
    ]);
  } catch (err) {
    pgMembers = [];
    pgProgramInterns = [];
    setText("pgError", err.message);
  }
  document.getElementById("pgMemberRows").innerHTML = pgMembers.length
    ? pgMembers
        .map(
          (m) => `<tr><td>${escapeHtml(m.fullName)}<span class="fr-sub">${escapeHtml(m.studentCode || "")}</span></td>
            <td>${m.isPrimary ? "Nhóm chính" : "Nhóm phụ"}</td>
            <td>${escapeHtml(pgFormat(m.joinedAt))}</td>
            <td><button class="btn btn-sm btn-danger" onclick="programGroupLeave(${Number(m.internId)})">Rời nhóm</button></td></tr>`,
        )
        .join("")
    : '<tr><td colspan="4">Nhóm chưa có thành viên.</td></tr>';
  document.getElementById("pgRoadmapSource").innerHTML =
    '<option value="">-- Chọn thực tập sinh nguồn --</option>' +
    pgProgramInterns
      .map((i) => `<option value="${Number(i.id)}">${escapeHtml(i.fullName)}</option>`)
      .join("");
  const inGroup = new Set(pgMembers.map((m) => Number(m.internId)));
  const candidates = pgProgramInterns.filter((i) => !inGroup.has(Number(i.id)));
  document.getElementById("pgCandidates").innerHTML = candidates.length
    ? candidates
        .map(
          (i) =>
            `<label class="meeting-checks-item" style="display:block"><input type="checkbox" class="pg-check" value="${Number(i.id)}" /> ${escapeHtml(i.fullName)}<span class="fr-sub">${escapeHtml(i.studentCode || "")}</span></label>`,
        )
        .join("")
    : "Mọi thực tập sinh của chương trình đã ở trong nhóm này.";
}
async function programGroupAddMembers() {
  const ids = [...document.querySelectorAll("#pgCandidates .pg-check:checked")].map(
    (c) => Number(c.value),
  );
  setText("pgError", "");
  setText("pgResult", "");
  if (!ids.length) return setText("pgError", "Chọn ít nhất một thực tập sinh.");
  try {
    const payload = {
      intern_ids: ids,
      is_primary: document.getElementById("pgPrimary").checked,
      move: document.getElementById("pgMove").checked,
    };
    const preview = await programRequest(
      `/groups/${pgGroupId}/members`,
      pgJson({ ...payload, dry_run: true }),
    );
    const impact = pgImpactText(preview);
    if (impact && !confirm(`${impact}Tiếp tục thêm ${ids.length} người vào nhóm?`))
      return;
    const r = await programRequest(`/groups/${pgGroupId}/members`, pgJson(payload));
    setText(
      "pgResult",
      `Đã thêm ${r.added} người${r.moved ? ` (chuyển ${r.moved} người từ nhóm chính cũ)` : ""}.${r.updatedMeetings ? ` Đã cập nhật ${r.updatedMeetings} lịch họp chưa diễn ra${r.cancelledMeetings ? `, hủy ${r.cancelledMeetings} lịch hết người` : ""}.` : ""}`,
    );
    await Promise.all([programGroupReload(), programGroupMembersReload()]);
  } catch (err) {
    setText("pgError", err.message);
  }
}
async function programGroupLeave(internId) {
  setText("pgError", "");
  setText("pgResult", "");
  try {
    const preview = await programRequest(
      `/groups/${pgGroupId}/members/${Number(internId)}?dry_run=1`,
      { method: "DELETE" },
    );
    if (
      !confirm(
        `${pgImpactText(preview)}Cho thực tập sinh này rời nhóm? Lịch sử vẫn được giữ lại.`,
      )
    )
      return;
    const r = await programRequest(
      `/groups/${pgGroupId}/members/${Number(internId)}`,
      { method: "DELETE" },
    );
    if (r && r.updatedMeetings)
      setText("pgResult", `Đã cập nhật ${r.updatedMeetings} lịch họp chưa diễn ra.`);
    await Promise.all([programGroupReload(), programGroupMembersReload()]);
  } catch (err) {
    setText("pgError", err.message);
  }
}

// ---------- Lịch sử phân công mentor ----------
async function internMentorHistoryOpen(internId, name) {
  setText("mhTitle", `Lịch sử mentor – ${name || ""}`);
  setText("mhError", "");
  document.getElementById("mhRows").innerHTML =
    '<tr><td colspan="4">Đang tải...</td></tr>';
  document.getElementById("mentorHistoryModal").style.display = "flex";
  try {
    const { items } = await programRequest(
      `/interns/${Number(internId)}/mentor-history`,
    );
    document.getElementById("mhRows").innerHTML = items.length
      ? items
          .map(
            (a) => `<tr><td>${escapeHtml(a.mentorName || "Mentor đã bị xóa")}${a.isCurrent ? ' <span class="program-status">Hiện tại</span>' : ""}</td>
              <td>${escapeHtml(pgFormat(a.effectiveFrom))}</td>
              <td>${escapeHtml(a.effectiveTo ? pgFormat(a.effectiveTo) : "Đang hiệu lực")}</td>
              <td>${escapeHtml(a.programName || "—")}</td></tr>`,
          )
          .join("")
      : '<tr><td colspan="4">Chưa có phân công mentor nào.</td></tr>';
  } catch (err) {
    setText("mhError", err.message);
    document.getElementById("mhRows").innerHTML = "";
  }
}
function internMentorHistoryClose() {
  document.getElementById("mentorHistoryModal").style.display = "none";
}

// ---------- Nhóm của tôi (Intern / Mentor) ----------
async function loadMyGroups() {
  const box = document.getElementById("myGroupsPage");
  box.innerHTML = '<p class="fr-hint">Đang tải...</p>';
  try {
    const groups = await programRequest("/me/groups");
    if (!groups.length) {
      box.innerHTML =
        '<p class="fr-hint">Hiện chưa có nhóm nào. Bộ phận nhân sự sẽ xếp nhóm cho thực tập sinh trong chương trình.</p>';
      return;
    }
    const isIntern = typeof currentRole !== "undefined" && currentRole === "Intern";
    box.innerHTML = groups
      .map((g) =>
        isIntern
          ? `<div class="card" style="margin-bottom:12px;padding:14px 18px">
              <h4 style="margin:0 0 4px">${escapeHtml(g.name)} <small>${g.isPrimary ? "(nhóm chính)" : "(nhóm phụ)"}</small></h4>
              <div class="fr-hint">Chương trình: ${escapeHtml(g.programName)} · Vào nhóm: ${escapeHtml(pgFormat(g.joinedAt))}</div>
              ${g.description ? `<p style="margin:6px 0 0">${escapeHtml(g.description)}</p>` : ""}
            </div>`
          : `<div class="card" style="margin-bottom:12px;padding:14px 18px">
              <h4 style="margin:0 0 4px">${escapeHtml(g.name)}</h4>
              <div class="fr-hint">Chương trình: ${escapeHtml(g.programName)}</div>
              <p style="margin:6px 0 0">Thực tập sinh của bạn trong nhóm: ${g.interns
                .map((i) => escapeHtml(i.fullName))
                .join(", ")}</p>
            </div>`,
      )
      .join("");
  } catch (err) {
    box.innerHTML = `<p class="text-danger">${escapeHtml(err.message)}</p>`;
  }
}
