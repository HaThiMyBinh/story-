// Chạy trên DB đã sao lưu trước khi nâng cấp: thêm nhóm trong chương trình, lịch sử phân công mentor,
// lịch sử đăng ký chương trình, người tham gia lịch và phạm vi GROUP. Chỉ thêm mới; mentor hiện có được
// ghi thành phân công đang mở (không suy diễn lịch sử cũ).
const mysql = require("mysql2/promise");
const fs = require("node:fs");
const path = require("node:path");
const { migrateStructure } = require("../services/structureMigration");
async function main() {
  const file = path.join(__dirname, "../db_config.json");
  const cfg = fs.existsSync(file)
    ? JSON.parse(fs.readFileSync(file, "utf8"))
    : {};
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || cfg.host || "localhost",
    port: Number(process.env.DB_PORT || cfg.port || 3306),
    user: process.env.DB_USER || cfg.user || "root",
    password: process.env.DB_PASSWORD ?? cfg.password ?? "",
    database: process.env.DB_NAME || cfg.database || "user_management",
  });
  try {
    await migrateStructure(conn);
    const [[count]] = await conn.query(
      "SELECT COUNT(*) AS open FROM mentor_assignments WHERE effective_to IS NULL",
    );
    console.log(
      `Cấu trúc nhóm/mentor đã sẵn sàng. Phân công mentor đang mở: ${count.open}.`,
    );
  } finally {
    await conn.end();
  }
}
main().catch((err) => {
  console.error(err);
  process.exit(1);
});
