# Cấu trúc chương trình – nhóm – mentor – lịch (8 quy tắc thiết kế)

Tài liệu này mô tả cách hệ thống đáp ứng 8 quy tắc thiết kế. Nâng cấp DB cũ: `cd backend && npm run migrate:structure`
(cũng tự chạy khi backend khởi động; chạy lặp lại an toàn, chỉ thêm mới).

| # | Quy tắc | Hiện thực |
|---|---|---|
| 1 | Chương trình có nhiều Intern qua bảng đăng ký | `program_interns` (đã có). Thêm `program_intern_events` ghi lịch sử thêm/gỡ. |
| 2 | Chương trình có nhiều nhóm, nhóm thuộc một chương trình | `program_groups(program_id, name)`, tên duy nhất trong chương trình. |
| 3 | Mỗi Intern một nhóm chính tại một thời điểm trong mỗi chương trình | `group_members` có `is_primary`, `joined_at`, `left_at`. Khóa duy nhất trên cột sinh `active_primary_key` chặn hai nhóm chính đang hiệu lực; FK kép buộc Intern phải thuộc chương trình của nhóm. Nhóm phụ (`is_primary=false`) được phép khi nghiệp vụ cần. |
| 4 | Mentor phân công qua bảng có thời gian hiệu lực | `mentor_assignments(intern_id, mentor_id, program_id, effective_from, effective_to)`; tối đa một phân công đang mở/Intern. `intern_profiles.mentor_id` vẫn là "mentor hiện tại" cho các truy vấn cũ và luôn cập nhật **cùng giao dịch**. |
| 5 | Lịch có phạm vi rõ ràng | Lịch họp: `scope_type` = `INDIVIDUAL` / `PROGRAM` / `GROUP` (+ `group_id`). Lịch làm việc: thêm phạm vi `GROUP`. |
| 6 | Khung giờ định kỳ tách khỏi lịch cụ thể | Đã có: `work_schedules`/`work_schedule_days` tách khỏi `meetings`. |
| 7 | Lịch chung/nhóm tự xác định từ thành viên; cá nhân/ngoại lệ dùng `schedule_participants` | Họp PROGRAM/GROUP tự lấy người từ `program_interns`/`group_members`; `schedule_participants` lưu ngoại lệ `INCLUDE`/`EXCLUDE`. `meeting_attendees` là kết quả đã tính. |
| 8 | Giữ lịch sử và xác định ảnh hưởng đến lịch tương lai | Đổi mentor/nhóm đóng dòng cũ (không xóa). Đổi thành viên chương trình/nhóm tự đồng bộ **lịch họp tương lai** theo phạm vi: tăng `sequence`, gửi lời mời/thông báo hủy đúng người; lịch hết người tự hủy. |

## Thứ tự ưu tiên lịch làm việc
`INTERN` > `GROUP` > `PROGRAM` > `MENTOR` > `UNIVERSITY` > `DEFAULT`. Nhóm được xác định theo **ngày** (lịch sử `group_members`);
ngày rời nhóm là mốc loại trừ nên chuyển nhóm trong ngày D thì nhóm mới áp dụng từ D.

## API mới (HR ghi; Admin/HR đọc)
- `GET|POST /api/programs/:id/groups`, `PUT|DELETE /api/groups/:groupId`
- `GET|POST /api/groups/:groupId/members` (`{intern_ids, is_primary?, move?}`; `?history=1` xem cả người đã rời), `DELETE /api/groups/:groupId/members/:internId`
- `GET /api/programs/:id/ungrouped-interns`, `GET /api/programs/:id/enrollment-history`
- `GET /api/interns/:id/mentor-history[?at=YYYY-MM-DD[ HH:mm[:ss]]]` (giờ Việt Nam)
- `POST|PUT /api/meetings` nhận thêm `scope_type`, `group_id`, `include_ids`, `exclude_ids`
  (PROGRAM/GROUP không gửi `attendee_ids`; `include_ids` chỉ cho GROUP và phải là thành viên chương trình).
- `POST /api/work-schedules/assignments` nhận `target_type: "GROUP"` (`target_value` = id nhóm).
- `PUT /api/groups/:groupId/mentor` `{mentor_id, confirm_warnings?}`: gán mentor cho mọi thành viên đang hoạt động của nhóm (mỗi người có dòng lịch sử riêng, ghi chú "Gán theo nhóm …"; cùng cơ chế cảnh báo cần xác nhận như gán theo chương trình).
- `POST /api/groups/:groupId/roadmap` và `POST /api/programs/:id/roadmap` `{source_intern_id}`: **sao chép** lộ trình thực tập của một người cho các thành viên chưa có lộ trình (người đã có được giữ nguyên). Lộ trình vẫn là dữ liệu của từng thực tập sinh.
- **Xem trước ảnh hưởng (dry run):** `POST /api/groups/:groupId/members` nhận `dry_run: true`, `DELETE /api/groups/:groupId/members/:internId?dry_run=1`. Thực hiện trong giao dịch rồi hoàn tác; trả về các lịch họp tương lai sẽ bị cập nhật/hủy, không gửi email, không đổi dữ liệu.
- `GET /api/me/groups` (Intern: nhóm của mình; Mentor: các nhóm có thực tập sinh của mình).
- `GET /api/attendance/report?scope_type=GROUP&scope_value=<id nhóm>`: báo cáo chuyên cần theo nhóm chính (tính theo ngày trong khoảng báo cáo).

## Hành vi cần biết
- Chuyển nhóm chính: gửi `move: true`, nếu không API trả 409 để tránh chuyển nhầm.
- Xóa nhóm: các lịch họp theo nhóm chuyển về `INDIVIDUAL` (giữ nguyên người tham dự); bị chặn (409) nếu nhóm đang được gán lịch làm việc.
- Gỡ Intern khỏi chương trình xóa dòng thành viên nhóm (FK CASCADE) nhưng `program_intern_events` giữ đủ dấu vết: `ADDED`/`REMOVED` (chương trình) và `GROUP_JOINED`/`GROUP_LEFT` (nhóm, kèm tên nhóm tại thời điểm đó), kể cả khi nhóm sau đó bị xóa.
- Dữ liệu mentor cũ được ghi thành một phân công đang mở (`note = 'Khởi tạo từ dữ liệu hiện có'`); hệ thống **không suy diễn** lịch sử trước đó.

## Giao diện web (HR)
- **Chương trình thực tập → nút "Nhóm":** tạo/đổi tên/xóa nhóm, xem thành viên, thêm thành viên (chọn nhóm chính/phụ, tùy chọn "chuyển nhóm"), danh sách thực tập sinh chưa có nhóm, lịch sử đăng ký chương trình.
- **Chương trình thực tập → "Thực tập sinh & mentor" → "Lịch sử mentor":** các mentor đã phụ trách một thực tập sinh theo thời gian.
- **Lịch họp → Tạo/Sửa:** ô "Cách chọn người tham dự" (chọn từng người / cả chương trình / theo nhóm) kèm danh sách ngoại lệ (không mời, mời thêm). Chi tiết lịch hiện dòng "Phạm vi". Mentor không thấy lựa chọn này.
- **Lịch làm việc → Gán lịch:** thêm lựa chọn "Nhóm trong chương trình". **Báo cáo chuyên cần:** thêm phạm vi "Theo nhóm".
- **Trong cửa sổ Nhóm:** gán mentor cho cả nhóm, áp dụng lộ trình, và hộp xác nhận liệt kê các lịch họp sẽ bị ảnh hưởng trước khi thêm/cho rời nhóm.
- **Danh sách thực tập sinh:** nút đồng hồ "Lịch sử mentor" (HR, Admin). **Intern và Mentor:** mục menu "Nhóm của tôi".

## Giới hạn đã biết
- Gói demo (`demo/demo_data.json`) không có `program_interns` nên không kèm dữ liệu nhóm; khi nạp demo, các bảng nhóm/mentor được xóa sạch (tránh dòng mồ côi) và lịch sử mentor được dựng lại từ `intern_profiles.mentor_id`.
- Giữ hai nơi khớp nhau: mọi thao tác đổi mentor phải đi qua `recordMentorChange` trong **cùng giao dịch** và khóa dòng intern (`FOR UPDATE`) trước khi đọc `mentor_id`. Thao tác ghi `mentor_id` ngoài luồng đó (như `backfillInternMentorIds`) phải gọi `reconcileMentorHistory()` ngay sau; `server.js` đã làm việc này sau khi nạp demo. DB không có ràng buộc nào ép hai nơi khớp, nên có thể kiểm tra bằng `npm run check:mentor-drift` (thêm `-- --fix` để đồng bộ lại; thoát mã 1 nếu còn lệch).
- `intern_profiles.mentor_id` vẫn tồn tại song song `mentor_assignments` (cùng giao dịch); chưa có "mentor của nhóm" như một thuộc tính riêng của nhóm — gán theo nhóm là thao tác gán hàng loạt.
- Báo cáo hoàn thành chương trình chưa lọc/gom theo nhóm; báo cáo chuyên cần chỉ lọc theo nhóm (chưa có `group_by=GROUP`).
- Chưa kiểm thử trên MySQL thật và trình duyệt thật (đã chạy trên MariaDB 10.11; giao diện kiểm tra thủ công bằng jsdom, không đưa vào dự án).
