const assert=require('node:assert/strict');
const{spawnSync}=require('node:child_process');
const path=require('node:path');
const base=path.resolve(process.argv[2]||process.cwd())+path.sep;
const mysql=require(base+'node_modules/mysql2/promise');
const {readDbConfig}=require(base+'tests/test_helpers');
const {findMentorAssignmentDrift}=require(base+'services/structureMigration');
(async()=>{
 const cfg=readDbConfig();assert.match(cfg.database,/^us[678]_test_/);
 const conn=await mysql.createConnection(cfg),mentors=[];let intern;
 try{
  await conn.query("SET time_zone='+07:00'");
  assert.deepEqual(await findMentorAssignmentDrift(conn),[],'Test database must start clean');
  const prefix='drift_cli_'+Date.now();
  for(const label of ['A','B']){const[r]=await conn.query('INSERT INTO mentors(full_name,email) VALUES(?,?)',[prefix+label,prefix+label+'@example.test']);mentors.push(r.insertId);}
  const [r]=await conn.query("INSERT INTO intern_profiles(full_name,email,mentor_id,mentor_name,status) VALUES(?,?,?,?,'Đang thực tập')",[prefix,prefix+'@example.test',mentors[0],prefix+'A']);intern=r.insertId;
  await conn.query('INSERT INTO mentor_assignments(intern_id,mentor_id,mentor_name,effective_from) VALUES(?,?,?,NOW(3))',[intern,mentors[1],prefix+'B']);
  const run=(args=[])=>spawnSync(process.execPath,['scripts/check_mentor_drift.js',...args],{cwd:base,encoding:'utf8',env:process.env});
  const check=run();assert.equal(check.status,1,check.stdout+check.stderr);assert.ok(check.stderr.includes('LỆCH 1'));assert.equal((await findMentorAssignmentDrift(conn)).length,1);console.log('[PASS] Read-only CLI detects fixture drift, exits 1, leaves data unchanged');
  const fix=run(['--fix']);assert.equal(fix.status,0,fix.stdout+fix.stderr);assert.deepEqual(await findMentorAssignmentDrift(conn),[]);console.log('[PASS] CLI --fix uses Vietnam dates on a UTC-default MySQL server and restores consistency');
  const [before]=await conn.query('SELECT * FROM mentor_assignments WHERE intern_id=? ORDER BY id',[intern]);const repeat=run(['--fix']);assert.equal(repeat.status,0,repeat.stderr);const[after]=await conn.query('SELECT * FROM mentor_assignments WHERE intern_id=? ORDER BY id',[intern]);assert.deepEqual(after,before);console.log('[PASS] Repeating --fix is idempotent');
 }finally{if(intern)await conn.query('DELETE FROM intern_profiles WHERE id=?',[intern]);if(mentors.length)await conn.query('DELETE FROM mentors WHERE id IN (?)',[mentors]);await conn.end();}
})().catch(e=>{console.error(e);process.exitCode=1;});
