# Kiểm tra UserManagement_structure_fixed.zip

Đầu vào: ZIP người dùng cung cấp, không lấy bản GitHub thay thế. Cài bằng `npm install` theo lockfile, package.json/package-lock.json giữ nguyên. MySQL Community **8.0.46**, DB riêng **us8_test_structure_review_20261018**, backend/API chạy trong bản sao `/tmp/structure-runtime` trên cổng 5052. Không chạy test lên DB người dùng; không dùng cấu hình mật khẩu có sẵn, không gửi SMTP ra ngoài. Runtime tách biệt để không sửa uploads trong bản nguồn.

## 1. Định dạng

Đã chạy Prettier 3.6.2 theo .prettierrc.json cho đúng sáu file yêu cầu. Hoàn tác các thay đổi định dạng ở code cũ không liên quan trong db.js và hai test, đúng yêu cầu giữ diff gọn.

Sau riêng bước định dạng, chỉ ba file có diff:

- backend/services/structureMigration.js
- backend/tests/test_structure_api.js
- backend/tests/test_structure_unit.js

backend/db.js, backend/server.js và backend/scripts/check_mentor_drift.js không cần giữ diff định dạng. Đã đối chiếu AST và chú thích của cả sáu file với ZIP: giống hệt, bước này chỉ đổi cách xuống dòng/khoảng trắng. Patch riêng: `01-format-only.patch`.

Sau khi sửa các lỗi test phát hiện, diff cuối cùng gồm **bốn file**, đều thuộc danh sách cho phép:

| File | Thay đổi cuối cùng |
| --- | --- |
| backend/services/structureMigration.js | Định dạng; mở/commit/rollback giao dịch khi nhận cả pool lẫn connection trực tiếp. |
| backend/scripts/check_mentor_drift.js | Đặt session MySQL theo VIETNAM_UTC_OFFSET trước kiểm tra/sửa. |
| backend/tests/test_structure_api.js | Định dạng phần mới; đặt múi giờ cho kết nối fixture; phân loại deadlock ở ca chạy đua qua DB. |
| backend/tests/test_structure_unit.js | Định dạng phần mới; mở rộng hai test giao dịch/rollback chạy cả pool và connection. Vẫn đủ 14 test cũ. |

Không sửa db.js (FOR UPDATE đã có và được giữ nguyên), server.js, package.json/lockfile, docs, schema, frontend hoặc uploads. Không thêm dependency dự án, trigger hay ràng buộc DB. Không xóa test. So sánh từng file với ZIP xác nhận chỉ đúng bốn file trên đổi byte. Những phần code cũ vốn chưa khớp Prettier được giữ lại theo giới hạn phạm vi; không khẳng định toàn bộ db.js/hai test đã được format lại.

## 2. Lỗi được tái hiện và sửa tối thiểu

### Múi giờ của kết nối test và CLI

Pool ứng dụng dùng +07:00, nhưng kết nối riêng của API test và CLI dùng mặc định UTC của máy chủ MySQL. Lúc đóng lịch sử, NOW(3) có thể sớm hơn effective_from bảy giờ, vi phạm CHECK sẵn có:

```text
ER_CHECK_CONSTRAINT_VIOLATED (3819)
Check constraint 'chk_ma_range' is violated.
UPDATE mentor_assignments SET effective_to=NOW(3) ...
```

API test ban đầu thất bại ở ca backfill/reconcile. Smoke test riêng cũng tái hiện lỗi tương tự với `check_mentor_drift.js --fix`. Sửa bằng `SET time_zone = ?` sử dụng VIETNAM_UTC_OFFSET ở hai kết nối đó. Không bỏ CHECK, không sửa dữ liệu để né lỗi.

Log: `logs/first-run/2-test-structure-api.log`, `logs/cli-before-fix.log`.

### Thiếu giao dịch khi truyền connection trực tiếp

reconcileMentorHistory chỉ begin/commit/rollback nếu database có getConnection (pool). CLI lại truyền connection trực tiếp, nên hai câu UPDATE/INSERT có thể autocommit riêng lẻ. Hai unit về giao dịch và rollback trước đây chỉ kiểm tra pool. Mở rộng chính hai test đó cho connection tái hiện thất bại: log truy vấn không có BEGIN/COMMIT.

Sửa tối thiểu: luôn mở giao dịch khi thực sự cần reconcile; vẫn giữ quyền sở hữu kết nối như cũ (chỉ trả connection về pool nếu hàm lấy nó từ pool). Nhánh không lệch vẫn không ghi dữ liệu. Theo hợp đồng đã ghi trong code, connection trực tiếp phải là connection chưa mở giao dịch.

Log tái hiện: `logs/unit-direct-connection-before-fix.log`. Không đổi cách xác định mentor hiện tại, SQL đồng bộ hay hành vi migrateStructure.

### Test chạy đua cũ giả định cả hai HTTP request đều thành công

Một lần chạy lại gặp đúng lỗi InnoDB được yêu cầu chấp nhận:

```text
ER_LOCK_DEADLOCK (1213)
Deadlock found when trying to get lock; try restarting transaction
SELECT id, mentor_id FROM intern_profiles WHERE id = ... FOR UPDATE
```

HTTP 500 chung đã ẩn mã SQL, nên không thể chấp nhận mọi 500 mà vẫn bảo đảm chỉ bỏ qua deadlock. Đổi riêng phần chạy đua hai mentor sang appDb.assignInternMentor + Promise.allSettled, tương tự ca updateStudent mới: chỉ ER_LOCK_DEADLOCK được chấp nhận, kết quả thành công phải là UPDATED, ít nhất một giao dịch thành công. Giữ nguyên kiểm tra một dòng mở và mentor_id khớp lịch sử; các ca API phân quyền/gán/gỡ và các test trước đó vẫn giữ. Không thêm retry hoặc sửa cách API xử lý lỗi.

Log: `logs/api-http-race-deadlock.log`, `logs/server-http-race-deadlock.log`.

Các sửa logic/test được tách riêng khỏi định dạng trong `02-test-fixes.patch`.

## 3. Kết quả chạy thật

Lệnh chạy trong backend, trừ script smoke nằm ngoài dự án. Tất cả kết quả cuối dưới đây exit 0.

| Lệnh | Kết quả cuối | Số test / suite |
| --- | --- | --- |
| npm install | PASS, không đổi manifest/lockfile | Cài phụ thuộc thành công |
| npm run test:structure-unit | PASS | **14 test**; hai test transaction/rollback bao phủ thêm connection trực tiếp |
| npm run test:structure-api | PASS | **45 nhóm kiểm tra**; chạy lại hai lần liên tiếp đều 45 PASS |
| node tests/test_mentor_assignment_unit.js | PASS | **15 matching + 5 notification = 20 case** |
| npm run test:interns | PASS | **6/6 case** |
| npm run test:mentors | PASS | **4/4 case** |
| node tests/test_mentor_assignment_api.js | PASS | **1 suite**; script không in số case, không tự suy diễn số lượng |
| npm run test:unit | PASS | **33 suite, 0 FAIL, 0 SKIP** |
| npm run check:mentor-drift | PASS / OK | **0 hồ sơ lệch**, exit 0, trước/sau test |
| Smoke CLI với fixture lệch cố ý | PASS | **3 case**: read-only phát hiện/exit 1/không sửa; --fix thành công; --fix lặp không đổi dữ liệu |
| node --check sáu file chỉ định | PASS | **6 file** |
| Prettier phần thêm/sửa + git diff --check | PASS | Giữ định dạng code cũ ngoài phạm vi |

Hai alias npm test:mentor-assignment-unit/API chưa có trong package.json, nên chạy trực tiếp các file tương ứng, không thêm script ngoài nhu cầu.

`check:mentor-drift` cuối cùng in:

```text
OK: intern_profiles.mentor_id khớp mentor_assignments.
```

Không dùng --fix để che lỗi của lượt test. Smoke --fix chỉ chạy khi toàn DB thử ban đầu đã sạch, tự tạo đúng một fixture lệch, đối chiếu kết quả và tự dọn. Quét toàn DB trong structure API giữ nguyên và đạt. Log cuối lưu ở `logs/final/`.

Có thể chạy lại smoke bằng `node /đường/dẫn/cli_regression.cjs /đường/dẫn/backend` với biến DB_* trỏ DB thử. Script chỉ chấp nhận tên DB bắt đầu us6_test_/us7_test_/us8_test_; từ chối nếu DB đã có lệch trước khi tạo fixture. Không chạy trên dữ liệu thật.

## 4. Vấn đề phát hiện thêm, không sửa ngoài phạm vi

- test_structure_api.js gốc chưa tự kiểm tra prefix DB/cờ cho phép trước khi ghi. Lượt kiểm tra này được bảo vệ bằng runtime riêng, biến môi trường và tên DB thử cố định. Khi chạy thủ công vẫn phải chọn DB DEV/TEST như yêu cầu; không coi tiền tố dữ liệu fixture là đủ để bảo vệ DB thật.
- API hiện vẫn có thể trả HTTP 500 chung khi một giao dịch bị InnoDB chọn làm nạn nhân deadlock. Giữ nguyên hành vi này theo giới hạn không đổi nghiệp vụ; test race kiểm tra trực tiếp mã DB và không chấp nhận lỗi khác.
- Dòng tài liệu cũ nói chưa chạy MySQL thật được giữ nguyên trong docs/STRUCTURE_RULES.md để không mở rộng diff. Báo cáo này bổ sung kết quả MySQL 8.0.46, không xác nhận browser.
- Unit mentor có log `db.findMentorUserId is not a function` do test cố ý truyền `{ db: {} }` để kiểm tra lỗi thông báo không làm hỏng nghiệp vụ; case đó vẫn PASS, không phải lỗi kết nối thật.

Chưa chạy toàn bộ API/browser của dự án; đã chạy toàn bộ unit và các API được yêu cầu. Npm ban đầu không ghi được cache ở thư mục mặc định; đã đổi cache sang /tmp và cài lại thành công, không tắt TLS/integrity hoặc sửa lockfile.
