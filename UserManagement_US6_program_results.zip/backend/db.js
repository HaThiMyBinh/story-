// db.js - Quản lý kết nối & truy vấn Database MySQL (nguồn dữ liệu DUY NHẤT)
const mysql = require("mysql2/promise");
const fs = require("fs");
const path = require("path");
const { hashPassword } = require("./auth");
const fileStorage = require("./services/fileStorage");
const {
  resolveUniqueMentorId,
} = require("./services/mentorAssignment.service");
const { VIETNAM_UTC_OFFSET } = require("./utils/date");

const CONFIG_FILE = path.join(__dirname, "db_config.json");

let config = {
  host: "localhost",
  port: 3306,
  user: "root",
  password: "",
  database: "user_management",
};

if (fs.existsSync(CONFIG_FILE)) {
  try {
    config = {
      ...config,
      ...JSON.parse(fs.readFileSync(CONFIG_FILE, "utf-8")),
    };
  } catch (e) {
    console.warn(
      `[DATABASE] Không đọc được ${CONFIG_FILE}, dùng cấu hình mặc định.`,
    );
  }
}

// Cảnh báo nếu mật khẩu MySQL vẫn còn là giá trị mẫu (chưa được thay bằng
// mật khẩu thật) - tránh trường hợp deploy nhầm với cấu hình demo.
if (config.password === "your_password_here" && !process.env.DB_PASSWORD) {
  console.warn(
    "[DATABASE] CẢNH BÁO: backend/db_config.json vẫn đang dùng mật khẩu mẫu " +
      "'your_password_here'. Vui lòng cập nhật mật khẩu MySQL thật của bạn " +
      "(hoặc dùng biến môi trường DB_PASSWORD) trước khi triển khai.",
  );
}

// Biến môi trường (nếu có) sẽ ghi đè db_config.json
config = {
  host: process.env.DB_HOST || config.host,
  port: Number(process.env.DB_PORT) || config.port,
  user: process.env.DB_USER || config.user,
  password: process.env.DB_PASSWORD ?? config.password,
  database: process.env.DB_NAME || config.database,
};

let pool = null;
let isMysqlConnected = false;

function requireDb() {
  if (!isMysqlConnected || !pool) {
    throw new Error(
      "MySQL chưa sẵn sàng. Vui lòng kiểm tra cấu hình db_config.json và đảm bảo MySQL Server đang chạy.",
    );
  }
  return pool;
}

// Cho phép script xuất demo dùng pool hiện tại sau khi initDatabase() hoàn tất.
function getPool() {
  return requireDb();
}

async function seedDepartmentsFromMentors(targetPool = requireDb()) {
  const [departmentCount] = await targetPool.query(
    "SELECT COUNT(*) AS total FROM departments",
  );
  if (Number(departmentCount[0].total) > 0) return false;
  await targetPool.query(`INSERT IGNORE INTO departments (name)
    SELECT DISTINCT TRIM(department) FROM mentors
    WHERE department IS NOT NULL AND TRIM(department) <> ''`);
  return true;
}

async function backfillInternMentorIds(targetPool = requireDb()) {
  const [result] = await targetPool.query(`
    UPDATE intern_profiles ip
    JOIN (
      SELECT ip_old.id, MIN(m.id) AS mentor_id
      FROM intern_profiles ip_old
      JOIN mentors m
        ON LOWER(TRIM(m.full_name)) COLLATE utf8mb4_unicode_ci
           = LOWER(TRIM(ip_old.mentor_name)) COLLATE utf8mb4_unicode_ci
      WHERE ip_old.mentor_id IS NULL
        AND ip_old.mentor_name IS NOT NULL
        AND TRIM(ip_old.mentor_name) <> ''
      GROUP BY ip_old.id
      HAVING COUNT(DISTINCT m.id) = 1
    ) resolved ON resolved.id = ip.id
    SET ip.mentor_id = resolved.mentor_id
    WHERE ip.mentor_id IS NULL
  `);
  return result.affectedRows;
}

async function closePool() {
  if (pool) await pool.end();
  pool = null;
  isMysqlConnected = false;
}

function nowISO() {
  return new Date().toISOString();
}

// Phòng ban mặc định khi hồ sơ mentor được tạo tự động từ một tài khoản Mentor
const DEFAULT_MENTOR_DEPARTMENT = "Chưa cập nhật";
// Trường/trạng thái mặc định khi hồ sơ thực tập sinh được tạo tự động từ tài khoản Intern
const DEFAULT_INTERN_UNIVERSITY = "Chưa cập nhật";
const DEFAULT_INTERN_STATUS = "Đang thực tập";
// Tài khoản Intern đang là ứng viên chờ duyệt / bị từ chối chưa phải thực tập sinh chính thức
const NON_INTERN_ACCOUNT_STATUSES = ["PENDING", "LOCKED"];
const NON_INTERN_ACCOUNT_STATUSES_SQL = NON_INTERN_ACCOUNT_STATUSES.map(
  (status) => `'${status}'`,
).join(", ");
// Mật khẩu mặc định của tài khoản được tạo tự động từ hồ sơ mentor / thực tập sinh
const DEFAULT_ACCOUNT_PASSWORD = "password123";

// Lỗi nghiệp vụ; mặc định 400, có thể dùng status khác cho xung đột trạng thái.
class ConflictError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
}

// Chạy nhiều câu lệnh trong 1 transaction để 2 bảng users & mentors luôn khớp nhau
async function withTransaction(work) {
  const conn = await requireDb().getConnection();
  try {
    await conn.beginTransaction();
    const result = await work(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

// Tra cứu role_id từ tên vai trò (Admin/HR/Mentor/Intern) trong bảng roles
async function getRoleId(roleName) {
  const db = requireDb();
  const [rows] = await db.query(
    "SELECT id FROM roles WHERE role_name = ? LIMIT 1",
    [roleName],
  );
  if (rows.length === 0) {
    throw new Error(
      `Vai trò không hợp lệ: '${roleName}' không tồn tại trong bảng roles.`,
    );
  }
  return rows[0].id;
}

// Thêm cột nếu chưa có (MySQL không hỗ trợ ADD COLUMN IF NOT EXISTS ở mọi phiên bản)
async function ensureColumn(table, column, definition) {
  const [rows] = await pool.query(
    `SELECT 1 FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1`,
    [config.database, table, column],
  );
  if (rows.length === 0) {
    await pool.query(
      `ALTER TABLE \`${table}\` ADD COLUMN \`${column}\` ${definition}`,
    );
  }
}

async function ensureForeignKey(table, constraintName, definition) {
  const [rows] = await pool.query(
    `SELECT 1 FROM information_schema.TABLE_CONSTRAINTS
     WHERE CONSTRAINT_SCHEMA = ? AND TABLE_NAME = ? AND CONSTRAINT_NAME = ?
       AND CONSTRAINT_TYPE = 'FOREIGN KEY' LIMIT 1`,
    [config.database, table, constraintName],
  );
  if (rows.length === 0) {
    await pool.query(
      `ALTER TABLE \`${table}\` ADD CONSTRAINT \`${constraintName}\` ${definition}`,
    );
  }
}

// Đổi tên index FK MySQL tự sinh để database cũ dùng chung tên khai báo trong schema.sql.
async function ensureIndex(table, indexName, columnName) {
  const [namedIndexes] = await pool.query(
    `SELECT 1 FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND INDEX_NAME = ? LIMIT 1`,
    [config.database, table, indexName],
  );
  if (namedIndexes.length > 0) return;

  const [supportingIndexes] = await pool.query(
    `SELECT INDEX_NAME AS indexName
     FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND INDEX_NAME <> 'PRIMARY'
     GROUP BY INDEX_NAME
     HAVING COUNT(*) = 1 AND SUM(CASE WHEN SEQ_IN_INDEX = 1 AND COLUMN_NAME = ? THEN 1 ELSE 0 END) = 1
     LIMIT 1`,
    [config.database, table, columnName],
  );
  const existingName = supportingIndexes[0]?.indexName;
  if (existingName) {
    const safeOldName = String(existingName).replace(/`/g, "``");
    await pool.query(
      `ALTER TABLE \`${table}\` RENAME INDEX \`${safeOldName}\` TO \`${indexName}\``,
    );
    return;
  }

  await pool.query(
    `ALTER TABLE \`${table}\` ADD INDEX \`${indexName}\` (\`${columnName}\`)`,
  );
}

async function ensureUniqueScheduleIndex() {
  const [indexes] = await pool.query(
    `SELECT INDEX_NAME AS indexName, NON_UNIQUE AS nonUnique,
            GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) AS columnsList
     FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'intern_schedules'
     GROUP BY INDEX_NAME, NON_UNIQUE`,
    [config.database],
  );
  const matchesColumns = (index) =>
    Number(index.nonUnique) === 0 &&
    index.columnsList === "intern_id,phase_order";
  const correct = indexes.some(
    (index) =>
      index.indexName === "uq_schedule_intern_phase" && matchesColumns(index),
  );
  if (correct) return;
  // Keep the lowest ID for each pair before adding the unique key.
  await pool.query(`DELETE newer FROM intern_schedules newer
    JOIN intern_schedules older ON older.intern_id = newer.intern_id
      AND older.phase_order = newer.phase_order AND older.id < newer.id`);
  const named = indexes.find(
    (index) => index.indexName === "uq_schedule_intern_phase",
  );
  if (named)
    await pool.query(
      "ALTER TABLE intern_schedules DROP INDEX uq_schedule_intern_phase",
    );
  const existingUnique = indexes.find(
    (index) =>
      index.indexName !== "uq_schedule_intern_phase" && matchesColumns(index),
  );
  if (existingUnique) {
    const oldName = String(existingUnique.indexName).replace(/`/g, "``");
    await pool.query(
      `ALTER TABLE intern_schedules RENAME INDEX \`${oldName}\` TO uq_schedule_intern_phase`,
    );
    return;
  }
  await pool.query(
    "ALTER TABLE intern_schedules ADD UNIQUE KEY uq_schedule_intern_phase (intern_id, phase_order)",
  );
}

// Khởi tạo kết nối MySQL, tạo bảng & seed dữ liệu mặc định nếu chưa có
async function initDatabase() {
  // Repeated initialization replaces the previous pool instead of leaking it.
  if (pool) await pool.end();
  pool = null;
  isMysqlConnected = false;
  // 1. Kết nối không chọn DB để tạo DB nếu chưa tồn tại
  const rootConn = await mysql.createConnection({
    host: config.host,
    port: config.port,
    user: config.user,
    password: config.password,
  });

  await rootConn.query(
    `CREATE DATABASE IF NOT EXISTS \`${config.database}\` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`,
  );
  await rootConn.end();

  // Tạo Pool kết nối tới database chính
  pool = mysql.createPool({
    host: config.host,
    port: config.port,
    user: config.user,
    password: config.password,
    database: config.database,
    dateStrings: ["DATE"],
    // Cố định múi giờ Việt Nam cho cả phía Node (chuyển đổi Date) và phiên MySQL (NOW(), TIMESTAMP).
    timezone: VIETNAM_UTC_OFFSET,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
  });
  pool.on("connection", (connection) => {
    connection.query(`SET time_zone = '${VIETNAM_UTC_OFFSET}'`);
  });

  // Tạo các bảng đúng theo thiết kế quan hệ trong schema.sql
  await pool.query(`
    CREATE TABLE IF NOT EXISTS \`roles\` (
      \`id\` INT AUTO_INCREMENT PRIMARY KEY,
      \`role_name\` VARCHAR(50) NOT NULL UNIQUE,
      \`description\` VARCHAR(255) NULL,
      \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS \`permissions\` (
      \`id\` INT AUTO_INCREMENT PRIMARY KEY,
      \`perm_code\` VARCHAR(50) NOT NULL UNIQUE,
      \`perm_name\` VARCHAR(100) NOT NULL,
      \`description\` VARCHAR(255) NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS \`role_permissions\` (
      \`role_id\` INT NOT NULL,
      \`permission_id\` INT NOT NULL,
      PRIMARY KEY (\`role_id\`, \`permission_id\`),
      FOREIGN KEY (\`role_id\`) REFERENCES \`roles\`(\`id\`) ON DELETE CASCADE,
      FOREIGN KEY (\`permission_id\`) REFERENCES \`permissions\`(\`id\`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  // users.role_id -> roles.id
  await pool.query(`
    CREATE TABLE IF NOT EXISTS \`users\` (
      \`id\` BIGINT AUTO_INCREMENT PRIMARY KEY,
      \`name\` VARCHAR(100) NOT NULL,
      \`email\` VARCHAR(150) NOT NULL UNIQUE,
      \`password_hash\` VARCHAR(255) NOT NULL,
      \`role_id\` INT NOT NULL,
      \`phone\` VARCHAR(20) NULL,
      \`status\` ENUM('ACTIVE', 'INACTIVE', 'LOCKED', 'PENDING') DEFAULT 'ACTIVE',
      \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (\`role_id\`) REFERENCES \`roles\`(\`id\`) ON DELETE RESTRICT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS \`candidate_profiles\` (
      \`id\` BIGINT AUTO_INCREMENT PRIMARY KEY,
      \`user_id\` BIGINT NULL,
      \`full_name\` VARCHAR(100) NOT NULL,
      \`email\` VARCHAR(150) NOT NULL UNIQUE,
      \`phone\` VARCHAR(20) NOT NULL,
      \`university\` VARCHAR(150) NOT NULL,
      \`major\` VARCHAR(100) NULL,
      \`cv_link\` VARCHAR(255) NULL,
      \`password_hash\` VARCHAR(255) NOT NULL,
      \`status\` ENUM('Chờ duyệt', 'Đã duyệt', 'Từ chối') DEFAULT 'Chờ duyệt',
      \`applied_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (\`user_id\`) REFERENCES \`users\`(\`id\`) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS \`mentors\` (
      \`id\` BIGINT AUTO_INCREMENT PRIMARY KEY,
      \`full_name\` VARCHAR(100) NOT NULL,
      \`email\` VARCHAR(150) NOT NULL UNIQUE,
      \`phone\` VARCHAR(20) NULL,
      \`department\` VARCHAR(150) NULL,
      \`specialization\` VARCHAR(150) NULL,
      \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS \`intern_profiles\` (
      \`id\` BIGINT AUTO_INCREMENT PRIMARY KEY,
      \`student_code\` VARCHAR(30) NULL,
      \`full_name\` VARCHAR(100) NOT NULL,
      \`email\` VARCHAR(150) NOT NULL UNIQUE,
      \`phone\` VARCHAR(20) NULL,
      \`university\` VARCHAR(150) NULL,
      \`major\` VARCHAR(100) NULL,
      \`mentor_name\` VARCHAR(100) NULL,
      \`mentor_id\` BIGINT NULL,
      \`status\` VARCHAR(50) DEFAULT 'Đang thực tập',
      \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT \`fk_intern_mentor_id\` FOREIGN KEY (\`mentor_id\`) REFERENCES \`mentors\`(\`id\`) ON DELETE SET NULL,
      INDEX \`idx_intern_mentor_id\` (\`mentor_id\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await ensureColumn("intern_profiles", "mentor_id", "BIGINT NULL");
  await ensureIndex("intern_profiles", "idx_intern_mentor_id", "mentor_id");
  await ensureIndex("intern_profiles", "idx_intern_university", "university");
  await ensureIndex("intern_profiles", "idx_intern_major", "major");
  await ensureForeignKey(
    "intern_profiles",
    "fk_intern_mentor_id",
    "FOREIGN KEY (\`mentor_id\`) REFERENCES \`mentors\`(\`id\`) ON DELETE SET NULL",
  );
  await backfillInternMentorIds(pool);

  // cột phục vụ duyệt / từ chối hồ sơ
  await ensureColumn("candidate_profiles", "rejection_reason", "TEXT NULL");
  await ensureColumn("candidate_profiles", "reviewed_by", "BIGINT NULL");
  await ensureColumn("candidate_profiles", "reviewed_at", "DATETIME NULL");

  // bảng nhật ký gửi email thông báo kết quả xét duyệt
  await pool.query(`
    CREATE TABLE IF NOT EXISTS \`email_logs\` (
      \`id\` BIGINT AUTO_INCREMENT PRIMARY KEY,
      \`application_id\` BIGINT NULL,
      \`recipient_email\` VARCHAR(150) NOT NULL,
      \`recipient_name\` VARCHAR(100) NULL,
      \`email_type\` ENUM('APPROVED', 'REJECTED') NOT NULL,
      \`subject\` VARCHAR(255) NOT NULL,
      \`status\` ENUM('PENDING', 'RETRYING', 'SENT', 'FAILED') NOT NULL DEFAULT 'PENDING',
      \`attempts\` INT NOT NULL DEFAULT 0,
      \`error_message\` TEXT NULL,
      \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      \`sent_at\` DATETIME NULL,
      FOREIGN KEY (\`application_id\`) REFERENCES \`candidate_profiles\`(\`id\`) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  // bảng tài liệu hồ sơ ứng tuyển (CV & Đơn xin thực tập)
  await pool.query(`
    CREATE TABLE IF NOT EXISTS \`application_documents\` (
      \`id\` BIGINT AUTO_INCREMENT PRIMARY KEY,
      \`application_id\` BIGINT NOT NULL,
      \`doc_type\` ENUM('CV', 'APPLICATION_LETTER') NOT NULL,
      \`original_name\` VARCHAR(255) NOT NULL,
      \`stored_name\` VARCHAR(255) NOT NULL,
      \`mime_type\` VARCHAR(100) NOT NULL,
      \`size_bytes\` BIGINT NOT NULL,
      \`uploaded_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY \`uq_application_doc_type\` (\`application_id\`, \`doc_type\`),
      FOREIGN KEY (\`application_id\`) REFERENCES \`candidate_profiles\`(\`id\`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  // Hợp đồng thực tập sinh chính thức, tách biệt tài liệu ứng tuyển
  await pool.query(`
    CREATE TABLE IF NOT EXISTS \`internship_contracts\` (
      \`id\` BIGINT AUTO_INCREMENT PRIMARY KEY,
      \`intern_id\` BIGINT NOT NULL, \`title\` VARCHAR(255) NULL,
      \`start_date\` DATE NULL, \`end_date\` DATE NULL, \`note\` TEXT NULL,
      \`program_id\` BIGINT NULL,
      \`original_name\` VARCHAR(255) NOT NULL, \`stored_name\` VARCHAR(255) NOT NULL,
      \`mime_type\` VARCHAR(100) NOT NULL, \`size_bytes\` BIGINT NOT NULL,
      \`uploaded_by\` BIGINT NULL, \`uploaded_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      \`confirmation_status\` ENUM('PENDING', 'CONFIRMED') NOT NULL DEFAULT 'PENDING',
      \`confirmed_at\` DATETIME NULL, \`confirmed_by\` BIGINT NULL,
      FOREIGN KEY (\`intern_id\`) REFERENCES \`intern_profiles\`(\`id\`) ON DELETE CASCADE,
      FOREIGN KEY (\`uploaded_by\`) REFERENCES \`users\`(\`id\`) ON DELETE SET NULL,
      CONSTRAINT \`fk_contract_confirmed_by\` FOREIGN KEY (\`confirmed_by\`) REFERENCES \`users\`(\`id\`) ON DELETE SET NULL,
      INDEX \`idx_contract_intern\` (\`intern_id\`),
      INDEX \`idx_contract_confirmed_by\` (\`confirmed_by\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);
  // CREATE TABLE khai báo đủ cột cho database mới; ensureColumn bổ sung chúng vào database cũ.
  // Hợp đồng cũ tự nhận PENDING, giữ nguyên dữ liệu và cho phép Intern xác nhận sau này.
  await ensureColumn(
    "internship_contracts",
    "confirmation_status",
    "ENUM('PENDING', 'CONFIRMED') NOT NULL DEFAULT 'PENDING'",
  );
  await ensureColumn("internship_contracts", "confirmed_at", "DATETIME NULL");
  await ensureColumn("internship_contracts", "confirmed_by", "BIGINT NULL");
  await ensureIndex(
    "internship_contracts",
    "idx_contract_confirmed_by",
    "confirmed_by",
  );
  await ensureForeignKey(
    "internship_contracts",
    "fk_contract_confirmed_by",
    "FOREIGN KEY (`confirmed_by`) REFERENCES `users`(`id`) ON DELETE SET NULL",
  );

  await pool.query(`CREATE TABLE IF NOT EXISTS departments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL COLLATE utf8mb4_unicode_ci,
    description TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_departments_name (name)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);
  await pool.query(`CREATE TABLE IF NOT EXISTS internship_programs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    department_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT NULL,
    start_date DATE NULL,
    end_date DATE NULL,
    capacity INT NULL,
    CONSTRAINT chk_program_capacity CHECK (capacity IS NULL OR capacity >= 1),
    status ENUM('DRAFT','OPEN','ONGOING','CLOSED') NOT NULL DEFAULT 'DRAFT',
    created_by BIGINT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_program_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE RESTRICT,
    CONSTRAINT fk_program_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_program_department_status (department_id, status)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await ensureColumn("internship_contracts", "program_id", "BIGINT NULL");
  await ensureForeignKey(
    "internship_contracts",
    "fk_contract_program",
    "FOREIGN KEY (\`program_id\`) REFERENCES internship_programs(id) ON DELETE SET NULL",
  );

  await pool.query(`CREATE TABLE IF NOT EXISTS intern_schedules (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    intern_id BIGINT NOT NULL,
    phase_order INT NOT NULL DEFAULT 1,
    title VARCHAR(255) NOT NULL,
    start_date DATE NULL,
    end_date DATE NULL,
    duration_weeks VARCHAR(50) NULL,
    description TEXT NULL,
    expected_results TEXT NULL,
    status ENUM('NOT_STARTED', 'IN_PROGRESS', 'COMPLETED') NOT NULL DEFAULT 'NOT_STARTED',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_schedule_intern_phase (intern_id, phase_order),
    INDEX idx_schedule_intern (intern_id),
    CONSTRAINT fk_schedule_intern FOREIGN KEY (intern_id) REFERENCES intern_profiles(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await ensureUniqueScheduleIndex();

  // Nhiệm vụ Mentor giao cho thực tập sinh. Xóa hồ sơ intern thì xóa nhiệm vụ;
  // xóa mentor chỉ bỏ liên kết người giao.
  await pool.query(`CREATE TABLE IF NOT EXISTS intern_tasks (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    intern_id BIGINT NOT NULL,
    created_by_mentor_id BIGINT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NULL,
    due_date DATE NULL,
    priority ENUM('LOW', 'MEDIUM', 'HIGH') NOT NULL DEFAULT 'MEDIUM',
    status ENUM('TODO', 'IN_PROGRESS', 'DONE') NOT NULL DEFAULT 'TODO',
    progress_percent TINYINT UNSIGNED NOT NULL DEFAULT 0,
    progress_note TEXT NULL,
    progress_updated_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_task_intern (intern_id),
    INDEX idx_task_mentor (created_by_mentor_id),
    CONSTRAINT fk_task_intern FOREIGN KEY (intern_id) REFERENCES intern_profiles(id) ON DELETE CASCADE,
    CONSTRAINT fk_task_mentor FOREIGN KEY (created_by_mentor_id) REFERENCES mentors(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  // Tiến độ do thực tập sinh cập nhật để mentor theo dõi (US12).
  await ensureColumn(
    "intern_tasks",
    "progress_percent",
    "TINYINT UNSIGNED NOT NULL DEFAULT 0",
  );
  await ensureColumn("intern_tasks", "progress_note", "TEXT NULL");
  await ensureColumn("intern_tasks", "progress_updated_at", "DATETIME NULL");
  // Việc DONE từ trước khi có cột % phải hiển thị 100% cho nhất quán.
  await pool.query(
    "UPDATE intern_tasks SET progress_percent = 100 WHERE status = 'DONE' AND progress_percent = 0",
  );

  // Tệp đính kèm khi thực tập sinh cập nhật tiến độ (minh chứng, báo cáo...).
  // Xóa nhiệm vụ thì xóa bản ghi; file trên đĩa do service dọn.
  await pool.query(`CREATE TABLE IF NOT EXISTS task_attachments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    task_id BIGINT NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    stored_name VARCHAR(255) NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    size_bytes BIGINT NOT NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_task_attachment_task (task_id),
    CONSTRAINT fk_task_attachment_task FOREIGN KEY (task_id) REFERENCES intern_tasks(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  // Báo cáo tuần của thực tập sinh: mỗi intern 1 báo cáo cho mỗi tuần (thứ Hai).
  // is_late = nộp sau hạn (hết Chủ nhật của tuần đó, giờ Việt Nam).
  await pool.query(`CREATE TABLE IF NOT EXISTS weekly_reports (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    intern_id BIGINT NOT NULL,
    week_start DATE NOT NULL,
    content TEXT NOT NULL,
    difficulties TEXT NULL,
    next_plan TEXT NULL,
    is_late TINYINT(1) NOT NULL DEFAULT 0,
    submitted_at DATETIME NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_weekly_report_intern_week (intern_id, week_start),
    CONSTRAINT fk_weekly_report_intern FOREIGN KEY (intern_id) REFERENCES intern_profiles(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await pool.query(`CREATE TABLE IF NOT EXISTS weekly_report_attachments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    report_id BIGINT NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    stored_name VARCHAR(255) NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    size_bytes BIGINT NOT NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_weekly_attachment_report (report_id),
    CONSTRAINT fk_weekly_attachment_report FOREIGN KEY (report_id) REFERENCES weekly_reports(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  // Phản hồi của mentor cho báo cáo tuần: mỗi báo cáo tối đa 1 phản hồi (UNIQUE report_id).
  await pool.query(`CREATE TABLE IF NOT EXISTS weekly_report_feedback (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    report_id BIGINT NOT NULL,
    mentor_id BIGINT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_weekly_feedback_report (report_id),
    INDEX idx_weekly_feedback_mentor (mentor_id),
    CONSTRAINT fk_weekly_feedback_report FOREIGN KEY (report_id) REFERENCES weekly_reports(id) ON DELETE CASCADE,
    CONSTRAINT fk_weekly_feedback_mentor FOREIGN KEY (mentor_id) REFERENCES mentors(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  // Đánh giá tổng kết của mentor cho thực tập sinh: mỗi thực tập sinh tối đa 1 đánh giá (UNIQUE intern_id).
  await pool.query(`CREATE TABLE IF NOT EXISTS intern_evaluations (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    intern_id BIGINT NOT NULL,
    mentor_id BIGINT NULL,
    skill_score TINYINT UNSIGNED NOT NULL,
    skill_comment TEXT NULL,
    attitude_score TINYINT UNSIGNED NOT NULL,
    attitude_comment TEXT NULL,
    overall_comment TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_evaluation_intern (intern_id),
    INDEX idx_evaluation_mentor (mentor_id),
    CONSTRAINT chk_eval_skill CHECK (skill_score BETWEEN 1 AND 5),
    CONSTRAINT chk_eval_attitude CHECK (attitude_score BETWEEN 1 AND 5),
    CONSTRAINT fk_evaluation_intern FOREIGN KEY (intern_id) REFERENCES intern_profiles(id) ON DELETE CASCADE,
    CONSTRAINT fk_evaluation_mentor FOREIGN KEY (mentor_id) REFERENCES mentors(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await pool.query(`CREATE TABLE IF NOT EXISTS attendance_records (
    id BIGINT AUTO_INCREMENT PRIMARY KEY, intern_id BIGINT NOT NULL, work_date DATE NOT NULL,
    check_in_at DATETIME NOT NULL, check_out_at DATETIME NULL, note VARCHAR(255) NULL,
    is_adjusted TINYINT(1) NOT NULL DEFAULT 0,
    correction_status ENUM('PENDING','APPROVED','REJECTED') NULL,
    correction_check_out_at DATETIME NULL, correction_reason VARCHAR(255) NULL,
    correction_requested_at DATETIME NULL, correction_reviewed_by BIGINT NULL,
    correction_reviewed_at DATETIME NULL, correction_review_note VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_attendance_intern_date (intern_id, work_date),
    CONSTRAINT chk_attendance_checkout CHECK (check_out_at IS NULL OR check_out_at >= check_in_at),
    CONSTRAINT fk_attendance_intern FOREIGN KEY (intern_id) REFERENCES intern_profiles(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  // Database cũ: bổ sung các cột bổ sung check-out (đề nghị điều chỉnh giờ ra do quên check-out).
  await ensureColumn("attendance_records", "is_adjusted", "TINYINT(1) NOT NULL DEFAULT 0");
  await ensureColumn("attendance_records", "correction_status", "ENUM('PENDING','APPROVED','REJECTED') NULL");
  await ensureColumn("attendance_records", "correction_check_out_at", "DATETIME NULL");
  await ensureColumn("attendance_records", "correction_reason", "VARCHAR(255) NULL");
  await ensureColumn("attendance_records", "correction_requested_at", "DATETIME NULL");
  await ensureColumn("attendance_records", "correction_reviewed_by", "BIGINT NULL");
  await ensureColumn("attendance_records", "correction_reviewed_at", "DATETIME NULL");
  await ensureColumn("attendance_records", "correction_review_note", "VARCHAR(255) NULL");
  // US8: mẫu lịch làm việc, phạm vi áp dụng và ngày nghỉ chung.
  await pool.query(`CREATE TABLE IF NOT EXISTS work_schedules (
    id BIGINT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(150) NOT NULL UNIQUE,
    description TEXT NULL, mode ENUM('FIXED','FLEXIBLE') NOT NULL,
    grace_minutes INT NOT NULL DEFAULT 15, min_daily_minutes INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await pool.query(`CREATE TABLE IF NOT EXISTS work_schedule_days (
    schedule_id BIGINT NOT NULL, weekday TINYINT NOT NULL, is_working TINYINT(1) NOT NULL DEFAULT 0,
    start_time TIME NULL, end_time TIME NULL, PRIMARY KEY(schedule_id, weekday),
    CONSTRAINT fk_work_schedule_day FOREIGN KEY(schedule_id) REFERENCES work_schedules(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await pool.query(`CREATE TABLE IF NOT EXISTS work_schedule_assignments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY, schedule_id BIGINT NOT NULL,
    target_type ENUM('DEFAULT','UNIVERSITY','PROGRAM','MENTOR','INTERN') NOT NULL,
    target_value VARCHAR(255) NOT NULL DEFAULT '', effective_from DATE NOT NULL, effective_to DATE NULL,
    created_by BIGINT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_schedule_assignment_lookup(target_type,target_value,effective_from,effective_to),
    UNIQUE KEY uq_schedule_assignment_start(target_type,target_value,effective_from),
    CONSTRAINT fk_work_schedule_assignment FOREIGN KEY(schedule_id) REFERENCES work_schedules(id) ON DELETE RESTRICT,
    CONSTRAINT fk_work_schedule_creator FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await pool.query(`CREATE TABLE IF NOT EXISTS work_holidays (
    id BIGINT AUTO_INCREMENT PRIMARY KEY, holiday_date DATE NOT NULL UNIQUE, name VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await pool.query(`CREATE TABLE IF NOT EXISTS program_interns (
    id BIGINT AUTO_INCREMENT PRIMARY KEY, program_id BIGINT NOT NULL, intern_id BIGINT NOT NULL, assigned_by BIGINT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_program_intern (program_id,intern_id), INDEX idx_program_intern_intern (intern_id),
    CONSTRAINT fk_pi_program FOREIGN KEY(program_id) REFERENCES internship_programs(id) ON DELETE CASCADE,
    CONSTRAINT fk_pi_intern FOREIGN KEY(intern_id) REFERENCES intern_profiles(id) ON DELETE CASCADE,
    CONSTRAINT fk_pi_user FOREIGN KEY(assigned_by) REFERENCES users(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await require("./services/programCompletionMigration").migrateProgramCompletion(pool);
  await pool.query(`CREATE TABLE IF NOT EXISTS leave_requests (
    id BIGINT AUTO_INCREMENT PRIMARY KEY, intern_id BIGINT NOT NULL,
    leave_type ENUM('SICK','PERSONAL','EXAM','OTHER') NOT NULL, from_date DATE NOT NULL, to_date DATE NOT NULL,
    reason VARCHAR(500) NOT NULL, status ENUM('PENDING','APPROVED','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING',
    reviewed_by BIGINT NULL, reviewed_at DATETIME NULL, review_note VARCHAR(500) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_leave_intern_dates(intern_id,from_date,to_date,status),
    CONSTRAINT fk_leave_intern FOREIGN KEY(intern_id) REFERENCES intern_profiles(id) ON DELETE CASCADE,
    CONSTRAINT fk_leave_reviewer FOREIGN KEY(reviewed_by) REFERENCES users(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  // Phụ cấp thực tập sinh do HR nhập (một khoản = loại + số tiền VND + chu kỳ + khoảng hiệu lực).
  await pool.query(`CREATE TABLE IF NOT EXISTS intern_allowances (
    id BIGINT AUTO_INCREMENT PRIMARY KEY, intern_id BIGINT NOT NULL,
    allowance_type ENUM('MEAL','TRANSPORT','PHONE','HOUSING','OTHER') NOT NULL,
    amount DECIMAL(12,0) NOT NULL, pay_cycle ENUM('MONTHLY','DAILY','ONE_TIME') NOT NULL,
    effective_from DATE NOT NULL, effective_to DATE NULL, note VARCHAR(500) NULL,
    created_by BIGINT NULL, updated_by BIGINT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_allowance_intern (intern_id, allowance_type, effective_from),
    CONSTRAINT chk_allowance_amount CHECK (amount > 0),
    CONSTRAINT chk_allowance_range CHECK (effective_to IS NULL OR effective_to >= effective_from),
    CONSTRAINT fk_allowance_intern FOREIGN KEY (intern_id) REFERENCES intern_profiles(id) ON DELETE CASCADE,
    CONSTRAINT fk_allowance_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_allowance_updater FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await pool.query(`CREATE TABLE IF NOT EXISTS support_requests (
    id BIGINT AUTO_INCREMENT PRIMARY KEY, intern_id BIGINT NOT NULL,
    request_type ENUM('INTERNSHIP_CERTIFICATE','INTRODUCTION_LETTER','INCOME_CONFIRMATION','DOCUMENT_SUPPORT','OTHER') NOT NULL,
    title VARCHAR(150) NOT NULL, description VARCHAR(2000) NOT NULL DEFAULT '',
    status ENUM('PENDING','IN_PROGRESS','RESOLVED','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING',
    handled_by BIGINT NULL, resolution_note VARCHAR(1000) NULL, resolved_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_support_intern_status (intern_id,status), INDEX idx_support_status_created (status,created_at),
    CONSTRAINT fk_support_intern FOREIGN KEY (intern_id) REFERENCES intern_profiles(id) ON DELETE CASCADE,
    CONSTRAINT fk_support_handler FOREIGN KEY (handled_by) REFERENCES users(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await pool.query(`CREATE TABLE IF NOT EXISTS support_request_attachments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY, request_id BIGINT NOT NULL,
    kind ENUM('REQUEST','RESULT') NOT NULL, original_name VARCHAR(255) NOT NULL,
    stored_name CHAR(36) NOT NULL, mime_type VARCHAR(150) NOT NULL, size_bytes BIGINT UNSIGNED NOT NULL,
    uploaded_by BIGINT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_support_attachment_request (request_id,kind),
    CONSTRAINT fk_support_attachment_request FOREIGN KEY (request_id) REFERENCES support_requests(id) ON DELETE CASCADE,
    CONSTRAINT fk_support_attachment_uploader FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  await pool.query(`CREATE TABLE IF NOT EXISTS notifications (
    id BIGINT AUTO_INCREMENT PRIMARY KEY, user_id BIGINT NOT NULL, type VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL, message VARCHAR(500) NOT NULL, target_tab VARCHAR(80) NULL,
    ref_id BIGINT NULL, is_read TINYINT(1) NOT NULL DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    dedupe_key VARCHAR(120) NULL,
    INDEX idx_notifications_user (user_id,is_read,created_at),
    UNIQUE KEY uq_notification_dedupe (user_id,dedupe_key),
    CONSTRAINT fk_notification_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  // Bảng đã tạo từ phiên bản cũ: bổ sung cột / khóa chống trùng cho thông báo nhắc lịch
  await ensureColumn("notifications", "dedupe_key", "VARCHAR(120) NULL");
  const [dedupeIdx] = await pool.query(
    "SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'notifications' AND INDEX_NAME = 'uq_notification_dedupe' LIMIT 1",
    [config.database],
  );
  if (!dedupeIdx.length) await pool.query("ALTER TABLE notifications ADD UNIQUE KEY uq_notification_dedupe (user_id, dedupe_key)");
  await pool.query("INSERT IGNORE INTO work_schedules (id,name,description,mode,grace_minutes) VALUES (1,'Lịch mặc định','Lịch làm việc mặc định toàn hệ thống','FIXED',15)");
  await pool.query("INSERT IGNORE INTO work_schedule_days (schedule_id,weekday,is_working,start_time,end_time) VALUES (1,1,1,'08:30','17:30'),(1,2,1,'08:30','17:30'),(1,3,1,'08:30','17:30'),(1,4,1,'08:30','17:30'),(1,5,1,'08:30','17:30'),(1,6,0,NULL,NULL),(1,7,0,NULL,NULL)");
  // Bản cũ không có khóa duy nhất nên INSERT IGNORE bên dưới thêm một dòng "Mặc định" mới sau mỗi lần khởi động.
  // Dọn các dòng trùng (giữ dòng có id nhỏ nhất) rồi thêm khóa để không lặp lại.
  await pool.query(`DELETE a FROM work_schedule_assignments a JOIN work_schedule_assignments b
    ON a.target_type=b.target_type AND a.target_value=b.target_value AND a.effective_from=b.effective_from AND a.id>b.id`);
  try {
    await pool.query("ALTER TABLE work_schedule_assignments ADD UNIQUE KEY uq_schedule_assignment_start(target_type,target_value,effective_from)");
  } catch (err) {
    if (err.code !== "ER_DUP_KEYNAME") throw err; // đã có khóa (database mới hoặc đã chạy trước đó)
  }
  await pool.query("INSERT IGNORE INTO work_schedule_assignments (schedule_id,target_type,target_value,effective_from) VALUES (1,'DEFAULT','','1970-01-01')");
  await pool.query(`CREATE TABLE IF NOT EXISTS final_reports (
    id BIGINT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(255) NOT NULL,
    scope_type ENUM('ALL','UNIVERSITY','PROGRAM') NOT NULL, scope_value VARCHAR(255) NULL,
    period_from DATE NULL, period_to DATE NULL,
    status ENUM('DRAFT','FINALIZED') NOT NULL DEFAULT 'DRAFT', hr_note TEXT NULL,
    snapshot_json LONGTEXT NULL, created_by BIGINT NULL, finalized_by BIGINT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, finalized_at DATETIME NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_final_report_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_final_report_finalizer FOREIGN KEY (finalized_by) REFERENCES users(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  // Lịch sử gửi báo cáo cuối kỳ (mỗi lần gửi email thành công là một dòng).
  await pool.query(`CREATE TABLE IF NOT EXISTS final_report_sends (
    id BIGINT AUTO_INCREMENT PRIMARY KEY, report_id BIGINT NOT NULL, sent_by BIGINT NULL,
    recipients TEXT NOT NULL, message VARCHAR(1000) NULL,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_final_report_sends_report (report_id, sent_at),
    CONSTRAINT fk_final_report_send_report FOREIGN KEY (report_id) REFERENCES final_reports(id) ON DELETE CASCADE,
    CONSTRAINT fk_final_report_send_user FOREIGN KEY (sent_by) REFERENCES users(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  // Danh sách email người nhận đã dùng, gợi ý theo phạm vi báo cáo (scope_value rỗng = phạm vi ALL).
  await pool.query(`CREATE TABLE IF NOT EXISTS final_report_recipients (
    id BIGINT AUTO_INCREMENT PRIMARY KEY, email VARCHAR(254) NOT NULL,
    scope_type ENUM('ALL','UNIVERSITY','PROGRAM') NOT NULL, scope_value VARCHAR(255) NOT NULL DEFAULT '',
    created_by BIGINT NULL, last_used_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_final_report_recipient (email, scope_type, scope_value),
    CONSTRAINT fk_final_report_recipient_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

  await seedDepartmentsFromMentors(pool);

  // Seed dữ liệu mặc định: roles, permissions, role_permissions
  await pool.query(`
    INSERT IGNORE INTO roles (id, role_name, description) VALUES
    (1, 'Admin', 'Quản trị viên toàn quyền hệ thống'),
    (2, 'HR', 'Quản lý nhân sự & tuyển dụng thực tập sinh'),
    (3, 'Mentor', 'Người hướng dẫn thực tập sinh'),
    (4, 'Intern', 'Thực tập sinh tham gia chương trình');
  `);

  await pool.query(`
    INSERT IGNORE INTO permissions (id, perm_code, perm_name, description) VALUES
    (1, 'MANAGE_USERS', 'Quản lý tài khoản', 'Tạo, sửa, xóa tài khoản người dùng'),
    (2, 'ASSIGN_TASKS', 'Giao nhiệm vụ & Task', 'Phân công nhiệm vụ cho thực tập sinh'),
    (3, 'SUBMIT_WORK', 'Nộp báo cáo công việc', 'Thực tập sinh gửi báo cáo/tiến độ'),
    (4, 'VIEW_REPORTS', 'Xem báo cáo & Thống kê', 'Xem số liệu thống kê đào tạo'),
    (5, 'SYSTEM_SETTINGS', 'Cài đặt hệ thống', 'Cấu hình phân quyền và hệ thống');
  `);

  await pool.query(`
    INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES
    (1, 1), (1, 5),
    (2, 4),
    (3, 2);
  `);

  isMysqlConnected = true;
  console.log(
    `[DATABASE] Đã kết nối MySQL thành công tới database '${config.database}'!`,
  );

  // Seed tài khoản mẫu mặc định (mật khẩu: password123)
  await seedDefaultAccounts();
  await syncMentorsWithAccounts();
  await syncInternsWithAccounts();
}

async function seedDefaultAccounts() {
  if (process.env.NODE_ENV === "production") {
    console.log("[DATABASE] NODE_ENV=production: bỏ qua seed tài khoản mẫu.");
    return;
  }
  const defaultPassHash = await hashPassword("password123");
  const defaultAccounts = [
    { name: "Admin", email: "admin@gmail.com", role: "Admin" },
    { name: "Hr", email: "hr@company.com", role: "HR" },
    { name: "Mentor", email: "mentor@gmail.com", role: "Mentor" },
    { name: "Intern", email: "intern@gmail.com", role: "Intern" },
  ];

  for (const acc of defaultAccounts) {
    const existing = await findUserByEmail(acc.email);
    if (!existing) {
      await insertUser({
        name: acc.name,
        email: acc.email,
        password_hash: defaultPassHash,
        role: acc.role,
        status: "ACTIVE",
      });
    }
  }
}

async function findUserByEmail(email) {
  const db = requireDb();
  const [rows] = await db.query(
    `SELECT u.*, r.role_name AS role
     FROM users u
     JOIN roles r ON u.role_id = r.id
     WHERE LOWER(u.email) = LOWER(?) LIMIT 1`,
    [email],
  );
  return rows[0] || null;
}

// Tra cứu theo account, email hoặc id (dùng khi đăng nhập)
async function findUserForLogin(account) {
  const db = requireDb();
  const [rows] = await db.query(
    `SELECT u.*, r.role_name AS role
     FROM users u
     JOIN roles r ON u.role_id = r.id
     WHERE LOWER(u.email) = LOWER(?) OR LOWER(u.name) = LOWER(?) OR u.id = ?
     LIMIT 1`,
    [account, account, isNaN(Number(account)) ? 0 : Number(account)],
  );
  return rows[0] || null;
}

async function insertUser({
  name,
  email,
  password_hash,
  role,
  status = "ACTIVE",
}) {
  const roleId = await getRoleId(role);

  const insertId = await withTransaction(async (conn) => {
    const [result] = await conn.query(
      "INSERT INTO users (name, email, password_hash, role_id, status) VALUES (?, ?, ?, ?, ?)",
      [name, email, password_hash, roleId, status],
    );
    // Đồng bộ: tài khoản Mentor luôn có hồ sơ tương ứng trong bảng mentors
    if (role === "Mentor") {
      await conn.query(
        `INSERT INTO mentors (full_name, email, phone, department, specialization)
         VALUES (?, ?, '', ?, '')
         ON DUPLICATE KEY UPDATE id = id`,
        [name, email, DEFAULT_MENTOR_DEPARTMENT],
      );
    }
    // Đồng bộ: tài khoản Intern chính thức luôn có hồ sơ trong bảng intern_profiles
    if (role === "Intern" && !NON_INTERN_ACCOUNT_STATUSES.includes(status)) {
      await conn.query(
        `INSERT INTO intern_profiles
           (student_code, full_name, email, phone, university, major, mentor_name, status)
         VALUES ('', ?, ?, '', ?, '', '', ?)
         ON DUPLICATE KEY UPDATE id = id`,
        [name, email, DEFAULT_INTERN_UNIVERSITY, DEFAULT_INTERN_STATUS],
      );
    }
    return result.insertId;
  });

  return {
    id: insertId,
    name,
    email,
    password_hash,
    role,
    status,
    createdAt: nowISO(),
  };
}

async function getAllUsers() {
  const db = requireDb();
  const [rows] = await db.query(
    `SELECT u.id, u.name, u.email, r.role_name AS role, u.status, u.phone,
            u.created_at AS createdAt
     FROM users u
     JOIN roles r ON u.role_id = r.id
     ORDER BY u.id DESC`,
  );
  return rows;
}

async function deleteUser(id) {
  const storedNames = await withProgramMembershipTransaction(async (conn) => {
    const [users] = await conn.query(
      `SELECT u.email, r.role_name AS role
       FROM users u JOIN roles r ON u.role_id = r.id
       WHERE u.id = ?`,
      [id],
    );
    if (users.length === 0) return [];

    const user = users[0];
    if (user.role === "Intern") {
      const [profiles] = await conn.query("SELECT id FROM intern_profiles WHERE LOWER(email) COLLATE utf8mb4_unicode_ci=LOWER(?) COLLATE utf8mb4_unicode_ci",[user.email]);
      for (const profile of profiles) await assertNoFinalizedProgramResults(conn,profile.id);
    }
    let contracts = [];
    if (user.role === "Mentor") {
      await conn.query("DELETE FROM mentors WHERE LOWER(email) = LOWER(?)", [
        user.email,
      ]);
    }
    if (user.role === "Intern") {
      const [rows] = await conn.query(
        `SELECT c.stored_name AS storedName,
                c.confirmation_status AS confirmationStatus
         FROM internship_contracts c
         JOIN intern_profiles i ON i.id = c.intern_id
         WHERE LOWER(i.email) = LOWER(?) FOR UPDATE`,
        [user.email],
      );
      if (
        rows.some((contract) => contract.confirmationStatus === "CONFIRMED")
      ) {
        throw new ConflictError(
          "Không thể xóa tài khoản Intern vì hồ sơ có hợp đồng đã được xác nhận!",
          409,
        );
      }
      contracts = rows;
      await conn.query(
        "DELETE FROM intern_profiles WHERE LOWER(email) = LOWER(?)",
        [user.email],
      );
    }

    await conn.query("DELETE FROM users WHERE id = ?", [id]);
    return contracts.map((contract) => contract.storedName);
  });

  // Chỉ xóa file sau khi transaction đã commit thành công.
  storedNames.forEach((storedName) => fileStorage.removeFile(storedName));
  return true;
}

async function insertCandidate({
  name,
  email,
  phone,
  university,
  major,
  cvLink,
  password_hash,
  status = "Chờ duyệt",
}) {
  const roleId = await getRoleId("Intern");

  // Tạo tài khoản + hồ sơ ứng tuyển trong 1 transaction: lỗi ở bước nào cũng rollback,
  // không để lại tài khoản mồ côi.
  const { id, userId } = await withTransaction(async (conn) => {
    const [userResult] = await conn.query(
      "INSERT INTO users (name, email, password_hash, role_id, status) VALUES (?, ?, ?, ?, 'PENDING')",
      [name, email, password_hash, roleId],
    );
    const newUserId = userResult.insertId;

    const [candResult] = await conn.query(
      `INSERT INTO candidate_profiles
        (user_id, full_name, email, phone, university, major, cv_link, password_hash, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        newUserId,
        name,
        email,
        phone,
        university,
        major || "",
        cvLink || "",
        password_hash,
        status,
      ],
    );
    return { id: candResult.insertId, userId: newUserId };
  });

  return {
    id,
    userId,
    name,
    email,
    phone,
    university,
    major: major || "Chưa cập nhật",
    cvLink: cvLink || "",
    status,
    createdAt: nowISO(),
  };
}

// Ứng viên bị TỪ CHỐI được nộp lại: dùng lại đúng hồ sơ + tài khoản cũ (email là duy nhất),
// đặt về "Chờ duyệt", xóa lý do từ chối / người duyệt và mở khóa tài khoản.
// Trả về hồ sơ mới, hoặc null nếu email này không có hồ sơ ở trạng thái "Từ chối".
async function reapplyRejectedCandidate({
  name,
  email,
  phone,
  university,
  major,
  cvLink,
  password_hash,
}) {
  return withTransaction(async (conn) => {
    const [rows] = await conn.query(
      `SELECT id, user_id AS userId, status FROM candidate_profiles
       WHERE LOWER(email) = LOWER(?) FOR UPDATE`,
      [email],
    );
    const candidate = rows[0];
    if (!candidate || candidate.status !== "Từ chối") return null;

    await conn.query(
      `UPDATE candidate_profiles
         SET full_name = ?, phone = ?, university = ?, major = ?, cv_link = ?,
             password_hash = ?, status = 'Chờ duyệt', rejection_reason = NULL,
             reviewed_by = NULL, reviewed_at = NULL, applied_at = NOW()
       WHERE id = ?`,
      [name, phone, university, major || "", cvLink || "", password_hash, candidate.id],
    );
    if (candidate.userId) {
      await conn.query(
        "UPDATE users SET name = ?, phone = ?, password_hash = ?, status = 'PENDING' WHERE id = ?",
        [name, phone, password_hash, candidate.userId],
      );
    }
    return {
      id: candidate.id,
      userId: candidate.userId,
      name,
      email,
      phone,
      university,
      major: major || "Chưa cập nhật",
      cvLink: cvLink || "",
      status: "Chờ duyệt",
      createdAt: nowISO(),
    };
  });
}

const APPLICATION_COLUMNS = `
  id, user_id AS userId, full_name AS name, email, phone, university, major,
  cv_link AS cvLink, status, rejection_reason AS rejectionReason,
  reviewed_by AS reviewedBy, reviewed_at AS reviewedAt, applied_at AS createdAt`;

async function listApplications() {
  const [rows] = await requireDb().query(
    `SELECT ${APPLICATION_COLUMNS} FROM candidate_profiles ORDER BY id DESC`,
  );
  return rows;
}

// Hồ sơ ứng tuyển khớp theo email (liên kết hồ sơ thực tập sinh <-> tài liệu); email so sánh không phân biệt hoa thường
async function findApplicationsByEmails(emails) {
  if (!Array.isArray(emails) || emails.length === 0) return [];
  const [rows] = await requireDb().query(
    `SELECT ${APPLICATION_COLUMNS} FROM candidate_profiles WHERE LOWER(email) IN (?)`,
    [emails],
  );
  return rows;
}

async function findApplicationById(id) {
  const [rows] = await requireDb().query(
    `SELECT ${APPLICATION_COLUMNS} FROM candidate_profiles WHERE id = ?`,
    [id],
  );
  return rows[0] || null;
}

// Đổi trạng thái ATOMIC: chỉ cập nhật khi hồ sơ còn 'Chờ duyệt'.
// Trả về hồ sơ sau cập nhật, hoặc null nếu không có dòng nào được đổi
// (không tồn tại hoặc đã được người khác xử lý trước).
async function reviewApplicationAtomic({
  id,
  newStatus, // 'Đã duyệt' | 'Từ chối'
  rejectionReason,
  reviewerId,
  requiredDocs = 0, // > 0: chỉ đổi khi hồ sơ có ĐỦ ngần ấy loại tài liệu (kiểm tra trong cùng câu UPDATE)
}) {
  return withTransaction(async (conn) => {
    const [result] = await conn.query(
      `UPDATE candidate_profiles
         SET status = ?, rejection_reason = ?, reviewed_by = ?, reviewed_at = NOW()
       WHERE id = ? AND status = 'Chờ duyệt'
         AND (? = 0 OR (SELECT COUNT(DISTINCT doc_type) FROM application_documents
                        WHERE application_id = ?) >= ?)`,
      [
        newStatus,
        rejectionReason,
        reviewerId,
        id,
        requiredDocs,
        id,
        requiredDocs,
      ],
    );
    if (result.affectedRows === 0) return null;

    const [rows] = await conn.query(
      `SELECT ${APPLICATION_COLUMNS} FROM candidate_profiles WHERE id = ?`,
      [id],
    );
    const application = rows[0];

    // Đồng bộ tài khoản đăng nhập của ứng viên
    if (application.userId) {
      await conn.query("UPDATE users SET status = ? WHERE id = ?", [
        newStatus === "Đã duyệt" ? "ACTIVE" : "LOCKED",
        application.userId,
      ]);
    }

    // Được duyệt -> trở thành thực tập sinh chính thức
    if (newStatus === "Đã duyệt") {
      await conn.query(
        `INSERT INTO intern_profiles
           (student_code, full_name, email, phone, university, major, mentor_name, status)
         VALUES ('', ?, ?, ?, ?, ?, '', ?)
         ON DUPLICATE KEY UPDATE id = id`,
        [
          application.name,
          application.email,
          application.phone || "",
          application.university || DEFAULT_INTERN_UNIVERSITY,
          application.major || "",
          DEFAULT_INTERN_STATUS,
        ],
      );
    }
    return application;
  });
}

async function getAllMentors() {
  const db = requireDb();
  const [rows] = await db.query(
    `SELECT m.id, m.full_name AS fullName, m.email, m.phone, m.department, m.specialization,
            m.created_at AS createdAt,
            (SELECT COUNT(*) FROM intern_profiles ip WHERE ip.mentor_id = m.id
               AND (ip.status IS NULL OR ip.status = ?)) AS activeInterns
     FROM mentors m ORDER BY m.id DESC`,
    [DEFAULT_INTERN_STATUS],
  );
  return rows.map((r) => ({ ...r, activeInterns: Number(r.activeInterns) }));
}

// Đảm bảo mỗi hồ sơ (mentor / thực tập sinh) có ĐÚNG 1 tài khoản cùng vai trò khớp email/họ tên/SĐT.
// oldEmail = email hiện tại của hồ sơ trước khi đổi (bằng email mới nếu là tạo mới).
async function upsertProfileAccount(
  conn,
  roleName,
  { oldEmail, fullName, email, phone },
) {
  const roleId = await getRoleId(roleName);
  const [current] = await conn.query(
    "SELECT id FROM users WHERE LOWER(email) = LOWER(?) AND role_id = ? LIMIT 1",
    [oldEmail, roleId],
  );
  const [target] = await conn.query(
    `SELECT u.id, r.role_name AS role
     FROM users u JOIN roles r ON u.role_id = r.id
     WHERE LOWER(u.email) = LOWER(?) LIMIT 1`,
    [email],
  );

  if (current.length > 0) {
    if (target.length > 0 && target[0].id !== current[0].id) {
      throw new ConflictError("Email này đã được dùng cho một tài khoản khác!");
    }
    await conn.query(
      "UPDATE users SET name = ?, email = ?, phone = ? WHERE id = ?",
      [fullName, email, phone || null, current[0].id],
    );
  } else if (target.length > 0) {
    if (target[0].role !== roleName) {
      throw new ConflictError(
        `Email này đã được dùng cho tài khoản vai trò ${target[0].role}!`,
      );
    }
    await conn.query("UPDATE users SET name = ?, phone = ? WHERE id = ?", [
      fullName,
      phone || null,
      target[0].id,
    ]);
  } else {
    const passwordHash = await hashPassword(DEFAULT_ACCOUNT_PASSWORD);
    await conn.query(
      `INSERT INTO users (name, email, password_hash, role_id, phone, status)
       VALUES (?, ?, ?, ?, ?, 'ACTIVE')`,
      [fullName, email, passwordHash, roleId, phone || null],
    );
  }
}

// Tạo mentor, kèm tài khoản Mentor tương ứng nếu chưa có
async function insertMentor({
  fullName,
  email,
  phone,
  department,
  specialization,
}) {
  const insertId = await withTransaction(async (conn) => {
    const [result] = await conn.query(
      "INSERT INTO mentors (full_name, email, phone, department, specialization) VALUES (?, ?, ?, ?, ?)",
      [fullName, email, phone || "", department || "", specialization || ""],
    );
    await upsertProfileAccount(conn, "Mentor", {
      oldEmail: email,
      fullName,
      email,
      phone,
    });
    return result.insertId;
  });
  return {
    id: insertId,
    fullName,
    email,
    phone: phone || "",
    department: department || "",
    specialization: specialization || "",
    createdAt: nowISO(),
  };
}

// Đồng bộ họ tên/email/SĐT sang tài khoản Mentor
async function updateMentor(
  id,
  { fullName, email, phone, department, specialization },
) {
  return withTransaction(async (conn) => {
    const [oldRows] = await conn.query(
      "SELECT email FROM mentors WHERE id = ? FOR UPDATE",
      [id],
    );
    if (oldRows.length === 0) return null;

    const [dup] = await conn.query(
      "SELECT id FROM mentors WHERE LOWER(email) = LOWER(?) AND id <> ?",
      [email, id],
    );
    if (dup.length > 0) {
      throw new ConflictError("Email mentor này đã tồn tại trong hệ thống!");
    }

    await conn.query(
      "UPDATE mentors SET full_name = ?, email = ?, phone = ?, department = ?, specialization = ? WHERE id = ?",
      [
        fullName,
        email,
        phone || "",
        department || "",
        specialization || "",
        id,
      ],
    );
    await upsertProfileAccount(conn, "Mentor", {
      oldEmail: oldRows[0].email,
      fullName,
      email,
      phone,
    });
    await conn.query(
      "UPDATE intern_profiles SET mentor_name = ? WHERE mentor_id = ?",
      [fullName, id],
    );

    const [rows] = await conn.query(
      `SELECT id, full_name AS fullName, email, phone, department, specialization,
              created_at AS createdAt
       FROM mentors WHERE id = ?`,
      [id],
    );
    return rows[0] || null;
  });
}

// Xóa mentor kèm tài khoản Mentor tương ứng
async function deleteMentor(id) {
  const mentorRoleId = await getRoleId("Mentor");
  await withTransaction(async (conn) => {
    const [rows] = await conn.query(
      "SELECT email FROM mentors WHERE id = ? FOR UPDATE",
      [id],
    );
    await conn.query(
      "UPDATE intern_profiles SET mentor_id = NULL, mentor_name = '' WHERE mentor_id = ?",
      [id],
    );
    await conn.query("DELETE FROM mentors WHERE id = ?", [id]);
    if (rows.length > 0) {
      await conn.query(
        "DELETE FROM users WHERE LOWER(email) = LOWER(?) AND role_id = ?",
        [rows[0].email, mentorRoleId],
      );
    }
  });
  return true;
}

// ĐỒNG BỘ TOÀN BỘ dữ liệu cũ giữa bảng users (vai trò Mentor) và bảng mentors.
async function syncMentorsWithAccounts() {
  const db = requireDb();
  const mentorRoleId = await getRoleId("Mentor");
  const defaultHash = await hashPassword(DEFAULT_ACCOUNT_PASSWORD);

  // 1. Tài khoản Mentor chưa có hồ sơ -> tạo hồ sơ mentor
  await db.query(
    `INSERT INTO mentors (full_name, email, phone, department, specialization)
     SELECT u.name, u.email, COALESCE(u.phone, ''), ?, ''
     FROM users u
     WHERE u.role_id = ?
       AND NOT EXISTS (SELECT 1 FROM mentors m WHERE LOWER(m.email) = LOWER(u.email))`,
    [DEFAULT_MENTOR_DEPARTMENT, mentorRoleId],
  );

  // 2. Hồ sơ mentor chưa có tài khoản -> tạo tài khoản Mentor
  await db.query(
    `INSERT INTO users (name, email, password_hash, role_id, phone, status)
     SELECT m.full_name, m.email, ?, ?, NULLIF(m.phone, ''), 'ACTIVE'
     FROM mentors m
     WHERE NOT EXISTS (SELECT 1 FROM users u WHERE LOWER(u.email) = LOWER(m.email))`,
    [defaultHash, mentorRoleId],
  );

  // 3. Hồ sơ đã có SĐT trống mà tài khoản có SĐT -> bổ sung sang hồ sơ
  await db.query(
    `UPDATE mentors m JOIN users u ON LOWER(u.email) = LOWER(m.email)
     SET m.phone = u.phone
     WHERE u.role_id = ? AND (m.phone IS NULL OR m.phone = '')
       AND u.phone IS NOT NULL AND u.phone <> ''`,
    [mentorRoleId],
  );

  // 4. Cặp đã khớp email -> đưa họ tên & SĐT của tài khoản về giống hồ sơ mentor
  await db.query(
    `UPDATE users u JOIN mentors m ON LOWER(m.email) = LOWER(u.email)
     SET u.name = m.full_name, u.phone = NULLIF(m.phone, '')
     WHERE u.role_id = ?
       AND (u.name <> m.full_name OR NOT (u.phone <=> NULLIF(m.phone, '')))`,
    [mentorRoleId],
  );

  // 5. Cảnh báo các mentor trùng email với tài khoản thuộc vai trò khác
  const [conflicts] = await db.query(
    `SELECT m.email, r.role_name AS role
     FROM mentors m
     JOIN users u ON LOWER(u.email) = LOWER(m.email)
     JOIN roles r ON r.id = u.role_id
     WHERE u.role_id <> ?`,
    [mentorRoleId],
  );
  conflicts.forEach((c) =>
    console.warn(
      `[SYNC] Cảnh báo: mentor '${c.email}' trùng email với tài khoản vai trò ${c.role}, cần xử lý thủ công.`,
    ),
  );
}

async function getAllStudents({
  includeContractCount = false,
  filters = {},
} = {}) {
  const { buildInternFilterConditions } = require("./utils/internFilters");
  const { whereSql, params } = buildInternFilterConditions(filters);
  const [rows] = await requireDb().query(
    `SELECT ip.id, ip.student_code AS studentCode, ip.full_name AS fullName, ip.email, ip.phone,
            ip.university, ip.major, ip.mentor_name AS mentorName, ip.mentor_id AS mentorId,
            ip.status, ip.created_at AS createdAt
            ${includeContractCount ? `, (SELECT COUNT(*) FROM internship_contracts c WHERE c.intern_id = ip.id) AS contract_count` : ""}
     FROM intern_profiles ip ${whereSql} ORDER BY ip.id DESC`,
    params,
  );
  return rows;
}

async function getStudentsForMentorEmail(email, filters = {}) {
  const { buildInternFilterConditions } = require("./utils/internFilters");
  const { whereSql, params } = buildInternFilterConditions(filters);
  const [rows] = await requireDb().query(
    `SELECT ip.id, ip.student_code AS studentCode, ip.full_name AS fullName,
            ip.email, ip.phone, ip.university, ip.major,
            ip.mentor_name AS mentorName, ip.mentor_id AS mentorId,
            ip.status, ip.created_at AS createdAt
     FROM intern_profiles ip JOIN mentors m ON m.id = ip.mentor_id
     ${whereSql ? `${whereSql} AND` : "WHERE"} LOWER(m.email) = LOWER(?)
     ORDER BY ip.id DESC`,
    [...params, email],
  );
  return rows;
}

async function getInternFilterOptions({ university = "" } = {}) {
  const database = requireDb();
  const [universities] = await database.query(
    `SELECT DISTINCT TRIM(university) AS value FROM intern_profiles
     WHERE university IS NOT NULL AND TRIM(university) <> ''
     ORDER BY value COLLATE utf8mb4_unicode_ci`,
  );
  const universityCondition = university
    ? " AND CONVERT(university USING utf8mb4) COLLATE utf8mb4_unicode_ci = CONVERT(? USING utf8mb4) COLLATE utf8mb4_unicode_ci"
    : "";
  const [majors] = await database.query(
    `SELECT DISTINCT TRIM(major) AS value FROM intern_profiles
     WHERE major IS NOT NULL AND TRIM(major) <> ''${universityCondition}
     ORDER BY value COLLATE utf8mb4_unicode_ci`,
    university ? [university] : [],
  );
  return {
    universities: universities.map((row) => row.value),
    majors: majors.map((row) => row.value),
  };
}

async function countInterns({ unassigned = false } = {}) {
  const whereSql = unassigned ? "WHERE mentor_id IS NULL" : "";
  const [rows] = await requireDb().query(
    `SELECT COUNT(*) AS count FROM intern_profiles ${whereSql}`,
  );
  return Number(rows[0]?.count) || 0;
}

async function assignInternMentor(internId, mentorId) {
  try {
    return await withTransaction(async (conn) => {
      let mentorName = "";
      if (mentorId != null) {
        const [mentorRows] = await conn.query(
          "SELECT full_name FROM mentors WHERE id = ? FOR UPDATE",
          [mentorId],
        );
        if (mentorRows.length === 0) return { outcome: "MENTOR_NOT_FOUND" };
        mentorName = mentorRows[0].full_name;
      }

      // Khóa mentor rồi đến intern, cùng thứ tự với luồng xóa để tránh race/deadlock.
      const [internRows] = await conn.query(
        "SELECT id FROM intern_profiles WHERE id = ? FOR UPDATE",
        [internId],
      );
      if (internRows.length === 0) return { outcome: "INTERN_NOT_FOUND" };

      await conn.query(
        "UPDATE intern_profiles SET mentor_id = ?, mentor_name = ? WHERE id = ?",
        [mentorId, mentorName, internId],
      );
      return {
        outcome: "UPDATED",
        student: { id: internId, mentorId, mentorName },
      };
    });
  } catch (err) {
    if (mentorId != null && err.code === "ER_NO_REFERENCED_ROW_2") {
      return { outcome: "MENTOR_NOT_FOUND" };
    }
    throw err;
  }
}

// Tạo hồ sơ thực tập sinh, kèm tài khoản Intern tương ứng nếu chưa có
async function insertStudent({
  studentCode,
  fullName,
  email,
  phone,
  university,
  major,
  mentorName,
  status,
}) {
  const finalStatus = status || DEFAULT_INTERN_STATUS;

  const inserted = await withTransaction(async (conn) => {
    const [mentorRows] = await conn.query(
      `SELECT id, full_name AS fullName FROM mentors
       WHERE LOWER(TRIM(full_name)) = LOWER(TRIM(?)) LIMIT 2`,
      [mentorName || ""],
    );
    const mentorId = resolveUniqueMentorId(mentorName, mentorRows);
    const [result] = await conn.query(
      "INSERT INTO intern_profiles (student_code, full_name, email, phone, university, major, mentor_name, mentor_id, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
      [
        studentCode || "",
        fullName,
        email,
        phone || "",
        university || "",
        major || "",
        mentorName || "",
        mentorId,
        finalStatus,
      ],
    );
    await upsertProfileAccount(conn, "Intern", {
      oldEmail: email,
      fullName,
      email,
      phone,
    });
    return { id: result.insertId, mentorId };
  });

  return {
    id: inserted.id,
    studentCode: studentCode || "",
    fullName,
    email,
    phone: phone || "",
    university: university || "",
    major: major || "",
    mentorName: mentorName || "",
    mentorId: inserted.mentorId,
    status: finalStatus,
    createdAt: nowISO(),
  };
}

// CHỈNH SỬA HỒ SƠ THỰC TẬP SINH (chỉ cập nhật field nào được truyền vào, giữ nguyên các field còn lại)
// Họ tên / email / SĐT được đồng bộ sang tài khoản Intern tương ứng.
async function updateStudent(
  id,
  {
    studentCode,
    fullName,
    email,
    phone,
    university,
    major,
    mentorName,
    status,
  },
) {
  return withTransaction(async (conn) => {
    const [existingRows] = await conn.query(
      "SELECT * FROM intern_profiles WHERE id = ?",
      [id],
    );
    if (existingRows.length === 0) return null;
    const existing = existingRows[0];

    let mentorId = existing.mentor_id;
    if (mentorName != null && mentorName !== existing.mentor_name) {
      const [mentorRows] = await conn.query(
        `SELECT id, full_name AS fullName FROM mentors
         WHERE LOWER(TRIM(full_name)) = LOWER(TRIM(?)) LIMIT 2`,
        [mentorName || ""],
      );
      mentorId = resolveUniqueMentorId(mentorName, mentorRows);
    }

    const merged = {
      studentCode: studentCode ?? existing.student_code,
      fullName: fullName ?? existing.full_name,
      email: email ?? existing.email,
      phone: phone ?? existing.phone,
      university: university ?? existing.university,
      major: major ?? existing.major,
      mentorName: mentorName ?? existing.mentor_name,
      status: status ?? existing.status,
    };

    await conn.query(
      "UPDATE intern_profiles SET student_code = ?, full_name = ?, email = ?, phone = ?, university = ?, major = ?, mentor_name = ?, mentor_id = ?, status = ? WHERE id = ?",
      [
        merged.studentCode,
        merged.fullName,
        merged.email,
        merged.phone,
        merged.university,
        merged.major,
        merged.mentorName,
        mentorId,
        merged.status,
        id,
      ],
    );
    await upsertProfileAccount(conn, "Intern", {
      oldEmail: existing.email,
      fullName: merged.fullName,
      email: merged.email,
      phone: merged.phone,
    });

    return { id: Number(id), ...merged, mentorId };
  });
}

// Xóa hồ sơ kèm tài khoản Intern tương ứng
async function deleteStudent(id) {
  const internRoleId = await getRoleId("Intern");
  const contractRows = await withProgramMembershipTransaction(async (conn) => {
    await assertNoFinalizedProgramResults(conn,id);
    const [contracts] = await conn.query(
      `SELECT stored_name AS storedName, confirmation_status AS confirmationStatus
       FROM internship_contracts WHERE intern_id = ? FOR UPDATE`,
      [id],
    );
    if (
      contracts.some((contract) => contract.confirmationStatus === "CONFIRMED")
    ) {
      throw new ConflictError(
        "Không thể xóa hồ sơ thực tập sinh vì có hợp đồng đã được xác nhận!",
        409,
      );
    }
    // File đính kèm của nhiệm vụ và báo cáo tuần bị xóa DB theo (CASCADE) nên phải lấy
    // tên file trước để dọn trên đĩa.
    const [taskFiles] = await conn.query(
      `SELECT ta.stored_name AS storedName
       FROM task_attachments ta
       JOIN intern_tasks t ON t.id = ta.task_id
       WHERE t.intern_id = ?`,
      [id],
    );
    const [reportFiles] = await conn.query(
      `SELECT wa.stored_name AS storedName
       FROM weekly_report_attachments wa
       JOIN weekly_reports wr ON wr.id = wa.report_id
       WHERE wr.intern_id = ?`,
      [id],
    );
    const [supportFiles] = await conn.query(
      `SELECT a.stored_name AS storedName FROM support_request_attachments a
       JOIN support_requests sr ON sr.id=a.request_id WHERE sr.intern_id=?`, [id],
    );
    const [rows] = await conn.query(
      "SELECT email FROM intern_profiles WHERE id = ?",
      [id],
    );
    await conn.query("DELETE FROM intern_profiles WHERE id = ?", [id]);
    if (rows.length > 0) {
      await conn.query(
        "DELETE FROM users WHERE LOWER(email) = LOWER(?) AND role_id = ?",
        [rows[0].email, internRoleId],
      );
    }
    return [...contracts, ...taskFiles, ...reportFiles, ...supportFiles];
  });
  return contractRows.map((row) => row.storedName);
}

// ĐỒNG BỘ TOÀN BỘ dữ liệu cũ giữa bảng users (vai trò Intern chính thức) và bảng intern_profiles.
async function syncInternsWithAccounts() {
  const db = requireDb();
  const internRoleId = await getRoleId("Intern");
  const defaultHash = await hashPassword(DEFAULT_ACCOUNT_PASSWORD);

  // 1. Tài khoản Intern chính thức chưa có hồ sơ -> tạo hồ sơ (lấy thêm trường/ngành từ hồ sơ ứng tuyển nếu có)
  await db.query(
    `INSERT INTO intern_profiles
       (student_code, full_name, email, phone, university, major, mentor_name, status)
     SELECT '', u.name, u.email, COALESCE(NULLIF(u.phone, ''), c.phone, ''),
            COALESCE(c.university, ?), COALESCE(c.major, ''), '', ?
     FROM users u
     LEFT JOIN candidate_profiles c ON c.user_id = u.id
     WHERE u.role_id = ?
       AND u.status NOT IN (${NON_INTERN_ACCOUNT_STATUSES_SQL})
       AND NOT EXISTS (SELECT 1 FROM intern_profiles i WHERE LOWER(i.email) COLLATE utf8mb4_unicode_ci = LOWER(u.email) COLLATE utf8mb4_unicode_ci)`,
    [DEFAULT_INTERN_UNIVERSITY, DEFAULT_INTERN_STATUS, internRoleId],
  );

  // 2. Hồ sơ thực tập sinh chưa có tài khoản -> tạo tài khoản Intern
  await db.query(
    `INSERT INTO users (name, email, password_hash, role_id, phone, status)
     SELECT i.full_name, i.email, ?, ?, NULLIF(i.phone, ''), 'ACTIVE'
     FROM intern_profiles i
     WHERE NOT EXISTS (SELECT 1 FROM users u WHERE LOWER(u.email) COLLATE utf8mb4_unicode_ci = LOWER(i.email) COLLATE utf8mb4_unicode_ci)`,
    [defaultHash, internRoleId],
  );

  // 3. Hồ sơ có SĐT trống mà tài khoản có SĐT -> bổ sung sang hồ sơ
  await db.query(
    `UPDATE intern_profiles i JOIN users u ON LOWER(u.email) COLLATE utf8mb4_unicode_ci = LOWER(i.email) COLLATE utf8mb4_unicode_ci
     SET i.phone = u.phone
     WHERE u.role_id = ? AND (i.phone IS NULL OR i.phone = '')
       AND u.phone IS NOT NULL AND u.phone <> ''`,
    [internRoleId],
  );

  // 4. Cặp đã khớp email -> đưa họ tên & SĐT của tài khoản về giống hồ sơ thực tập sinh
  await db.query(
    `UPDATE users u JOIN intern_profiles i ON LOWER(i.email) COLLATE utf8mb4_unicode_ci = LOWER(u.email) COLLATE utf8mb4_unicode_ci
     SET u.name = i.full_name, u.phone = NULLIF(i.phone, '')
     WHERE u.role_id = ?
       AND (u.name COLLATE utf8mb4_unicode_ci <> i.full_name COLLATE utf8mb4_unicode_ci
         OR NOT (u.phone COLLATE utf8mb4_unicode_ci <=> NULLIF(i.phone, '') COLLATE utf8mb4_unicode_ci))`,
    [internRoleId],
  );

  // 5. Cảnh báo hồ sơ thực tập sinh trùng email với tài khoản thuộc vai trò khác
  const [conflicts] = await db.query(
    `SELECT i.email, r.role_name AS role
     FROM intern_profiles i
     JOIN users u ON LOWER(u.email) COLLATE utf8mb4_unicode_ci = LOWER(i.email) COLLATE utf8mb4_unicode_ci
     JOIN roles r ON r.id = u.role_id
     WHERE u.role_id <> ?`,
    [internRoleId],
  );
  conflicts.forEach((c) =>
    console.warn(
      `[SYNC] Cảnh báo: thực tập sinh '${c.email}' trùng email với tài khoản vai trò ${c.role}, cần xử lý thủ công.`,
    ),
  );
}

// --- NHẬT KÝ GỬI EMAIL THÔNG BÁO KẾT QUẢ XÉT DUYỆT (email_logs) ---
const EMAIL_LOG_COLUMNS = `
  id, application_id AS applicationId, recipient_email AS recipientEmail,
  recipient_name AS recipientName, email_type AS emailType, subject,
  status, attempts, error_message AS errorMessage,
  created_at AS createdAt, updated_at AS updatedAt, sent_at AS sentAt
`;

// Tạo 1 dòng nhật ký mới (trạng thái PENDING, attempts = 0) - trả về id vừa tạo
async function insertEmailLog({
  applicationId,
  recipientEmail,
  recipientName,
  emailType,
  subject,
}) {
  const [result] = await requireDb().query(
    `INSERT INTO email_logs
       (application_id, recipient_email, recipient_name, email_type, subject, status, attempts)
     VALUES (?, ?, ?, ?, ?, 'PENDING', 0)`,
    [
      applicationId || null,
      recipientEmail,
      recipientName || null,
      emailType,
      subject,
    ],
  );
  return result.insertId;
}

// Cập nhật 1 phần thông tin nhật ký (chỉ ghi các trường thật sự được truyền vào)
async function updateEmailLog(id, { status, attempts, errorMessage, sentAt }) {
  const fields = [];
  const values = [];
  if (status !== undefined) {
    fields.push("status = ?");
    values.push(status);
  }
  if (attempts !== undefined) {
    fields.push("attempts = ?");
    values.push(attempts);
  }
  if (errorMessage !== undefined) {
    fields.push("error_message = ?");
    values.push(errorMessage);
  }
  if (sentAt !== undefined) {
    fields.push("sent_at = ?");
    values.push(sentAt);
  }
  if (fields.length === 0) return;
  values.push(id);
  await requireDb().query(
    `UPDATE email_logs SET ${fields.join(", ")} WHERE id = ?`,
    values,
  );
}

async function findEmailLogById(id) {
  const [rows] = await requireDb().query(
    `SELECT ${EMAIL_LOG_COLUMNS} FROM email_logs WHERE id = ?`,
    [id],
  );
  return rows[0] || null;
}

// Các job còn dang dở khi server bị tắt/crash giữa chừng - nạp lại lúc khởi động
async function listPendingOrRetryingEmailLogs() {
  const [rows] = await requireDb().query(
    `SELECT ${EMAIL_LOG_COLUMNS} FROM email_logs
     WHERE status IN ('PENDING', 'RETRYING') ORDER BY id ASC`,
  );
  return rows;
}

// Danh sách nhật ký có lọc + phân trang, dùng cho trang "Nhật ký Email"
async function listEmailLogs({
  status,
  emailType,
  search,
  page = 1,
  pageSize = 20,
} = {}) {
  const where = [];
  const values = [];
  if (status) {
    where.push("status = ?");
    values.push(status);
  }
  if (emailType) {
    where.push("email_type = ?");
    values.push(emailType);
  }
  if (search) {
    where.push("(recipient_email LIKE ? OR recipient_name LIKE ?)");
    values.push(`%${search}%`, `%${search}%`);
  }
  const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

  const [[{ total }]] = await requireDb().query(
    `SELECT COUNT(*) AS total FROM email_logs ${whereSql}`,
    values,
  );

  const safePage = Math.max(1, Number(page) || 1);
  const safePageSize = Math.min(100, Math.max(1, Number(pageSize) || 20));
  const offset = (safePage - 1) * safePageSize;

  const [rows] = await requireDb().query(
    `SELECT ${EMAIL_LOG_COLUMNS} FROM email_logs ${whereSql}
     ORDER BY id DESC LIMIT ? OFFSET ?`,
    [...values, safePageSize, offset],
  );

  return { rows, total, page: safePage, pageSize: safePageSize };
}

// --- TÀI LIỆU HỒ SƠ ỨNG TUYỂN (CV & ĐƠN XIN THỰC TẬP - application_documents) ---
const DOCUMENT_COLUMNS = `
  id, application_id AS applicationId, doc_type AS docType,
  original_name AS originalName, stored_name AS storedName,
  mime_type AS mimeType, size_bytes AS sizeBytes,
  uploaded_at AS uploadedAt, updated_at AS updatedAt
`;

async function findApplicationByUserIdOrEmail(userId, email) {
  const [rows] = await requireDb().query(
    `SELECT ${APPLICATION_COLUMNS} FROM candidate_profiles
     WHERE (user_id = ? AND user_id IS NOT NULL) OR LOWER(email) = LOWER(?)
     ORDER BY id DESC LIMIT 1`,
    [userId || 0, email || ""],
  );
  return rows[0] || null;
}

async function findDocumentsByApplicationId(applicationId) {
  const [rows] = await requireDb().query(
    `SELECT ${DOCUMENT_COLUMNS} FROM application_documents
     WHERE application_id = ?
     ORDER BY id ASC`,
    [applicationId],
  );
  return rows;
}

async function findDocumentById(docId) {
  const [rows] = await requireDb().query(
    `SELECT ${DOCUMENT_COLUMNS} FROM application_documents
     WHERE id = ? LIMIT 1`,
    [docId],
  );
  return rows[0] || null;
}

// Lấy tài liệu của NHIỀU hồ sơ trong 1 truy vấn (HR xem danh sách ứng viên, tránh N+1)
async function findDocumentsByApplicationIds(applicationIds) {
  if (!Array.isArray(applicationIds) || applicationIds.length === 0) return [];
  const [rows] = await requireDb().query(
    `SELECT ${DOCUMENT_COLUMNS} FROM application_documents
     WHERE application_id IN (?)
     ORDER BY application_id ASC, id ASC`,
    [applicationIds],
  );
  return rows;
}

// Tài khoản Intern được Admin tạo trực tiếp (không qua form ứng tuyển) chưa có hồ sơ.
// Tạo hồ sơ 'Chờ duyệt' GẮN VỚI user hiện có (KHÔNG tạo thêm user mới như insertCandidate).
async function createCandidateProfileForUser(userId) {
  const db = requireDb();
  const [users] = await db.query(
    "SELECT id, name, email FROM users WHERE id = ? LIMIT 1",
    [userId],
  );
  if (users.length === 0) return null;
  const u = users[0];
  try {
    await db.query(
      `INSERT INTO candidate_profiles
         (user_id, full_name, email, phone, university, major, cv_link, password_hash, status)
       VALUES (?, ?, ?, '', 'Chưa cập nhật', '', '', '', 'Chờ duyệt')`,
      [u.id, u.name, u.email],
    );
  } catch (err) {
    // Hai request đồng thời cùng tạo: UNIQUE(email) chặn bản thứ hai -> dùng bản đã có
    if (err.code !== "ER_DUP_ENTRY") throw err;
  }
  return findApplicationByUserIdOrEmail(u.id, u.email);
}

// Hồ sơ 'Chờ duyệt' và 'Đã duyệt' cho phép Intern thay đổi tài liệu; chỉ 'Từ chối' bị khóa.
// Nếu hồ sơ đã duyệt mà tài liệu bị thay đổi -> chuyển về 'Chờ duyệt' để HR duyệt lại tài liệu
// (KHÔNG đổi trạng thái tài khoản đăng nhập, Intern vẫn dùng hệ thống bình thường).
async function reopenIfApproved(conn, applicationId, status) {
  if (status !== "Đã duyệt") return;
  await conn.query(
    `UPDATE candidate_profiles
        SET status = 'Chờ duyệt', rejection_reason = NULL, reviewed_by = NULL, reviewed_at = NULL
      WHERE id = ? AND status = 'Đã duyệt'`,
    [applicationId],
  );
}

// Lưu (thêm mới hoặc ghi đè) tài liệu khi hồ sơ 'Chờ duyệt' hoặc 'Đã duyệt' (bị 'Từ chối' thì khóa).
// Khóa dòng hồ sơ bằng FOR UPDATE trong cùng transaction: HR không thể duyệt/từ chối
// xen giữa bước kiểm tra trạng thái và bước ghi. Lỗi bất kỳ -> rollback toàn bộ.
// Trả về { outcome: 'SAVED' | 'LOCKED' | 'NOT_FOUND', ... }
async function saveDocumentIfPending({
  applicationId,
  docType,
  originalName,
  storedName,
  mimeType,
  sizeBytes,
}) {
  return withTransaction(async (conn) => {
    const [apps] = await conn.query(
      "SELECT status FROM candidate_profiles WHERE id = ? FOR UPDATE",
      [applicationId],
    );
    if (apps.length === 0) return { outcome: "NOT_FOUND" };
    if (apps[0].status === "Từ chối") {
      return { outcome: "LOCKED", status: apps[0].status };
    }

    const [old] = await conn.query(
      `SELECT stored_name AS storedName FROM application_documents
       WHERE application_id = ? AND doc_type = ? FOR UPDATE`,
      [applicationId, docType],
    );

    await conn.query(
      `INSERT INTO application_documents
         (application_id, doc_type, original_name, stored_name, mime_type, size_bytes)
       VALUES (?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE
         original_name = VALUES(original_name),
         stored_name = VALUES(stored_name),
         mime_type = VALUES(mime_type),
         size_bytes = VALUES(size_bytes),
         updated_at = CURRENT_TIMESTAMP`,
      [applicationId, docType, originalName, storedName, mimeType, sizeBytes],
    );

    await reopenIfApproved(conn, applicationId, apps[0].status);

    const [rows] = await conn.query(
      `SELECT ${DOCUMENT_COLUMNS} FROM application_documents
       WHERE application_id = ? AND doc_type = ? LIMIT 1`,
      [applicationId, docType],
    );
    return {
      outcome: "SAVED",
      document: rows[0],
      previousStoredName: old.length > 0 ? old[0].storedName : null,
    };
  });
}

// Xóa bản ghi tài liệu khi hồ sơ không bị 'Từ chối' (cùng cơ chế khóa như trên).
// Trả về { outcome: 'DELETED' | 'LOCKED' | 'NOT_FOUND', storedName?, status? }
async function deleteDocumentIfPending({ applicationId, docId }) {
  return withTransaction(async (conn) => {
    const [apps] = await conn.query(
      "SELECT status FROM candidate_profiles WHERE id = ? FOR UPDATE",
      [applicationId],
    );
    if (apps.length === 0) return { outcome: "NOT_FOUND" };
    if (apps[0].status === "Từ chối") {
      return { outcome: "LOCKED", status: apps[0].status };
    }

    const [docs] = await conn.query(
      `SELECT stored_name AS storedName FROM application_documents
       WHERE id = ? AND application_id = ? FOR UPDATE`,
      [docId, applicationId],
    );
    if (docs.length === 0) return { outcome: "NOT_FOUND" };

    await conn.query("DELETE FROM application_documents WHERE id = ?", [docId]);
    await reopenIfApproved(conn, applicationId, apps[0].status);
    return { outcome: "DELETED", storedName: docs[0].storedName };
  });
}

// --- HỢP ĐỒNG THỰC TẬP SINH ---
const CONTRACT_COLUMNS =
  "id, intern_id AS internId, title, start_date AS startDate, " +
  "end_date AS endDate, note, program_id AS programId, original_name AS originalName, " +
  "stored_name AS storedName, mime_type AS mimeType, " +
  "size_bytes AS sizeBytes, uploaded_by AS uploadedBy, " +
  "uploaded_at AS uploadedAt, updated_at AS updatedAt, " +
  "confirmation_status AS confirmationStatus, confirmed_at AS confirmedAt, " +
  "confirmed_by AS confirmedBy";

// ---------- Mentor ↔ thực tập sinh (xem / gán từ phía mentor) ----------
async function listMentorInterns(mentorId) {
  const [rows] = await requireDb().query(
    `SELECT id, student_code AS studentCode, full_name AS fullName, email, university, status
     FROM intern_profiles WHERE mentor_id = ? ORDER BY full_name, id`, [mentorId]);
  return rows;
}
// Thực tập sinh chưa thuộc mentor này (chưa có mentor lên đầu) để HR chọn thêm / chuyển sang.
async function listInternsNotOfMentor(mentorId) {
  const [rows] = await requireDb().query(
    `SELECT id, student_code AS studentCode, full_name AS fullName, university, status,
            mentor_id AS mentorId, mentor_name AS mentorName
     FROM intern_profiles WHERE mentor_id IS NULL OR mentor_id <> ?
     ORDER BY (mentor_id IS NULL) DESC, full_name, id`, [mentorId]);
  return rows;
}
// Phòng ban của các chương trình mà từng thực tập sinh thuộc về: Map<internId, string[]>.
async function listProgramDepartmentsForInterns(internIds) {
  const map = new Map();
  if (!internIds.length) return map;
  const [rows] = await requireDb().query(
    `SELECT pi.intern_id AS internId, d.name AS departmentName
     FROM program_interns pi JOIN internship_programs p ON p.id = pi.program_id
     JOIN departments d ON d.id = p.department_id WHERE pi.intern_id IN (?)`, [internIds]);
  for (const r of rows) map.set(Number(r.internId), [...(map.get(Number(r.internId)) || []), r.departmentName]);
  return map;
}
// Gán một mentor cho nhiều thực tập sinh trong một transaction; người đã thuộc mentor này được tính là không đổi.
async function assignMentorToInterns(mentorId, internIds) {
  return withTransaction(async (conn) => {
    const [mentorRows] = await conn.query("SELECT full_name FROM mentors WHERE id = ? FOR UPDATE", [mentorId]);
    if (!mentorRows.length) return { outcome: "MENTOR_NOT_FOUND" };
    const mentorName = mentorRows[0].full_name;
    const [found] = await conn.query(
      "SELECT id, full_name AS fullName, email, mentor_id AS mentorId FROM intern_profiles WHERE id IN (?) ORDER BY id FOR UPDATE", [internIds]);
    const foundIds = new Set(found.map((r) => Number(r.id)));
    const missing = internIds.filter((id) => !foundIds.has(id));
    if (missing.length) return { outcome: "INTERN_NOT_FOUND", missing };
    const changed = found.filter((r) => Number(r.mentorId) !== Number(mentorId));
    if (changed.length)
      await conn.query("UPDATE intern_profiles SET mentor_id = ?, mentor_name = ? WHERE id IN (?)", [mentorId, mentorName, changed.map((r) => r.id)]);
    return { outcome: "UPDATED", mentorName, changed, unchanged: found.length - changed.length };
  });
}

async function findInternProfileById(id) {
  const [rows] = await requireDb().query(
    `SELECT id, student_code AS studentCode, full_name AS fullName, email,
            phone, university, major, mentor_name AS mentorName, mentor_id AS mentorId,
            status, created_at AS createdAt
     FROM intern_profiles WHERE id = ? LIMIT 1`,
    [id],
  );
  return rows[0] || null;
}

async function findInternProfileByEmail(email) {
  const [rows] = await requireDb().query(
    `SELECT id, student_code AS studentCode, full_name AS fullName, email,
            phone, university, major, mentor_name AS mentorName, mentor_id AS mentorId,
            status, created_at AS createdAt
     FROM intern_profiles
     WHERE LOWER(email) = LOWER(?) LIMIT 1`,
    [email],
  );
  return rows[0] || null;
}

async function findMentorById(id) {
  if (!id) return null;
  const [rows] = await requireDb().query(
    `SELECT id, full_name AS fullName, email, phone, department, specialization, created_at AS createdAt
     FROM mentors WHERE id = ? LIMIT 1`,
    [id],
  );
  return rows[0] || null;
}

async function findMentorByEmail(email) {
  if (!email) return null;
  const [rows] = await requireDb().query(
    `SELECT id, full_name AS fullName, email, phone, department, specialization
     FROM mentors WHERE LOWER(email) = LOWER(?) LIMIT 1`,
    [email],
  );
  return rows[0] || null;
}

// ---------- NHIỆM VỤ GIAO CHO THỰC TẬP SINH ----------
const TASK_SELECT = `SELECT t.id, t.intern_id AS internId, t.created_by_mentor_id AS createdByMentorId,
            t.title, t.description, t.due_date AS dueDate, t.priority, t.status,
            t.progress_percent AS progressPercent, t.progress_note AS progressNote,
            t.progress_updated_at AS progressUpdatedAt,
            t.created_at AS createdAt, t.updated_at AS updatedAt,
            ip.full_name AS internName, ip.student_code AS studentCode,
            ip.mentor_id AS internMentorId, m.full_name AS mentorName
     FROM intern_tasks t
     JOIN intern_profiles ip ON ip.id = t.intern_id
     LEFT JOIN mentors m ON m.id = ip.mentor_id`;
const TASK_ORDER = `ORDER BY (t.status = 'DONE') ASC, (t.due_date IS NULL) ASC, t.due_date ASC, t.id DESC`;

async function insertInternTask(task) {
  const [result] = await requireDb().query(
    `INSERT INTO intern_tasks (intern_id, created_by_mentor_id, title, description, due_date, priority)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [
      task.internId,
      task.createdByMentorId || null,
      task.title,
      task.description || null,
      task.dueDate || null,
      task.priority || "MEDIUM",
    ],
  );
  return result.insertId;
}

async function findInternTaskById(id) {
  const [rows] = await requireDb().query(
    `${TASK_SELECT} WHERE t.id = ? LIMIT 1`,
    [id],
  );
  return rows[0] || null;
}

// Mentor chỉ thấy nhiệm vụ của thực tập sinh đang được phân công cho mình.
async function listInternTasksForMentor(
  mentorId,
  { internId = null, status = null } = {},
) {
  const params = [mentorId];
  let extraSql = "";
  if (internId) {
    extraSql += " AND t.intern_id = ?";
    params.push(internId);
  }
  if (status) {
    extraSql += " AND t.status = ?";
    params.push(status);
  }
  const [rows] = await requireDb().query(
    `${TASK_SELECT} WHERE ip.mentor_id = ?${extraSql} ${TASK_ORDER}`,
    params,
  );
  return rows;
}

async function listInternTasksForIntern(internId) {
  const [rows] = await requireDb().query(
    `${TASK_SELECT} WHERE t.intern_id = ? ${TASK_ORDER}`,
    [internId],
  );
  return rows;
}

// fields dùng khóa nội bộ (title, description, dueDate, priority, status),
// không nhận khóa từ request.
async function updateInternTask(id, fields) {
  const columns = {
    title: "title",
    description: "description",
    dueDate: "due_date",
    priority: "priority",
    status: "status",
    progressPercent: "progress_percent",
  };
  const sets = [];
  const params = [];
  for (const [key, column] of Object.entries(columns)) {
    if (!Object.prototype.hasOwnProperty.call(fields, key)) continue;
    sets.push(`${column} = ?`);
    params.push(fields[key]);
  }
  if (sets.length === 0) return 0;
  const [result] = await requireDb().query(
    `UPDATE intern_tasks SET ${sets.join(", ")} WHERE id = ?`,
    [...params, id],
  );
  return result.affectedRows;
}

// Thực tập sinh cập nhật tiến độ. Luôn ghi progress_updated_at; chỉ đổi các
// trường có trong `fields` (status, progressPercent, progressNote).
async function updateInternTaskProgress(id, fields) {
  const columns = {
    status: "status",
    progressPercent: "progress_percent",
    progressNote: "progress_note",
  };
  const sets = ["progress_updated_at = NOW()"];
  const params = [];
  for (const [key, column] of Object.entries(columns)) {
    if (!Object.prototype.hasOwnProperty.call(fields, key)) continue;
    sets.push(`${column} = ?`);
    params.push(fields[key]);
  }
  const [result] = await requireDb().query(
    `UPDATE intern_tasks SET ${sets.join(", ")} WHERE id = ?`,
    [...params, id],
  );
  return result.affectedRows;
}

// ---------- BÁO CÁO TUẦN ----------
// Kỳ thực tập của intern: ngày bắt đầu sớm nhất / kết thúc muộn nhất của các hợp đồng
// đã xác nhận (endDate = null nếu có hợp đồng chưa có ngày kết thúc).
const PERIOD_SELECT = `SELECT MIN(start_date) AS startDate,
            CASE WHEN SUM(end_date IS NULL) > 0 THEN NULL ELSE MAX(end_date) END AS endDate
     FROM internship_contracts
     WHERE confirmation_status = 'CONFIRMED'`;

async function findInternContractPeriod(internId) {
  const [rows] = await requireDb().query(`${PERIOD_SELECT} AND intern_id = ?`, [
    internId,
  ]);
  return rows[0] || { startDate: null, endDate: null };
}

// Thực tập sinh của mentor kèm kỳ thực tập (dùng cho bảng tổng quan nộp báo cáo).
async function listInternsWithPeriodForMentor(mentorId) {
  const [rows] = await requireDb().query(
    `SELECT ip.id, ip.full_name AS fullName, ip.student_code AS studentCode,
            ip.created_at AS createdAt, p.startDate, p.endDate
     FROM intern_profiles ip
     LEFT JOIN (
       SELECT intern_id, MIN(start_date) AS startDate,
              CASE WHEN SUM(end_date IS NULL) > 0 THEN NULL ELSE MAX(end_date) END AS endDate
       FROM internship_contracts
       WHERE confirmation_status = 'CONFIRMED'
       GROUP BY intern_id
     ) p ON p.intern_id = ip.id
     WHERE ip.mentor_id = ?
     ORDER BY ip.full_name ASC, ip.id ASC`,
    [mentorId],
  );
  return rows;
}

const WEEKLY_REPORT_SELECT = `SELECT wr.id, wr.intern_id AS internId, wr.week_start AS weekStart,
            wr.content, wr.difficulties, wr.next_plan AS nextPlan, wr.is_late AS isLate,
            wr.submitted_at AS submittedAt, wr.updated_at AS updatedAt,
            ip.full_name AS internName, ip.student_code AS studentCode,
            ip.mentor_id AS internMentorId,
            wf.id AS feedbackId, wf.content AS feedbackContent,
            wf.mentor_id AS feedbackMentorId, fm.full_name AS feedbackMentorName,
            wf.created_at AS feedbackCreatedAt, wf.updated_at AS feedbackUpdatedAt
     FROM weekly_reports wr
     JOIN intern_profiles ip ON ip.id = wr.intern_id
     LEFT JOIN weekly_report_feedback wf ON wf.report_id = wr.id
     LEFT JOIN mentors fm ON fm.id = wf.mentor_id`;

async function findWeeklyReportById(id) {
  const [rows] = await requireDb().query(
    `${WEEKLY_REPORT_SELECT} WHERE wr.id = ? LIMIT 1`,
    [id],
  );
  return rows[0] || null;
}

async function findWeeklyReportByWeek(internId, weekStart) {
  const [rows] = await requireDb().query(
    `${WEEKLY_REPORT_SELECT} WHERE wr.intern_id = ? AND wr.week_start = ? LIMIT 1`,
    [internId, weekStart],
  );
  return rows[0] || null;
}

// Nộp mới hoặc cập nhật báo cáo của tuần đó. Nộp lại không đổi is_late / submitted_at.
async function upsertWeeklyReport({
  internId,
  weekStart,
  content,
  difficulties,
  nextPlan,
  isLate,
}) {
  await requireDb().query(
    `INSERT INTO weekly_reports
       (intern_id, week_start, content, difficulties, next_plan, is_late, submitted_at)
     VALUES (?, ?, ?, ?, ?, ?, NOW())
     ON DUPLICATE KEY UPDATE
       content = VALUES(content),
       difficulties = VALUES(difficulties),
       next_plan = VALUES(next_plan)`,
    [internId, weekStart, content, difficulties, nextPlan, isLate ? 1 : 0],
  );
  return findWeeklyReportByWeek(internId, weekStart);
}

async function listWeeklyReportsForIntern(internId) {
  const [rows] = await requireDb().query(
    `${WEEKLY_REPORT_SELECT} WHERE wr.intern_id = ? ORDER BY wr.week_start DESC`,
    [internId],
  );
  return rows;
}

// Mentor chỉ thấy báo cáo của thực tập sinh đang được phân công cho mình.
async function listWeeklyReportsForMentor(
  mentorId,
  { internId = null, weekStart = null } = {},
) {
  const params = [mentorId];
  let extraSql = "";
  if (internId) {
    extraSql += " AND wr.intern_id = ?";
    params.push(internId);
  }
  if (weekStart) {
    extraSql += " AND wr.week_start = ?";
    params.push(weekStart);
  }
  const [rows] = await requireDb().query(
    `${WEEKLY_REPORT_SELECT} WHERE ip.mentor_id = ?${extraSql}
     ORDER BY wr.week_start DESC, ip.full_name ASC`,
    params,
  );
  return rows;
}

// ---------- PHẢN HỒI CỦA MENTOR CHO BÁO CÁO TUẦN ----------
// Mỗi báo cáo tối đa 1 phản hồi. Gửi lại thì ghi đè nội dung và đặt updated_at = NOW()
// (kể cả khi nội dung giống hệt) để mốc "đã xem lại báo cáo mới" luôn được làm mới.
// Trả về báo cáo (kèm phản hồi) sau khi lưu.
async function upsertWeeklyReportFeedback({ reportId, mentorId, content }) {
  await requireDb().query(
    `INSERT INTO weekly_report_feedback (report_id, mentor_id, content)
     VALUES (?, ?, ?)
     ON DUPLICATE KEY UPDATE
       mentor_id = VALUES(mentor_id),
       content = VALUES(content),
       updated_at = NOW()`,
    [reportId, mentorId, content],
  );
  return findWeeklyReportById(reportId);
}

async function deleteWeeklyReportFeedback(reportId) {
  const [result] = await requireDb().query(
    "DELETE FROM weekly_report_feedback WHERE report_id = ?",
    [reportId],
  );
  return result.affectedRows;
}

// ---------- ĐÁNH GIÁ TỔNG KẾT CỦA MENTOR ----------
// Mỗi thực tập sinh tối đa 1 đánh giá. Trả về bản ghi kèm tên mentor, hoặc null nếu chưa có.
const EVALUATION_SELECT = `SELECT ev.id, ev.intern_id AS internId,
            ip.full_name AS internName, ip.student_code AS studentCode,
            ip.mentor_id AS internMentorId,
            ev.mentor_id AS mentorId, m.full_name AS mentorName,
            ev.skill_score AS skillScore, ev.skill_comment AS skillComment,
            ev.attitude_score AS attitudeScore, ev.attitude_comment AS attitudeComment,
            ev.overall_comment AS overallComment,
            ev.created_at AS createdAt, ev.updated_at AS updatedAt
     FROM intern_evaluations ev
     JOIN intern_profiles ip ON ip.id = ev.intern_id
     LEFT JOIN mentors m ON m.id = ev.mentor_id`;

async function findInternEvaluation(internId) {
  const [rows] = await requireDb().query(
    `${EVALUATION_SELECT} WHERE ev.intern_id = ? LIMIT 1`,
    [internId],
  );
  return rows[0] || null;
}

// Gửi lại thì ghi đè nội dung và đặt updated_at = NOW() (kể cả khi nội dung giống hệt).
async function upsertInternEvaluation({
  internId,
  mentorId,
  skillScore,
  skillComment,
  attitudeScore,
  attitudeComment,
  overallComment,
}) {
  await requireDb().query(
    `INSERT INTO intern_evaluations
       (intern_id, mentor_id, skill_score, skill_comment, attitude_score, attitude_comment, overall_comment)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE
       mentor_id = VALUES(mentor_id),
       skill_score = VALUES(skill_score),
       skill_comment = VALUES(skill_comment),
       attitude_score = VALUES(attitude_score),
       attitude_comment = VALUES(attitude_comment),
       overall_comment = VALUES(overall_comment),
       updated_at = NOW()`,
    [
      internId,
      mentorId,
      skillScore,
      skillComment,
      attitudeScore,
      attitudeComment,
      overallComment,
    ],
  );
  return findInternEvaluation(internId);
}

async function getServerDateTime() {
  const [rows] = await requireDb().query("SELECT DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s') AS serverNow");
  return rows[0]?.serverNow;
}
const ATTENDANCE_COLUMNS = `a.id, a.intern_id AS internId, DATE_FORMAT(a.work_date, '%Y-%m-%d') AS workDate,
    DATE_FORMAT(a.check_in_at, '%Y-%m-%d %H:%i:%s') AS checkInAt, DATE_FORMAT(a.check_out_at, '%Y-%m-%d %H:%i:%s') AS checkOutAt,
    a.note, TIMESTAMPDIFF(MINUTE, a.check_in_at, a.check_out_at) AS durationMinutes, a.is_adjusted AS isAdjusted,
    a.correction_status AS correctionStatus, DATE_FORMAT(a.correction_check_out_at, '%Y-%m-%d %H:%i:%s') AS correctionCheckOutAt,
    a.correction_reason AS correctionReason, DATE_FORMAT(a.correction_requested_at, '%Y-%m-%d %H:%i:%s') AS correctionRequestedAt,
    DATE_FORMAT(a.correction_reviewed_at, '%Y-%m-%d %H:%i:%s') AS correctionReviewedAt, a.correction_review_note AS correctionReviewNote`;
async function findAttendanceByInternDate(internId, workDate) {
  const [rows] = await requireDb().query(`SELECT ${ATTENDANCE_COLUMNS} FROM attendance_records a WHERE a.intern_id = ? AND a.work_date = ? LIMIT 1`, [internId, workDate]);
  return rows[0] || null;
}
async function findAttendanceById(id) {
  const [rows] = await requireDb().query(`SELECT ${ATTENDANCE_COLUMNS} FROM attendance_records a WHERE a.id = ? LIMIT 1`, [id]);
  return rows[0] || null;
}
// Ca đang mở (chưa check-out) bắt đầu trong vòng maxHours giờ gần nhất — gồm cả ca qua đêm.
async function findOpenAttendance(internId, maxHours) {
  const [rows] = await requireDb().query(`SELECT ${ATTENDANCE_COLUMNS} FROM attendance_records a
    WHERE a.intern_id = ? AND a.check_out_at IS NULL AND a.check_in_at >= (NOW() - INTERVAL ? HOUR)
    ORDER BY a.check_in_at DESC LIMIT 1`, [internId, maxHours]);
  return rows[0] || null;
}
// Ngày làm việc có nằm trong ít nhất một hợp đồng đã xác nhận không (không tính khoảng trống giữa các hợp đồng).
async function hasConfirmedContractOn(internId, date) {
  const [rows] = await requireDb().query(`SELECT 1 FROM internship_contracts WHERE intern_id = ? AND confirmation_status = 'CONFIRMED'
    AND (start_date IS NULL OR start_date <= ?) AND (end_date IS NULL OR end_date >= ?) LIMIT 1`, [internId, date, date]);
  return rows.length > 0;
}
async function insertAttendance({ internId, workDate, note }) {
  try {
    await requireDb().query(`INSERT INTO attendance_records (intern_id, work_date, check_in_at, note)
      VALUES (?, ?, NOW(), ?)`, [internId, workDate, note]);
    return findAttendanceByInternDate(internId, workDate);
  }
  catch (err) {
    if (err.code === "ER_DUP_ENTRY")
      return "DUPLICATE";
    throw err;
  }
}
async function checkOutAttendance(id) {
  const [result] = await requireDb().query("UPDATE attendance_records SET check_out_at = NOW() WHERE id = ? AND check_out_at IS NULL", [id]);
  if (!result.affectedRows)
    return null;
  return findAttendanceById(id);
}
async function listAttendance(internId, from, to) {
  const [rows] = await requireDb().query(`SELECT ${ATTENDANCE_COLUMNS} FROM attendance_records a
    WHERE a.intern_id = ? AND a.work_date BETWEEN ? AND ? ORDER BY a.work_date DESC`, [internId, from, to]);
  return rows;
}
// Thực tập sinh đề nghị bổ sung giờ check-out cho ca quên check-out. Cho gửi lại sau khi bị từ chối.
async function requestAttendanceCorrection({ id, internId, checkOutAt, reason }) {
  const [result] = await requireDb().query(`UPDATE attendance_records SET correction_status = 'PENDING', correction_check_out_at = ?,
    correction_reason = ?, correction_requested_at = NOW(), correction_reviewed_by = NULL, correction_reviewed_at = NULL, correction_review_note = NULL
    WHERE id = ? AND intern_id = ? AND check_out_at IS NULL AND (correction_status IS NULL OR correction_status = 'REJECTED')`, [checkOutAt, reason, id, internId]);
  return result.affectedRows;
}
async function reviewAttendanceCorrection({ id, decision, userId, note }) {
  const approved = decision === "APPROVED";
  const [result] = await requireDb().query(`UPDATE attendance_records SET correction_status = ?,
    check_out_at = IF(?, correction_check_out_at, check_out_at), is_adjusted = IF(?, 1, is_adjusted),
    correction_reviewed_by = ?, correction_reviewed_at = NOW(), correction_review_note = ?
    WHERE id = ? AND correction_status = 'PENDING' AND check_out_at IS NULL`, [
    decision,
    approved,
    approved,
    userId,
    note || null,
    id
  ]);
  return result.affectedRows;
}
async function listPendingAttendanceCorrections(mentorId = null) {
  const params = [];
  let extra = "";
  if (mentorId) {
    extra = " AND ip.mentor_id = ?";
    params.push(mentorId);
  }
  const [rows] = await requireDb().query(`SELECT ${ATTENDANCE_COLUMNS}, ip.full_name AS fullName, ip.student_code AS studentCode
    FROM attendance_records a JOIN intern_profiles ip ON ip.id = a.intern_id
    WHERE a.correction_status = 'PENDING'${extra} ORDER BY a.correction_requested_at ASC, a.id ASC`, params);
  return rows;
}
async function deleteInternEvaluation(internId) {
  const [result] = await requireDb().query(
    "DELETE FROM intern_evaluations WHERE intern_id = ?",
    [internId],
  );
  return result.affectedRows;
}

// Mọi thực tập sinh của mentor kèm đánh giá (nếu có) — dùng cho bảng tổng quan.
async function listFinalReportInterns({ scopeType, scopeValue, from, to }) {
  // Thứ tự tham số phải khớp thứ tự xuất hiện trong câu SQL: các subquery trước, bộ lọc WHERE sau.
  const cpParams = [], taskParams = [], attParams = [], params = [];
  // Chỉ thực tập sinh đã có hợp đồng xác nhận (đang/đã thực tập thật) mới vào báo cáo.
  const filters = ["EXISTS (SELECT 1 FROM internship_contracts c0 WHERE c0.intern_id=ip.id AND c0.confirmation_status='CONFIRMED')"];
  let programClause = "";
  if (scopeType === "UNIVERSITY") {
    filters.push("TRIM(ip.university) = TRIM(?)");
    params.push(scopeValue);
  }
  if (scopeType === "PROGRAM") {
    filters.push("EXISTS (SELECT 1 FROM program_interns pi0 WHERE pi0.intern_id=ip.id AND pi0.program_id=?)");
    params.push(scopeValue);
    programClause = " AND pi.program_id = ?";
    cpParams.push(scopeValue);
  }
  if (from) {
    filters.push("p.startDate IS NOT NULL AND (p.endDate IS NULL OR p.endDate >= ?)");
    params.push(from);
  }
  if (to) {
    filters.push("p.startDate IS NOT NULL AND p.startDate <= ?");
    params.push(to);
  }
  // Nhiệm vụ và giờ làm chỉ tính trong kỳ báo cáo (nhiệm vụ theo hạn nộp, không có hạn thì theo ngày giao).
  let taskPeriod = "", attPeriod = "";
  if (from) {
    taskPeriod += " AND COALESCE(due_date, DATE(created_at)) >= ?";
    taskParams.push(from);
    attPeriod += " AND work_date >= ?";
    attParams.push(from);
  }
  if (to) {
    taskPeriod += " AND COALESCE(due_date, DATE(created_at)) <= ?";
    taskParams.push(to);
    attPeriod += " AND work_date <= ?";
    attParams.push(to);
  }
  const [rows] = await requireDb().query(`SELECT ip.id AS internId, ip.full_name AS fullName, ip.student_code AS studentCode,
    ip.university, ip.major, COALESCE(m.full_name, ip.mentor_name) AS mentorName,
    p.startDate, p.endDate, cp.programName, cp.departmentName,
    ev.skill_score AS skillScore, ev.skill_comment AS skillComment, ev.attitude_score AS attitudeScore,
    ev.attitude_comment AS attitudeComment, ev.overall_comment AS overallComment,
    COALESCE(ts.taskCount,0) AS taskCount, COALESCE(ts.completedTaskCount,0) AS completedTaskCount,
    COALESCE(att.totalWorkMinutes,0) AS totalWorkMinutes
    FROM intern_profiles ip LEFT JOIN mentors m ON m.id=ip.mentor_id
    LEFT JOIN intern_evaluations ev ON ev.intern_id=ip.id
    LEFT JOIN (SELECT intern_id, MIN(start_date) AS startDate, CASE WHEN SUM(end_date IS NULL)>0 THEN NULL ELSE MAX(end_date) END AS endDate
      FROM internship_contracts WHERE confirmation_status='CONFIRMED' GROUP BY intern_id) p ON p.intern_id=ip.id
    LEFT JOIN (SELECT pi.intern_id, GROUP_CONCAT(DISTINCT pr.name ORDER BY pr.name SEPARATOR ', ') AS programName,
        GROUP_CONCAT(DISTINCT d.name ORDER BY d.name SEPARATOR ', ') AS departmentName
      FROM program_interns pi JOIN internship_programs pr ON pr.id=pi.program_id LEFT JOIN departments d ON d.id=pr.department_id
      WHERE 1=1${programClause} GROUP BY pi.intern_id) cp ON cp.intern_id=ip.id
    LEFT JOIN (SELECT intern_id, COUNT(*) AS taskCount, SUM(status='DONE') AS completedTaskCount FROM intern_tasks WHERE 1=1${taskPeriod} GROUP BY intern_id) ts ON ts.intern_id=ip.id
    LEFT JOIN (SELECT intern_id, SUM(TIMESTAMPDIFF(MINUTE,check_in_at,check_out_at)) AS totalWorkMinutes FROM attendance_records WHERE check_out_at IS NOT NULL${attPeriod} GROUP BY intern_id) att ON att.intern_id=ip.id
    WHERE ${filters.join(" AND ")} ORDER BY ip.full_name, ip.id`, [...cpParams, ...taskParams, ...attParams, ...params]);
  if (!rows.length)
    return rows;
  const ids = rows.map(r => r.internId);
  const [reports] = await requireDb().query("SELECT intern_id AS internId, week_start AS weekStart, is_late AS isLate FROM weekly_reports WHERE intern_id IN (?)", [ids]);
  const grouped = new Map();
  for (const r of reports)
    (grouped.get(Number(r.internId)) || (grouped.set(Number(r.internId), []), grouped.get(Number(r.internId)))).push(r);
  return rows.map(r => ({ ...r, weeklyReports: grouped.get(Number(r.internId)) || [] }));
}
async function getFinalReportFilterOptions() {
  const [programs] = await requireDb().query("SELECT id, name FROM internship_programs ORDER BY name");
  return { ...(await getInternFilterOptions()), programs };
}
async function createFinalReport(fields, userId) {
  const [result] = await requireDb().query(`INSERT INTO final_reports (title,scope_type,scope_value,period_from,period_to,hr_note,created_by)
    VALUES (?,?,?,?,?,?,?)`, [fields.title,fields.scopeType,fields.scopeValue,fields.periodFrom,fields.periodTo,fields.hrNote,userId]);
  return findFinalReportById(result.insertId);
}
async function listFinalReports({ status = null, limit = 20, offset = 0 } = {}) {
  const params = [];
  const where = status ? "WHERE fr.status = ?" : "";
  if (status) params.push(status);
  params.push(limit, offset);
  const [rows] = await requireDb().query(`SELECT fr.id,fr.title,fr.scope_type AS scopeType,fr.scope_value AS scopeValue,
    fr.period_from AS periodFrom,fr.period_to AS periodTo,fr.status,fr.created_by AS createdBy,u.name AS createdByName,
    fr.created_at AS createdAt,fr.finalized_at AS finalizedAt,
    (SELECT COUNT(*) FROM final_report_sends s WHERE s.report_id=fr.id) AS sendCount,
    (SELECT MAX(s.sent_at) FROM final_report_sends s WHERE s.report_id=fr.id) AS lastSentAt,
    (SELECT s.recipients FROM final_report_sends s WHERE s.report_id=fr.id ORDER BY s.sent_at DESC, s.id DESC LIMIT 1) AS lastRecipients
    FROM final_reports fr LEFT JOIN users u ON u.id=fr.created_by ${where} ORDER BY fr.created_at DESC, fr.id DESC LIMIT ? OFFSET ?`, params);
  return rows;
}
async function findFinalReportById(id) {
  const [rows] = await requireDb().query(`SELECT id,title,scope_type AS scopeType,scope_value AS scopeValue,
    period_from AS periodFrom,period_to AS periodTo,status,hr_note AS hrNote,snapshot_json AS snapshotJson,
    created_by AS createdBy,finalized_by AS finalizedBy,created_at AS createdAt,finalized_at AS finalizedAt,updated_at AS updatedAt
    FROM final_reports WHERE id = ? LIMIT 1`, [id]);
  return rows[0] || null;
}
async function updateFinalReport(id, fields) {
  const [result] = await requireDb().query(`UPDATE final_reports SET title=?,scope_type=?,scope_value=?,period_from=?,period_to=?,hr_note=? WHERE id=? AND status='DRAFT'`,
    [fields.title,fields.scopeType,fields.scopeValue,fields.periodFrom,fields.periodTo,fields.hrNote,id]);
  return result.affectedRows;
}
async function finalizeFinalReport(id, userId, snapshot) {
  const [result] = await requireDb().query(`UPDATE final_reports SET status='FINALIZED',snapshot_json=?,finalized_by=?,finalized_at=NOW()
    WHERE id=? AND status='DRAFT'`, [JSON.stringify(snapshot),userId,id]);
  return result.affectedRows;
}
async function deleteFinalReport(id) {
  const [result] = await requireDb().query("DELETE FROM final_reports WHERE id=? AND status='DRAFT'", [id]);
  return result.affectedRows;
}
async function recordFinalReportSend({ reportId, userId, recipients, message }) {
  const [result] = await requireDb().query("INSERT INTO final_report_sends (report_id,sent_by,recipients,message) VALUES (?,?,?,?)",
    [reportId, userId || null, JSON.stringify(recipients), message || null]);
  return result.insertId;
}
async function listFinalReportSends(reportId) {
  const [rows] = await requireDb().query(`SELECT s.id,s.recipients,s.message,s.sent_at AS sentAt,s.sent_by AS sentBy,u.name AS sentByName
    FROM final_report_sends s LEFT JOIN users u ON u.id=s.sent_by WHERE s.report_id=? ORDER BY s.sent_at DESC, s.id DESC`, [reportId]);
  return rows;
}
async function upsertFinalReportRecipients({ emails, scopeType, scopeValue, userId }) {
  const value = scopeType === "ALL" ? "" : String(scopeValue || "");
  for (const email of emails)
    await requireDb().query(`INSERT INTO final_report_recipients (email,scope_type,scope_value,created_by) VALUES (?,?,?,?)
      ON DUPLICATE KEY UPDATE last_used_at=CURRENT_TIMESTAMP`, [email, scopeType, value, userId || null]);
}
async function listFinalReportRecipients({ scopeType, scopeValue }) {
  const value = scopeType === "ALL" ? "" : String(scopeValue || "");
  const [rows] = await requireDb().query(`SELECT id,email,scope_type AS scopeType,scope_value AS scopeValue,last_used_at AS lastUsedAt
    FROM final_report_recipients WHERE (scope_type=? AND scope_value=?) OR scope_type='ALL'
    ORDER BY (scope_type=?) DESC, last_used_at DESC, id DESC LIMIT 30`, [scopeType, value, scopeType]);
  return rows;
}
async function deleteFinalReportRecipient(id) {
  const [result] = await requireDb().query("DELETE FROM final_report_recipients WHERE id=?", [id]);
  return result.affectedRows;
}

async function listEvaluationsForMentor(mentorId) {
  const [rows] = await requireDb().query(
    `SELECT ip.id AS internId, ip.full_name AS internName, ip.student_code AS studentCode,
            ev.id AS evaluationId, ev.skill_score AS skillScore,
            ev.attitude_score AS attitudeScore, ev.updated_at AS updatedAt
     FROM intern_profiles ip
     LEFT JOIN intern_evaluations ev ON ev.intern_id = ip.id
     WHERE ip.mentor_id = ?
     ORDER BY ip.full_name ASC, ip.id ASC`,
    [mentorId],
  );
  return rows;
}

const WEEKLY_ATTACHMENT_COLUMNS = `id, report_id AS reportId, original_name AS originalName,
            stored_name AS storedName, mime_type AS mimeType,
            size_bytes AS sizeBytes, uploaded_at AS uploadedAt`;

// Trả về { [reportId]: [attachment, ...] }.
async function listWeeklyReportAttachmentsByReportIds(reportIds) {
  const ids = [...new Set(reportIds.map(Number))].filter(Number.isFinite);
  if (ids.length === 0) return {};
  const [rows] = await requireDb().query(
    `SELECT ${WEEKLY_ATTACHMENT_COLUMNS} FROM weekly_report_attachments
     WHERE report_id IN (?) ORDER BY id ASC`,
    [ids],
  );
  const grouped = {};
  for (const row of rows) {
    (grouped[Number(row.reportId)] ||= []).push(row);
  }
  return grouped;
}

async function findWeeklyReportAttachmentById(reportId, attachmentId) {
  const [rows] = await requireDb().query(
    `SELECT ${WEEKLY_ATTACHMENT_COLUMNS} FROM weekly_report_attachments
     WHERE id = ? AND report_id = ? LIMIT 1`,
    [attachmentId, reportId],
  );
  return rows[0] || null;
}

// Khóa dòng báo cáo để hai request song song không vượt quá giới hạn số file.
// Trả về { outcome: 'SAVED' | 'LIMIT' | 'NOT_FOUND', attachment? }
async function insertWeeklyReportAttachmentLimited(
  { reportId, originalName, storedName, mimeType, sizeBytes },
  maxCount,
) {
  return withTransaction(async (conn) => {
    const [reports] = await conn.query(
      "SELECT id FROM weekly_reports WHERE id = ? FOR UPDATE",
      [reportId],
    );
    if (reports.length === 0) return { outcome: "NOT_FOUND" };

    const [[{ total }]] = await conn.query(
      "SELECT COUNT(*) AS total FROM weekly_report_attachments WHERE report_id = ?",
      [reportId],
    );
    if (Number(total) >= maxCount) return { outcome: "LIMIT" };

    const [result] = await conn.query(
      `INSERT INTO weekly_report_attachments
         (report_id, original_name, stored_name, mime_type, size_bytes)
       VALUES (?, ?, ?, ?, ?)`,
      [reportId, originalName, storedName, mimeType, sizeBytes],
    );
    const [rows] = await conn.query(
      `SELECT ${WEEKLY_ATTACHMENT_COLUMNS} FROM weekly_report_attachments WHERE id = ?`,
      [result.insertId],
    );
    return { outcome: "SAVED", attachment: rows[0] };
  });
}

async function deleteWeeklyReportAttachment(reportId, attachmentId) {
  const [result] = await requireDb().query(
    "DELETE FROM weekly_report_attachments WHERE id = ? AND report_id = ?",
    [attachmentId, reportId],
  );
  return result.affectedRows;
}

// ---------- TỆP ĐÍNH KÈM CỦA CẬP NHẬT TIẾN ĐỘ ----------
const ATTACHMENT_COLUMNS = `id, task_id AS taskId, original_name AS originalName,
            stored_name AS storedName, mime_type AS mimeType,
            size_bytes AS sizeBytes, uploaded_at AS uploadedAt`;

// Trả về { [taskId]: [attachment, ...] } cho danh sách nhiệm vụ.
async function listTaskAttachmentsByTaskIds(taskIds) {
  const ids = [...new Set(taskIds.map(Number))].filter(Number.isFinite);
  if (ids.length === 0) return {};
  const [rows] = await requireDb().query(
    `SELECT ${ATTACHMENT_COLUMNS} FROM task_attachments
     WHERE task_id IN (?) ORDER BY id ASC`,
    [ids],
  );
  const grouped = {};
  for (const row of rows) {
    (grouped[Number(row.taskId)] ||= []).push(row);
  }
  return grouped;
}

async function findTaskAttachmentById(taskId, attachmentId) {
  const [rows] = await requireDb().query(
    `SELECT ${ATTACHMENT_COLUMNS} FROM task_attachments
     WHERE id = ? AND task_id = ? LIMIT 1`,
    [attachmentId, taskId],
  );
  return rows[0] || null;
}

// Khóa dòng nhiệm vụ để hai request song song không vượt quá giới hạn số file.
// Trả về { outcome: 'SAVED' | 'LIMIT' | 'NOT_FOUND', attachment? }
async function insertTaskAttachmentLimited(
  { taskId, originalName, storedName, mimeType, sizeBytes },
  maxCount,
) {
  return withTransaction(async (conn) => {
    const [tasks] = await conn.query(
      "SELECT id FROM intern_tasks WHERE id = ? FOR UPDATE",
      [taskId],
    );
    if (tasks.length === 0) return { outcome: "NOT_FOUND" };

    const [[{ total }]] = await conn.query(
      "SELECT COUNT(*) AS total FROM task_attachments WHERE task_id = ?",
      [taskId],
    );
    if (Number(total) >= maxCount) return { outcome: "LIMIT" };

    const [result] = await conn.query(
      `INSERT INTO task_attachments
         (task_id, original_name, stored_name, mime_type, size_bytes)
       VALUES (?, ?, ?, ?, ?)`,
      [taskId, originalName, storedName, mimeType, sizeBytes],
    );
    // Gắn thời điểm cập nhật để mentor thấy có hoạt động mới.
    await conn.query(
      "UPDATE intern_tasks SET progress_updated_at = NOW() WHERE id = ?",
      [taskId],
    );
    const [rows] = await conn.query(
      `SELECT ${ATTACHMENT_COLUMNS} FROM task_attachments WHERE id = ?`,
      [result.insertId],
    );
    return { outcome: "SAVED", attachment: rows[0] };
  });
}

async function deleteTaskAttachment(taskId, attachmentId) {
  const [result] = await requireDb().query(
    "DELETE FROM task_attachments WHERE id = ? AND task_id = ?",
    [attachmentId, taskId],
  );
  return result.affectedRows;
}

async function deleteInternTask(id) {
  const [result] = await requireDb().query(
    "DELETE FROM intern_tasks WHERE id = ?",
    [id],
  );
  return result.affectedRows;
}

async function listScheduleMilestones(internId) {
  const [rows] = await requireDb().query(
    `SELECT id, intern_id AS internId, phase_order AS phaseOrder, title,
            start_date AS startDate, end_date AS endDate, duration_weeks AS durationWeeks,
            description, expected_results AS expectedResults, status,
            created_at AS createdAt, updated_at AS updatedAt
     FROM intern_schedules
     WHERE intern_id = ?
     ORDER BY phase_order ASC, start_date ASC, id ASC`,
    [internId],
  );
  return rows;
}

async function insertScheduleMilestone(internId, milestone) {
  const [result] = await requireDb().query(
    `INSERT INTO intern_schedules (intern_id, phase_order, title, start_date, end_date, duration_weeks, description, expected_results, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      internId,
      milestone.phase_order || 1,
      milestone.title,
      milestone.start_date || null,
      milestone.end_date || null,
      milestone.duration_weeks || null,
      milestone.description || null,
      milestone.expected_results || null,
      milestone.status || "NOT_STARTED",
    ],
  );
  return result.insertId;
}

async function insertScheduleMilestonesAtomic(internId, milestones) {
  return withTransaction(async (conn) => {
    const ids = [];
    for (const milestone of milestones) {
      const [result] = await conn.query(
        `INSERT INTO intern_schedules (intern_id, phase_order, title, start_date, end_date, duration_weeks, description, expected_results, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          internId,
          milestone.phase_order,
          milestone.title,
          milestone.start_date || null,
          milestone.end_date || null,
          milestone.duration_weeks || null,
          milestone.description || null,
          milestone.expected_results || null,
          milestone.status || "NOT_STARTED",
        ],
      );
      ids.push(result.insertId);
    }
    return ids;
  });
}

async function updateScheduleMilestone(internId, milestoneId, milestone) {
  const [result] = await requireDb().query(
    `UPDATE intern_schedules
     SET phase_order = COALESCE(?, phase_order),
         title = COALESCE(?, title),
         start_date = COALESCE(?, start_date),
         end_date = COALESCE(?, end_date),
         duration_weeks = COALESCE(?, duration_weeks),
         description = COALESCE(?, description),
         expected_results = COALESCE(?, expected_results),
         status = COALESCE(?, status)
     WHERE id = ? AND intern_id = ?`,
    [
      milestone.phase_order,
      milestone.title,
      milestone.start_date,
      milestone.end_date,
      milestone.duration_weeks,
      milestone.description,
      milestone.expected_results,
      milestone.status,
      milestoneId,
      internId,
    ],
  );
  return result.affectedRows > 0;
}

async function deleteScheduleMilestone(internId, milestoneId) {
  const [result] = await requireDb().query(
    `DELETE FROM intern_schedules WHERE id = ? AND intern_id = ?`,
    [milestoneId, internId],
  );
  return result.affectedRows > 0;
}

async function findMilestoneById(milestoneId) {
  const [rows] = await requireDb().query(
    `SELECT id, intern_id AS internId, phase_order AS phaseOrder, title,
            start_date AS startDate, end_date AS endDate, duration_weeks AS durationWeeks,
            description, expected_results AS expectedResults, status,
            created_at AS createdAt, updated_at AS updatedAt
     FROM intern_schedules WHERE id = ? LIMIT 1`,
    [milestoneId],
  );
  return rows[0] || null;
}

async function listContractsByInternId(internId) {
  const [rows] = await requireDb().query(
    `SELECT ${CONTRACT_COLUMNS} FROM internship_contracts
     WHERE intern_id = ? ORDER BY uploaded_at DESC, id DESC`,
    [internId],
  );
  return rows;
}

async function insertContract(contract) {
  return withTransaction(async (conn) => {
    const [result] = await conn.query(
      `INSERT INTO internship_contracts
         (intern_id, title, start_date, end_date, note, program_id, original_name,
          stored_name, mime_type, size_bytes, uploaded_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        contract.internId,
        contract.title,
        contract.startDate,
        contract.endDate,
        contract.note,
        contract.programId || null,
        contract.originalName,
        contract.storedName,
        contract.mimeType,
        contract.sizeBytes,
        contract.uploadedBy || null,
      ],
    );

    const [rows] = await conn.query(
      `SELECT ${CONTRACT_COLUMNS} FROM internship_contracts WHERE id = ?`,
      [result.insertId],
    );
    return rows[0];
  });
}

async function findContractById(internId, contractId) {
  const [rows] = await requireDb().query(
    `SELECT ${CONTRACT_COLUMNS} FROM internship_contracts
     WHERE id = ? AND intern_id = ? LIMIT 1`,
    [contractId, internId],
  );
  return rows[0] || null;
}

// Chỉ cho sửa chương trình và khoảng ngày hợp đồng (không đổi file/tiêu đề);
// cho phép cả hợp đồng đã xác nhận (đổi ngày thì phải xác nhận lại). `changes` dùng khóa camelCase.
const CONTRACT_UPDATABLE_COLUMNS = {
  programId: "program_id",
  startDate: "start_date",
  endDate: "end_date",
};

async function updateContractFields(internId, contractId, changes) {
  const keys = Object.keys(changes).filter((key) =>
    Object.hasOwn(CONTRACT_UPDATABLE_COLUMNS, key),
  );
  if (keys.length === 0) return findContractById(internId, contractId);

  const assignments = keys.map((key) => `${CONTRACT_UPDATABLE_COLUMNS[key]} = ?`);
  // Đổi điều khoản (ngày) của hợp đồng đã xác nhận -> đưa về chờ xác nhận lại.
  if (changes.resetConfirmation) {
    assignments.push(
      "confirmation_status = 'PENDING'",
      "confirmed_at = NULL",
      "confirmed_by = NULL",
    );
  }
  const [result] = await requireDb().query(
    `UPDATE internship_contracts SET ${assignments.join(", ")}
     WHERE id = ? AND intern_id = ?`,
    [...keys.map((key) => changes[key]), contractId, internId],
  );
  if (result.affectedRows === 0) return null;
  return findContractById(internId, contractId);
}

// Thực tập sinh đã có ít nhất 1 hợp đồng được xác nhận chưa (điều kiện giao việc / nộp báo cáo / đánh giá).
// ---------- Phụ cấp thực tập sinh (HR) ----------
const ALLOWANCE_SELECT = `a.id, a.intern_id AS internId, a.allowance_type AS allowanceType, a.amount,
  a.pay_cycle AS payCycle, DATE_FORMAT(a.effective_from,'%Y-%m-%d') AS effectiveFrom,
  DATE_FORMAT(a.effective_to,'%Y-%m-%d') AS effectiveTo, a.note,
  a.created_by AS createdBy, a.updated_by AS updatedBy, a.created_at AS createdAt, a.updated_at AS updatedAt`;
// DECIMAL trả về dạng chuỗi; số tiền VND luôn là số nguyên nên đổi sang Number.
function mapAllowance(row) {
  return row ? { ...row, amount: Number(row.amount) } : null;
}
async function listAllowancesByIntern(internId) {
  const [rows] = await requireDb().query(
    `SELECT ${ALLOWANCE_SELECT} FROM intern_allowances a WHERE a.intern_id = ?
     ORDER BY a.effective_from DESC, a.id DESC`,
    [internId],
  );
  return rows.map(mapAllowance);
}
async function findAllowanceById(id) {
  const [rows] = await requireDb().query(
    `SELECT ${ALLOWANCE_SELECT} FROM intern_allowances a WHERE a.id = ? LIMIT 1`,
    [id],
  );
  return mapAllowance(rows[0]);
}
// Tạo (id = null) hoặc sửa một khoản phụ cấp. Khóa dòng thực tập sinh để hai yêu cầu song song
// không cùng lọt qua bước kiểm tra trùng khoảng hiệu lực.
// Trả về { outcome: "SAVED" | "OVERLAP" | "NOT_FOUND", id }.
async function saveAllowanceAtomic({ id = null, internId, fields, userId }) {
  return withTransaction(async (conn) => {
    const [locked] = await conn.query(
      "SELECT id FROM intern_profiles WHERE id = ? FOR UPDATE",
      [internId],
    );
    if (!locked.length) return { outcome: "NOT_FOUND" };
    if (id !== null) {
      const [own] = await conn.query(
        "SELECT id FROM intern_allowances WHERE id = ? AND intern_id = ? FOR UPDATE",
        [id, internId],
      );
      if (!own.length) return { outcome: "NOT_FOUND" };
    }
    const [overlap] = await conn.query(
      `SELECT id FROM intern_allowances
       WHERE intern_id = ? AND allowance_type = ? AND id <> ?
         AND effective_from <= COALESCE(?, '9999-12-31')
         AND (effective_to IS NULL OR effective_to >= ?) LIMIT 1`,
      [internId, fields.allowanceType, id ?? 0, fields.effectiveTo, fields.effectiveFrom],
    );
    if (overlap.length) return { outcome: "OVERLAP" };
    const values = [
      fields.allowanceType, fields.amount, fields.payCycle,
      fields.effectiveFrom, fields.effectiveTo, fields.note,
    ];
    if (id === null) {
      const [result] = await conn.query(
        `INSERT INTO intern_allowances (intern_id, allowance_type, amount, pay_cycle,
           effective_from, effective_to, note, created_by, updated_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [internId, ...values, userId ?? null, userId ?? null],
      );
      return { outcome: "SAVED", id: result.insertId };
    }
    await conn.query(
      `UPDATE intern_allowances SET allowance_type = ?, amount = ?, pay_cycle = ?,
         effective_from = ?, effective_to = ?, note = ?, updated_by = ? WHERE id = ? AND intern_id = ?`,
      [...values, userId ?? null, id, internId],
    );
    return { outcome: "SAVED", id };
  });
}
async function deleteAllowance(id, internId) {
  const [result] = await requireDb().query(
    "DELETE FROM intern_allowances WHERE id = ? AND intern_id = ?",
    [id, internId],
  );
  return result.affectedRows > 0;
}
// Tổng quan toàn bộ thực tập sinh trong 1 truy vấn (không N+1); khoản "đang hiệu lực" tính theo `today`.
async function listAllowanceOverview({ filters = {}, today }) {
  const { buildInternFilterConditions } = require("./utils/internFilters");
  const { whereSql, params } = buildInternFilterConditions(filters, { includeUnassigned: false });
  const active = "effective_from <= ? AND (effective_to IS NULL OR effective_to >= ?)";
  const [rows] = await requireDb().query(
    `SELECT ip.id, ip.student_code AS studentCode, ip.full_name AS fullName, ip.email,
            ip.university, ip.major,
            COALESCE(s.totalCount, 0) AS totalCount,
            COALESCE(s.activeCount, 0) AS activeCount,
            COALESCE(s.totalMonthly, 0) AS totalMonthly,
            EXISTS(SELECT 1 FROM internship_contracts c
                   WHERE c.intern_id = ip.id AND c.confirmation_status = 'CONFIRMED') AS hasConfirmedContract
     FROM intern_profiles ip
     LEFT JOIN (
       SELECT intern_id, COUNT(*) AS totalCount,
              SUM(CASE WHEN ${active} THEN 1 ELSE 0 END) AS activeCount,
              SUM(CASE WHEN pay_cycle = 'MONTHLY' AND ${active} THEN amount ELSE 0 END) AS totalMonthly
       FROM intern_allowances GROUP BY intern_id
     ) s ON s.intern_id = ip.id
     ${whereSql} ORDER BY ip.id DESC`,
    [today, today, today, today, ...params],
  );
  return rows.map((r) => ({
    ...r,
    totalCount: Number(r.totalCount),
    activeCount: Number(r.activeCount),
    totalMonthly: Number(r.totalMonthly),
    hasConfirmedContract: Boolean(r.hasConfirmedContract),
  }));
}

async function hasConfirmedContract(internId) {
  const [rows] = await requireDb().query(
    `SELECT 1 FROM internship_contracts
     WHERE intern_id = ? AND confirmation_status = 'CONFIRMED' LIMIT 1`,
    [internId],
  );
  return rows.length > 0;
}

// Số hợp đồng gắn với chương trình nhưng nằm ngoài khoảng ngày [startDate, endDate] (null = không giới hạn).
async function countContractsOutsideProgramRange(programId, startDate, endDate) {
  const [rows] = await requireDb().query(
    `SELECT COUNT(*) AS n FROM internship_contracts
     WHERE program_id = ?
       AND ((? IS NOT NULL AND start_date IS NOT NULL AND start_date < ?)
         OR (? IS NOT NULL AND end_date IS NOT NULL AND end_date > ?))`,
    [programId, startDate, startDate, endDate, endDate],
  );
  return Number(rows[0].n);
}

async function deleteContract(internId, contractId) {
  return withTransaction(async (conn) => {
    const [rows] = await conn.query(
      `SELECT stored_name AS storedName,
              confirmation_status AS confirmationStatus
       FROM internship_contracts
       WHERE id = ? AND intern_id = ? FOR UPDATE`,
      [contractId, internId],
    );
    if (rows.length === 0) return { outcome: "NOT_FOUND" };
    if (rows[0].confirmationStatus !== "PENDING") {
      return { outcome: "CONFIRMED" };
    }

    const [result] = await conn.query(
      `DELETE FROM internship_contracts
       WHERE id = ? AND intern_id = ? AND confirmation_status = 'PENDING'`,
      [contractId, internId],
    );
    if (result.affectedRows === 0) return { outcome: "CONFIRMED" };
    return { outcome: "DELETED", storedName: rows[0].storedName };
  });
}

async function confirmContractAtomic(internId, contractId, userId) {
  return withTransaction(async (conn) => {
    const [result] = await conn.query(
      `UPDATE internship_contracts
       SET confirmation_status = 'CONFIRMED', confirmed_at = NOW(), confirmed_by = ?
       WHERE id = ? AND intern_id = ? AND confirmation_status = 'PENDING'`,
      [userId, contractId, internId],
    );
    if (result.affectedRows === 1) {
      const [rows] = await conn.query(
        `SELECT ${CONTRACT_COLUMNS} FROM internship_contracts
         WHERE id = ? AND intern_id = ? LIMIT 1`,
        [contractId, internId],
      );
      return { outcome: "CONFIRMED", contract: rows[0] || null };
    }

    const [rows] = await conn.query(
      `SELECT confirmation_status AS confirmationStatus
       FROM internship_contracts WHERE id = ? AND intern_id = ? LIMIT 1`,
      [contractId, internId],
    );
    if (rows.length === 0) return { outcome: "NOT_FOUND" };
    if (rows[0].confirmationStatus === "CONFIRMED") {
      return { outcome: "ALREADY_CONFIRMED" };
    }
    return { outcome: "NOT_PENDING" };
  });
}

async function listDepartments() {
  const [rows] = await requireDb().query(
    "SELECT id, name, description, created_at FROM departments ORDER BY name",
  );
  return rows;
}

async function findDepartmentByName(name) {
  const [rows] = await requireDb().query(
    "SELECT id, name, description, created_at FROM departments WHERE name = ? LIMIT 1",
    [name],
  );
  return rows[0] || null;
}

async function findDepartmentById(id) {
  const [rows] = await requireDb().query(
    "SELECT id, name FROM departments WHERE id = ? LIMIT 1",
    [id],
  );
  return rows[0] || null;
}

async function insertDepartment({ name, description }) {
  const [result] = await requireDb().query(
    "INSERT INTO departments (name, description) VALUES (?, ?)",
    [name, description || null],
  );
  return findDepartmentById(result.insertId);
}

async function deleteDepartment(id) {
  return withTransaction(async (conn) => {
    const [rows] = await conn.query(
      "SELECT id FROM departments WHERE id = ? FOR UPDATE",
      [id],
    );
    if (!rows.length) return "NOT_FOUND";
    const [programs] = await conn.query(
      "SELECT id FROM internship_programs WHERE department_id = ? LIMIT 1",
      [id],
    );
    if (programs.length) return "IN_USE";
    await conn.query("DELETE FROM departments WHERE id = ?", [id]);
    return "DELETED";
  });
}
const PROGRAM_SELECT = `SELECT p.id, p.department_id, d.name AS department_name, p.name, p.description,
  p.start_date, p.end_date, p.capacity, p.status, p.created_by, p.created_at, p.updated_at
  FROM internship_programs p JOIN departments d ON d.id = p.department_id`;
async function listPrograms({ departmentId, status } = {}) {
  const where = [];
  const values = [];

  if (departmentId) {
    where.push("p.department_id = ?");
    values.push(departmentId);
  }
  if (status) {
    where.push("p.status = ?");
    values.push(status);
  }

  const whereSql = where.length ? ` WHERE ${where.join(" AND ")}` : "";
  const [rows] = await requireDb().query(
    `${PROGRAM_SELECT}${whereSql} ORDER BY p.created_at DESC, p.id DESC`,
    values,
  );
  return rows;
}

// ---------- Chương trình & phân công mentor (US12) ----------
// Thành viên chương trình do HR tự xếp (bảng program_interns), không phụ thuộc hợp đồng.
async function listProgramInterns(programId) {
  const [rows] = await requireDb().query(
    `SELECT ip.id, ip.student_code AS studentCode, ip.full_name AS fullName, ip.email, ip.university, ip.status,
            ip.mentor_id AS mentorId, ip.mentor_name AS mentorName,
            pi.completion_status AS completionStatus, pi.completed_at AS completedAt, pi.completed_by AS completedBy,
            pi.completion_note AS completionNote, pi.result_updated_at AS resultUpdatedAt
     FROM program_interns pi JOIN intern_profiles ip ON ip.id = pi.intern_id
     WHERE pi.program_id = ? ORDER BY ip.full_name, ip.id`,
    [programId],
  );
  return rows;
}
// Thực tập sinh chưa thuộc chương trình (để HR chọn thêm vào).
async function listInternsNotInProgram(programId) {
  const [rows] = await requireDb().query(
    `SELECT ip.id, ip.student_code AS studentCode, ip.full_name AS fullName, ip.university
     FROM intern_profiles ip
     WHERE NOT EXISTS (SELECT 1 FROM program_interns pi WHERE pi.program_id = ? AND pi.intern_id = ip.id)
     ORDER BY ip.full_name, ip.id`,
    [programId],
  );
  return rows;
}
// Thêm nhiều thực tập sinh vào chương trình; không vượt quá sức chứa (capacity) của chương trình.
// Serialize enrollment/date/result writes across all app processes for this DB.
// Taking the advisory lock BEFORE the transaction avoids stale snapshots.
async function assertNoFinalizedProgramResults(conn,internId) {
  const [results] = await conn.query("SELECT id FROM program_interns WHERE intern_id=? AND completion_status IN ('COMPLETED','NOT_COMPLETED') LIMIT 1 FOR UPDATE",[internId]);
  if (results.length) throw new ConflictError("Không thể xóa hồ sơ/tài khoản có kết quả chương trình đã chốt; cần giữ lịch sử!",409);
}
async function withProgramMembershipTransaction(work) {
  const conn = await requireDb().getConnection();
  let acquired = false;
  try {
    const [[lock]] = await conn.query("SELECT GET_LOCK(CONCAT('us6:',MD5(DATABASE())),10) AS acquired");
    acquired = Number(lock.acquired) === 1;
    if (!acquired) throw new (require("./errors").HttpError)(409, "Phân công đang được cập nhật, vui lòng thử lại!");
    await conn.beginTransaction();
    try { const result = await work(conn); await conn.commit(); return result; }
    catch (err) { await conn.rollback(); throw err; }
  } finally {
    if (acquired) await conn.query("SELECT RELEASE_LOCK(CONCAT('us6:',MD5(DATABASE())))").catch(() => {});
    conn.release();
  }
}
async function enrollmentConflicts(conn, programId, internIds, start, end, includeUnknown = true) {
  if (!internIds.length) return [];
  const [rows] = await conn.query(`SELECT pi.intern_id AS internId, p.id AS programId, p.name AS programName
    FROM program_interns pi JOIN internship_programs p ON p.id=pi.program_id
    WHERE pi.intern_id IN (?) AND pi.program_id <> ?
      AND (${includeUnknown ? 'p.start_date IS NULL OR p.end_date IS NULL OR' : ''} p.start_date <= ? AND p.end_date >= ?)
    ORDER BY pi.intern_id,p.id`, [internIds, programId, end, start]);
  return rows;
}
async function addProgramInterns(programId, internIds, userId) {
  return withProgramMembershipTransaction(async conn => {
    const [[program]] = await conn.query("SELECT capacity,start_date,end_date FROM internship_programs WHERE id=? FOR UPDATE", [programId]);
    if (!program) return { outcome: "PROGRAM_NOT_FOUND" };
    const [found] = await conn.query("SELECT id FROM intern_profiles WHERE id IN (?) ORDER BY id FOR UPDATE", [internIds]);
    const foundIds = new Set(found.map(r => Number(r.id)));
    const missing = internIds.filter(id => !foundIds.has(id));
    if (missing.length) return { outcome: "INTERN_NOT_FOUND", missing };
    const [current] = await conn.query("SELECT intern_id FROM program_interns WHERE program_id=?", [programId]);
    const members = new Set(current.map(r => Number(r.intern_id)));
    const toAdd = internIds.filter(id => !members.has(id));
    if (!toAdd.length) return { outcome: "ADDED", added: [], already: internIds.length };
    if (!program.start_date || !program.end_date) return { outcome: "DATES_REQUIRED" };
    if (program.capacity != null && members.size + toAdd.length > Number(program.capacity))
      return { outcome: "CAPACITY_EXCEEDED", capacity: Number(program.capacity), current: members.size };
    const conflicts = await enrollmentConflicts(conn, programId, toAdd, program.start_date, program.end_date);
    if (conflicts.length) return { outcome: "OVERLAP", conflicts };
    await conn.query("INSERT INTO program_interns (program_id,intern_id,assigned_by) VALUES ?", [toAdd.map(id => [programId,id,userId || null])]);
    return { outcome: "ADDED", added: toAdd, already: internIds.length-toAdd.length };
  });
}
async function setProgramCompletion(programId, internId, values, userId, today) {
  return withProgramMembershipTransaction(async conn => {
    const [[row]] = await conn.query(`SELECT pi.*,p.start_date,p.end_date,p.status AS programStatus,
      i.mentor_id AS mentorId,COALESCE(m.full_name COLLATE utf8mb4_unicode_ci,i.mentor_name COLLATE utf8mb4_unicode_ci) AS mentorName
      FROM program_interns pi JOIN internship_programs p ON p.id=pi.program_id
      JOIN intern_profiles i ON i.id=pi.intern_id LEFT JOIN mentors m ON m.id=i.mentor_id
      WHERE pi.program_id=? AND pi.intern_id=? FOR UPDATE`, [programId,internId]);
    if (!row) return { outcome: "NOT_FOUND" };
    const terminal = ["COMPLETED","NOT_COMPLETED"];
    if (terminal.includes(row.completion_status)) {
      if (row.completion_status === values.status && (row.completion_note || "") === values.note) return { outcome: "SAVED", already: true };
      return { outcome: "FINALIZED" };
    }
    if (terminal.includes(values.status) && (!row.start_date || !row.end_date || row.start_date > today || !["ONGOING","CLOSED"].includes(row.programStatus))) return { outcome: "NOT_STARTED" };
    if (terminal.includes(values.status)) {
      const conflicts = await enrollmentConflicts(conn,programId,[internId],row.start_date,row.end_date);
      if (conflicts.length) return { outcome: "OVERLAP" };
    }
    await conn.query(`UPDATE program_interns SET completion_status=?,completion_note=?,result_updated_at=NOW(),
      completed_at=IF(?='COMPLETED',NOW(),NULL),completed_by=IF(? IN ('COMPLETED','NOT_COMPLETED'),?,NULL),result_mentor_id=?,result_mentor_name=? WHERE id=?`,
      [values.status,values.note,values.status,values.status,userId,terminal.includes(values.status)?row.mentorId:null,terminal.includes(values.status)?row.mentorName:null,row.id]);
    return { outcome: "SAVED", already: false };
  });
}
async function removeProgramIntern(programId, internId) {
  return withProgramMembershipTransaction(async conn => {
    const [[row]] = await conn.query("SELECT completion_status FROM program_interns WHERE program_id=? AND intern_id=? FOR UPDATE", [programId,internId]);
    if (!row) return 0;
    if (["COMPLETED","NOT_COMPLETED"].includes(row.completion_status)) throw new (require("./errors").HttpError)(409,"Không thể gỡ thành viên đã chốt kết quả; cần giữ lịch sử chương trình!");
    const [result] = await conn.query("DELETE FROM program_interns WHERE program_id=? AND intern_id=?", [programId,internId]);
    return result.affectedRows;
  });
}

// Gán (hoặc gỡ, mentorId = null) mentor cho nhiều thực tập sinh của một chương trình trong một transaction.
// internIds = null nghĩa là toàn bộ thực tập sinh của chương trình.
async function assignProgramInternsMentor(programId, mentorId, internIds) {
  try {
    return await withTransaction(async (conn) => {
      let mentorName = "";
      if (mentorId != null) {
        const [mentorRows] = await conn.query("SELECT full_name FROM mentors WHERE id = ? FOR UPDATE", [mentorId]);
        if (mentorRows.length === 0) return { outcome: "MENTOR_NOT_FOUND" };
        mentorName = mentorRows[0].full_name;
      }
      const [members] = await conn.query(
        `SELECT ip.id, ip.full_name AS fullName, ip.email, ip.mentor_id AS mentorId
         FROM program_interns pi JOIN intern_profiles ip ON ip.id = pi.intern_id
         WHERE pi.program_id = ? ORDER BY ip.id FOR UPDATE`,
        [programId],
      );
      if (members.length === 0) return { outcome: "NO_INTERNS" };
      let targets = members;
      if (internIds) {
        const inProgram = new Set(members.map((m) => Number(m.id)));
        const missing = internIds.filter((id) => !inProgram.has(id));
        if (missing.length) return { outcome: "INTERN_NOT_IN_PROGRAM", missing };
        const wanted = new Set(internIds);
        targets = members.filter((m) => wanted.has(Number(m.id)));
      }
      const same = (m) => (m.mentorId == null ? null : Number(m.mentorId)) === (mentorId == null ? null : Number(mentorId));
      const changed = targets.filter((m) => !same(m));
      if (changed.length)
        await conn.query("UPDATE intern_profiles SET mentor_id = ?, mentor_name = ? WHERE id IN (?)", [mentorId, mentorName, changed.map((m) => m.id)]);
      return { outcome: "UPDATED", mentorName, changed, unchanged: targets.length - changed.length };
    });
  } catch (err) {
    if (mentorId != null && err.code === "ER_NO_REFERENCED_ROW_2") return { outcome: "MENTOR_NOT_FOUND" };
    throw err;
  }
}

async function findProgramById(id) {
  const [rows] = await requireDb().query(
    `${PROGRAM_SELECT} WHERE p.id = ? LIMIT 1`,
    [id],
  );
  return rows[0] || null;
}
async function saveProgramAtomic(value, { id = null, createdBy = null } = {}) {
  return withProgramMembershipTransaction(async conn => {
    if (id != null) {
      const [[existing]] = await conn.query("SELECT id,start_date,end_date FROM internship_programs WHERE id=? FOR UPDATE", [id]);
      if (!existing) return { outcome: "NOT_FOUND" };
      const [members] = await conn.query("SELECT intern_id,completion_status FROM program_interns WHERE program_id=?", [id]);
      const changed = existing.start_date !== value.startDate || existing.end_date !== value.endDate;
      if (members.length && changed) {
        if (members.some(r => ["COMPLETED","NOT_COMPLETED"].includes(r.completion_status))) return { outcome: "RESULTS_FINALIZED" };
        if (!value.startDate || !value.endDate) return { outcome: "DATES_REQUIRED" };
        const conflicts = await enrollmentConflicts(conn,id,members.map(r=>Number(r.intern_id)),value.startDate,value.endDate,!!existing.start_date && !!existing.end_date);
        if (conflicts.length) return { outcome: "OVERLAP" };
      }
      if (value.capacity != null && Number(value.capacity) < members.length) return { outcome: "CAPACITY_BELOW_MEMBERS" };
    }
    const [duplicates] = await conn.query(`SELECT id FROM internship_programs WHERE department_id=? AND LOWER(name)=LOWER(?)
      AND (end_date IS NULL OR ? IS NULL OR end_date>=?) AND (start_date IS NULL OR ? IS NULL OR start_date<=?)
      AND (? IS NULL OR id<>?) LIMIT 1`,[value.departmentId,value.name,value.startDate,value.startDate,value.endDate,value.endDate,id,id]);
    if (duplicates.length) return { outcome: "DUPLICATE" };
    const values = [value.departmentId,value.name,value.description || null,value.startDate,value.endDate,value.capacity,value.status];
    if (id == null) {
      const [result] = await conn.query("INSERT INTO internship_programs (department_id,name,description,start_date,end_date,capacity,status,created_by) VALUES (?,?,?,?,?,?,?,?)",[...values,createdBy]);
      id = result.insertId;
    } else await conn.query("UPDATE internship_programs SET department_id=?,name=?,description=?,start_date=?,end_date=?,capacity=?,status=? WHERE id=?",[...values,id]);
    return { outcome: "SAVED",id };
  });
}
async function deleteProgram(id) {
  return withProgramMembershipTransaction(async conn => {
    const [[program]] = await conn.query("SELECT status FROM internship_programs WHERE id=? FOR UPDATE",[id]);
    if (!program) return "NOT_FOUND";
    if (program.status === "ONGOING") return "ONGOING";
    const [members] = await conn.query("SELECT id FROM program_interns WHERE program_id=? LIMIT 1",[id]);
    if (members.length) return "HAS_MEMBERS";
    await conn.query("DELETE FROM internship_programs WHERE id=?",[id]);
    return "DELETED";
  });
}

// Số liệu tổng quan cho tab Báo cáo & Thống kê: toàn bộ lấy từ dữ liệu thật trong DB.
async function getOverviewStats() {
  const db = requireDb();
  const [[applications]] = await db.query(
    `SELECT COUNT(*) AS total,
            COALESCE(SUM(status = 'Chờ duyệt'), 0) AS pending,
            COALESCE(SUM(status = 'Đã duyệt'), 0) AS approved,
            COALESCE(SUM(status = 'Từ chối'), 0) AS rejected
       FROM candidate_profiles`,
  );
  const [[interns]] = await db.query(
    `SELECT COUNT(*) AS total,
            COALESCE(SUM(mentor_id IS NOT NULL), 0) AS assigned
       FROM intern_profiles`,
  );
  const [[contracts]] = await db.query(
    `SELECT COUNT(*) AS total,
            COALESCE(SUM(confirmation_status = 'CONFIRMED'), 0) AS confirmed
       FROM internship_contracts`,
  );
  return {
    applications: {
      total: Number(applications.total),
      pending: Number(applications.pending),
      approved: Number(applications.approved),
      rejected: Number(applications.rejected),
    },
    interns: {
      total: Number(interns.total),
      assigned: Number(interns.assigned),
    },
    contracts: {
      total: Number(contracts.total),
      confirmed: Number(contracts.confirmed),
    },
  };
}

// US5: Thống kê thực tập sinh theo trường / ngành
async function getInternOriginCounts(filters = {}) {
  const db = requireDb();
  const conditions = [];
  const params = [];
  if (filters.status) {
    conditions.push("status = ?");
    params.push(filters.status);
  }
  if (filters.from) {
    conditions.push("DATE(created_at) >= ?");
    params.push(filters.from);
  }
  if (filters.to) {
    conditions.push("DATE(created_at) <= ?");
    params.push(filters.to);
  }
  if (filters.q) {
    const escaped = String(filters.q).replace(/([%_\\])/g, "\\$1");
    conditions.push("(university LIKE ? ESCAPE '\\\\' OR major LIKE ? ESCAPE '\\\\')");
    params.push(`%${escaped}%`, `%${escaped}%`);
  }
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  const [rows] = await db.query(
    `SELECT ANY_VALUE(university) AS university, ANY_VALUE(major) AS major, COUNT(*) AS count
       FROM intern_profiles
      ${where}
      GROUP BY BINARY university, BINARY major`,
    params,
  );
  return rows;
}

async function getCandidateFunnelByUniversity(filters = {}) {
  const db = requireDb();
  const conditions = [];
  const params = [];
  if (filters.from) {
    conditions.push("DATE(applied_at) >= ?");
    params.push(filters.from);
  }
  if (filters.to) {
    conditions.push("DATE(applied_at) <= ?");
    params.push(filters.to);
  }
  if (filters.q) {
    const escaped = String(filters.q).replace(/([%_\\])/g, "\\$1");
    conditions.push("university LIKE ? ESCAPE '\\\\'");
    params.push(`%${escaped}%`);
  }
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  const [rows] = await db.query(
    `SELECT ANY_VALUE(university) AS university, status, COUNT(*) AS count
       FROM candidate_profiles
      ${where}
      GROUP BY BINARY university, status`,
    params,
  );
  return rows;
}

async function listInternsByOrigin(filters = {}) {
  const db = requireDb();
  const conditions = [];
  const params = [];
  if (filters.status) {
    conditions.push("i.status = ?");
    params.push(filters.status);
  }
  if (filters.from) {
    conditions.push("DATE(i.created_at) >= ?");
    params.push(filters.from);
  }
  if (filters.to) {
    conditions.push("DATE(i.created_at) <= ?");
    params.push(filters.to);
  }
  if (filters.q) {
    const escaped = String(filters.q).replace(/([%_\\])/g, "\\$1");
    conditions.push("(i.university LIKE ? ESCAPE '\\\\' OR i.major LIKE ? ESCAPE '\\\\')");
    params.push(`%${escaped}%`, `%${escaped}%`);
  }
  // Map canonical chart labels back to every raw stored variant using the same JS key.
  // Binary equality prevents MySQL collation from merging distinct raw spellings.
  for (const [column, value, unknownFlag] of [
    ["university", filters.university, filters.isUnknownUniversity],
    ["major", filters.major, filters.isUnknownMajor],
  ]) {
    if (!value) continue;
    if (value === "Khác") {
      conditions.push("1 = 0"); // Không trả danh sách sai nhóm khi thiếu thành viên bucket.
      continue;
    }
    const [variants] = await db.query(`SELECT ANY_VALUE(${column}) AS value FROM intern_profiles GROUP BY BINARY ${column}`);
    const matches = variants
      .filter((row) => unknownFlag
        ? row.value == null || ["", "chua cap nhat"].includes(filters.normalizeKey(row.value))
        : filters.normalizeKey(row.value) === filters.normalizeKey(value))
      .map((row) => row.value);
    const nonNullMatches = matches.filter((raw) => raw != null);
    if (!matches.length) { conditions.push("1 = 0"); continue; }
    if (unknownFlag) {
      conditions.push(`(i.${column} IS NULL${nonNullMatches.length ? ` OR BINARY i.${column} IN (${nonNullMatches.map(() => "?").join(", ")})` : ""})`);
      params.push(...nonNullMatches);
      continue;
    }
    conditions.push(`BINARY i.${column} IN (${matches.map(() => '?').join(', ')})`);
    params.push(...matches);
  }
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

  const [[countRow]] = await db.query(
    `SELECT COUNT(*) AS total FROM intern_profiles i ${where}`,
    params,
  );
  const total = Number(countRow.total || 0);

  const page = Math.max(1, Number(filters.page) || 1);
  const pageSize = Math.min(100, Math.max(1, Number(filters.pageSize) || 20));
  const offset = (page - 1) * pageSize;

  const [rows] = await db.query(
    `SELECT i.id, i.full_name AS fullName, i.student_code AS studentCode,
            i.university, i.major, i.status,
            COALESCE(i.mentor_name, m.full_name) AS mentorName
       FROM intern_profiles i
       LEFT JOIN mentors m ON i.mentor_id = m.id
      ${where}
      ORDER BY i.id DESC
      LIMIT ? OFFSET ?`,
    [...params, pageSize, offset],
  );

  return {
    items: rows,
    pagination: {
      page,
      pageSize,
      total,
      totalPages: Math.ceil(total / pageSize) || 1,
    },
  };
}

// US7/US8 data access. The schedule resolver returns the most specific active assignment.
// ---------- Lịch làm việc ----------
function mapWorkSchedule(row, days) {
  return {
    id: Number(row.id),
    name: row.name,
    description: row.description || "",
    mode: row.mode,
    graceMinutes: Number(row.grace_minutes),
    minDailyMinutes: row.min_daily_minutes == null ? null : Number(row.min_daily_minutes),
    assignmentCount: Number(row.assignmentCount || 0),
    days: days.map((d) => ({
      weekday: Number(d.weekday),
      isWorking: !!d.isWorking,
      startTime: d.startTime,
      endTime: d.endTime,
    })),
  };
}
const WORK_SCHEDULE_DAY_COLUMNS = `schedule_id AS scheduleId, weekday, is_working AS isWorking,
  TIME_FORMAT(start_time,'%H:%i') AS startTime, TIME_FORMAT(end_time,'%H:%i') AS endTime`;
async function listWorkSchedules() {
  const pool = requireDb();
  const [rows] = await pool.query(`SELECT s.*,
    (SELECT COUNT(*) FROM work_schedule_assignments a WHERE a.schedule_id = s.id) AS assignmentCount
    FROM work_schedules s ORDER BY s.name`);
  const [days] = await pool.query(`SELECT ${WORK_SCHEDULE_DAY_COLUMNS} FROM work_schedule_days ORDER BY schedule_id, weekday`);
  return rows.map((row) => mapWorkSchedule(row, days.filter((d) => Number(d.scheduleId) === Number(row.id))));
}
async function findWorkSchedule(id) {
  const pool = requireDb();
  const [rows] = await pool.query(`SELECT s.*,
    (SELECT COUNT(*) FROM work_schedule_assignments a WHERE a.schedule_id = s.id) AS assignmentCount
    FROM work_schedules s WHERE s.id = ? LIMIT 1`, [id]);
  if (!rows[0]) return null;
  const [days] = await pool.query(`SELECT ${WORK_SCHEDULE_DAY_COLUMNS} FROM work_schedule_days WHERE schedule_id = ? ORDER BY weekday`, [id]);
  return mapWorkSchedule(rows[0], days);
}
async function saveWorkSchedule(id, input) {
  const conn = await requireDb().getConnection();
  try {
    await conn.beginTransaction();
    const minDaily = input.mode === "FLEXIBLE" ? input.minDailyMinutes : null;
    const values = [input.name, input.description, input.mode, input.graceMinutes ?? 15, minDaily];
    let scheduleId = id;
    if (id) {
      await conn.query("UPDATE work_schedules SET name=?, description=?, mode=?, grace_minutes=?, min_daily_minutes=? WHERE id=?", [...values, id]);
    } else {
      const [result] = await conn.query("INSERT INTO work_schedules (name,description,mode,grace_minutes,min_daily_minutes) VALUES (?,?,?,?,?)", values);
      scheduleId = result.insertId;
    }
    if (input.days) {
      await conn.query("DELETE FROM work_schedule_days WHERE schedule_id=?", [scheduleId]);
      for (const d of input.days) {
        const hasHours = d.isWorking && input.mode === "FIXED";
        await conn.query("INSERT INTO work_schedule_days (schedule_id,weekday,is_working,start_time,end_time) VALUES (?,?,?,?,?)",
          [scheduleId, d.weekday, d.isWorking ? 1 : 0, hasHours ? d.startTime : null, hasHours ? d.endTime : null]);
      }
    }
    await conn.commit();
    return findWorkSchedule(scheduleId);
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}
// Lịch mặc định (id=1) và lịch đang được áp dụng không xóa được.
async function deleteWorkSchedule(id) {
  const [result] = await requireDb().query(`DELETE FROM work_schedules WHERE id=? AND id<>1
    AND NOT EXISTS (SELECT 1 FROM work_schedule_assignments a WHERE a.schedule_id = work_schedules.id)`, [id]);
  return result.affectedRows;
}
async function listWorkScheduleAssignments() {
  const [rows] = await requireDb().query(`SELECT a.id, a.schedule_id AS scheduleId, s.name AS scheduleName,
    a.target_type AS targetType, a.target_value AS targetValue,
    DATE_FORMAT(a.effective_from,'%Y-%m-%d') AS effectiveFrom, DATE_FORMAT(a.effective_to,'%Y-%m-%d') AS effectiveTo,
    a.created_by AS createdBy
    FROM work_schedule_assignments a JOIN work_schedules s ON s.id = a.schedule_id
    ORDER BY FIELD(a.target_type,'DEFAULT','UNIVERSITY','PROGRAM','MENTOR','INTERN'), a.target_value, a.effective_from DESC`);
  return rows;
}
// planChange(existingRows) -> { conflict, close: [{ id, effectiveTo }] } (hàm thuần, xem planAssignmentChange).
async function createWorkScheduleAssignment(input, planChange) {
  const conn = await requireDb().getConnection();
  try {
    await conn.beginTransaction();
    const [existing] = await conn.query(`SELECT id, DATE_FORMAT(effective_from,'%Y-%m-%d') AS effectiveFrom,
      DATE_FORMAT(effective_to,'%Y-%m-%d') AS effectiveTo FROM work_schedule_assignments
      WHERE target_type=? AND target_value=? FOR UPDATE`, [input.targetType, input.targetValue]);
    const plan = planChange(existing);
    if (plan.conflict) {
      await conn.rollback();
      return { conflict: true };
    }
    for (const item of plan.close)
      await conn.query("UPDATE work_schedule_assignments SET effective_to=? WHERE id=?", [item.effectiveTo, item.id]);
    const [result] = await conn.query(`INSERT INTO work_schedule_assignments
      (schedule_id,target_type,target_value,effective_from,effective_to,created_by) VALUES (?,?,?,?,?,?)`,
      [input.scheduleId, input.targetType, input.targetValue, input.effectiveFrom, input.effectiveTo || null, input.createdBy || null]);
    await conn.commit();
    return { id: result.insertId };
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}
async function deleteWorkScheduleAssignment(id) {
  const [result] = await requireDb().query("DELETE FROM work_schedule_assignments WHERE id=? AND target_type<>'DEFAULT'", [id]);
  return result.affectedRows;
}
async function workScheduleTargetExists(type, value) {
  const queries = {
    UNIVERSITY: "SELECT 1 FROM intern_profiles WHERE university = ? LIMIT 1",
    PROGRAM: "SELECT 1 FROM internship_programs WHERE id = ? LIMIT 1",
    MENTOR: "SELECT 1 FROM mentors WHERE id = ? LIMIT 1",
    INTERN: "SELECT 1 FROM intern_profiles WHERE id = ? LIMIT 1",
  };
  if (!queries[type]) return false;
  const [rows] = await requireDb().query(queries[type], [value]);
  return rows.length > 0;
}
async function listWorkHolidays() {
  const [rows] = await requireDb().query("SELECT id, DATE_FORMAT(holiday_date,'%Y-%m-%d') AS holidayDate, name FROM work_holidays ORDER BY holiday_date");
  return rows;
}
async function addWorkHoliday(date, name) {
  const [result] = await requireDb().query("INSERT INTO work_holidays (holiday_date,name) VALUES (?,?)", [date, name]);
  return result.insertId;
}
async function deleteWorkHoliday(id) {
  const [result] = await requireDb().query("DELETE FROM work_holidays WHERE id=?", [id]);
  return result.affectedRows;
}
// Toàn bộ dữ liệu cần để tính lịch áp dụng trong bộ nhớ (các bảng nhỏ, tải một lần).
async function loadWorkScheduleContext() {
  const pool = requireDb();
  const [schedules, assignments, [programs], [mentors]] = await Promise.all([
    listWorkSchedules(),
    listWorkScheduleAssignments(),
    pool.query("SELECT id, name FROM internship_programs"),
    pool.query("SELECT id, full_name AS name FROM mentors"),
  ]);
  return { schedules, assignments, programs, mentors };
}
// Hợp đồng đã xác nhận (ngày có thể null = không giới hạn đầu/cuối).
async function listConfirmedContractsForInterns(internIds) {
  if (!internIds.length) return [];
  const [rows] = await requireDb().query(`SELECT id, intern_id AS internId, program_id AS programId,
    DATE_FORMAT(start_date,'%Y-%m-%d') AS startDate, DATE_FORMAT(end_date,'%Y-%m-%d') AS endDate, confirmed_at AS confirmedAt
    FROM internship_contracts WHERE confirmation_status='CONFIRMED' AND intern_id IN (?)`, [internIds]);
  return rows;
}
// Thành viên chương trình do HR xếp (program_interns), cùng hình dạng với hợp đồng để dùng chung hàm tìm chương trình:
// startDate/endDate là ngày của chương trình (null = không giới hạn), confirmedAt là thời điểm HR xếp.
async function listProgramMembershipsForInterns(internIds) {
  if (!internIds.length) return [];
  const [rows] = await requireDb().query(`SELECT pi.id, pi.intern_id AS internId, pi.program_id AS programId,
    DATE_FORMAT(p.start_date,'%Y-%m-%d') AS startDate, DATE_FORMAT(p.end_date,'%Y-%m-%d') AS endDate,
    DATE_FORMAT(pi.created_at,'%Y-%m-%d %H:%i:%s') AS confirmedAt
    FROM program_interns pi JOIN internship_programs p ON p.id = pi.program_id WHERE pi.intern_id IN (?)`, [internIds]);
  return rows;
}
async function listAttendanceForInterns(internIds, from, to) {
  if (!internIds.length) return [];
  const [rows] = await requireDb().query(`SELECT ${ATTENDANCE_COLUMNS} FROM attendance_records a
    WHERE a.intern_id IN (?) AND a.work_date BETWEEN ? AND ? ORDER BY a.work_date`, [internIds, from, to]);
  return rows;
}

// ---------- Nghỉ phép ----------
const LEAVE_COLUMNS = `l.id, l.intern_id AS internId, l.leave_type AS leaveType,
  DATE_FORMAT(l.from_date,'%Y-%m-%d') AS fromDate, DATE_FORMAT(l.to_date,'%Y-%m-%d') AS toDate,
  l.reason, l.status, l.reviewed_by AS reviewedBy, DATE_FORMAT(l.reviewed_at,'%Y-%m-%d %H:%i:%s') AS reviewedAt,
  l.review_note AS reviewNote, DATE_FORMAT(l.created_at,'%Y-%m-%d %H:%i:%s') AS createdAt`;
async function listLeaves(internId, from, to) {
  const ranged = Boolean(from && to);
  const [rows] = await requireDb().query(`SELECT ${LEAVE_COLUMNS} FROM leave_requests l WHERE l.intern_id = ?
    ${ranged ? "AND l.to_date >= ? AND l.from_date <= ?" : ""} ORDER BY l.from_date DESC, l.id DESC`,
    ranged ? [internId, from, to] : [internId]);
  return rows;
}
async function listLeavesForInterns(internIds, from, to) {
  if (!internIds.length) return [];
  const [rows] = await requireDb().query(`SELECT ${LEAVE_COLUMNS} FROM leave_requests l
    WHERE l.intern_id IN (?) AND l.status IN ('PENDING','APPROVED') AND l.to_date >= ? AND l.from_date <= ?`, [internIds, from, to]);
  return rows;
}
async function listLeavesForStaff({ status = null, internId = null, from = null, to = null, mentorId = null, limit = 200 } = {}) {
  const where = [];
  const params = [];
  if (status) { where.push("l.status = ?"); params.push(status); }
  if (internId) { where.push("l.intern_id = ?"); params.push(internId); }
  if (from) { where.push("l.to_date >= ?"); params.push(from); }
  if (to) { where.push("l.from_date <= ?"); params.push(to); }
  if (mentorId) { where.push("ip.mentor_id = ?"); params.push(mentorId); }
  const [rows] = await requireDb().query(`SELECT ${LEAVE_COLUMNS}, ip.full_name AS fullName, ip.student_code AS studentCode
    FROM leave_requests l JOIN intern_profiles ip ON ip.id = l.intern_id
    ${where.length ? "WHERE " + where.join(" AND ") : ""} ORDER BY l.created_at DESC, l.id DESC LIMIT ?`, [...params, limit]);
  return rows;
}
async function listPendingLeaves(mentorId = null) {
  return listLeavesForStaff({ status: "PENDING", mentorId });
}
async function createLeave(input) {
  const [result] = await requireDb().query("INSERT INTO leave_requests (intern_id,leave_type,from_date,to_date,reason) VALUES (?,?,?,?,?)",
    [input.internId, input.leaveType, input.fromDate, input.toDate, input.reason]);
  return result.insertId;
}
// Email các tài khoản HR đang hoạt động (dùng để báo có đơn nghỉ phép mới)
async function listActiveHrEmails() {
  const [rows] = await requireDb().query(
    `SELECT u.email FROM users u JOIN roles r ON u.role_id = r.id
     WHERE r.role_name = 'HR' AND u.status = 'ACTIVE'`,
  );
  return rows.map((r) => r.email);
}
// ---------- Thông báo trong app (chuông) ----------
async function listActiveHrUserIds() {
  const [rows] = await requireDb().query(
    `SELECT u.id FROM users u JOIN roles r ON u.role_id = r.id WHERE r.role_name = 'HR' AND u.status = 'ACTIVE'`);
  return rows.map((r) => r.id);
}
async function findMentorUserId(mentorId) {
  if (!mentorId) return null;
  const [rows] = await requireDb().query(
    `SELECT u.id FROM mentors m JOIN users u ON LOWER(u.email) = LOWER(m.email) WHERE m.id = ? LIMIT 1`, [mentorId]);
  return rows[0] ? rows[0].id : null;
}
async function createNotifications(userIds, n) {
  const ids = [...new Set(userIds.filter(Boolean))];
  if (!ids.length) return 0;
  // dedupeKey: cùng (tài khoản, khóa) chỉ tạo một lần (dùng cho thông báo nhắc lịch); trả về số dòng thực sự được tạo.
  const dedupe = n.dedupeKey || null;
  const [result] = await requireDb().query(
    `INSERT ${dedupe ? "IGNORE " : ""}INTO notifications (user_id,type,title,message,target_tab,ref_id,dedupe_key) VALUES ?`,
    [ids.map((id) => [id, n.type, n.title, n.message, n.targetTab || null, n.refId || null, dedupe])]);
  return result.affectedRows;
}
// Tài khoản (users) của các hồ sơ thực tập sinh, ghép theo email.
async function findUserIdsByInternIds(internIds) {
  if (!internIds.length) return [];
  const [rows] = await requireDb().query(
    `SELECT ip.id AS internId, u.id AS userId FROM intern_profiles ip
     JOIN users u ON LOWER(u.email) = LOWER(ip.email) WHERE ip.id IN (?)`, [internIds]);
  return rows;
}
// Mốc lịch thực tập chưa hoàn thành bắt đầu trong [from, to] của thực tập sinh đang thực tập.
async function listMilestonesStartingBetween(from, to) {
  const [rows] = await requireDb().query(
    `SELECT s.id, s.intern_id AS internId, s.title, DATE_FORMAT(s.start_date,'%Y-%m-%d') AS startDate
     FROM intern_schedules s JOIN intern_profiles ip ON ip.id = s.intern_id
     WHERE s.status <> 'COMPLETED' AND s.start_date BETWEEN ? AND ? AND (ip.status IS NULL OR ip.status = ?)`,
    [from, to, DEFAULT_INTERN_STATUS]);
  return rows;
}
// Nhiệm vụ chưa xong đến hạn trong [from, to] của thực tập sinh đang thực tập.
async function listTasksDueBetween(from, to) {
  const [rows] = await requireDb().query(
    `SELECT t.id, t.intern_id AS internId, t.title, DATE_FORMAT(t.due_date,'%Y-%m-%d') AS dueDate
     FROM intern_tasks t JOIN intern_profiles ip ON ip.id = t.intern_id
     WHERE t.status <> 'DONE' AND t.due_date BETWEEN ? AND ? AND (ip.status IS NULL OR ip.status = ?)`,
    [from, to, DEFAULT_INTERN_STATUS]);
  return rows;
}
async function listNotifications(userId, limit = 30) {
  const [rows] = await requireDb().query(
    `SELECT id, type, title, message, target_tab AS targetTab, ref_id AS refId, is_read AS isRead,
            DATE_FORMAT(created_at,'%Y-%m-%d %H:%i:%s') AS createdAt
     FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT ?`, [userId, limit]);
  return rows.map((r) => ({ ...r, isRead: !!r.isRead }));
}
async function countUnreadNotifications(userId) {
  const [rows] = await requireDb().query("SELECT COUNT(*) AS c FROM notifications WHERE user_id = ? AND is_read = 0", [userId]);
  return Number(rows[0].c);
}
async function markNotificationRead(id, userId) {
  const [r] = await requireDb().query("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?", [id, userId]);
  return r.affectedRows;
}
async function markAllNotificationsRead(userId) {
  const [r] = await requireDb().query("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0", [userId]);
  return r.affectedRows;
}
async function findLeave(id) {
  const [rows] = await requireDb().query(`SELECT ${LEAVE_COLUMNS}, ip.mentor_id AS mentorId
    FROM leave_requests l JOIN intern_profiles ip ON ip.id = l.intern_id WHERE l.id = ?`, [id]);
  return rows[0] || null;
}
// today: ngày hiện tại theo giờ Việt Nam (YYYY-MM-DD), truyền từ service để không phụ thuộc múi giờ MySQL.
async function cancelLeave(id, internId, today) {
  const [result] = await requireDb().query(`UPDATE leave_requests SET status='CANCELLED'
    WHERE id=? AND intern_id=? AND (status='PENDING' OR (status='APPROVED' AND from_date > ?))`, [id, internId, today]);
  return result.affectedRows;
}
async function reviewLeave(id, decision, userId, note) {
  const [result] = await requireDb().query(`UPDATE leave_requests SET status=?, reviewed_by=?, reviewed_at=NOW(), review_note=?
    WHERE id=? AND status='PENDING'`, [decision, userId, note || null, id]);
  return result.affectedRows;
}

const SUPPORT_SELECT = `sr.id, sr.intern_id AS internId, sr.request_type AS requestType, sr.title, sr.description, sr.status,
  sr.handled_by AS handledBy, sr.resolution_note AS resolutionNote, sr.resolved_at AS resolvedAt,
  sr.created_at AS createdAt, sr.updated_at AS updatedAt, u.name AS handledByName`;
function buildSupportRequestWhere(internId, filters) {
  const where = [internId ? "sr.intern_id = ?" : "1=1"];
  const params = internId ? [internId] : [];
  if (filters.status) { where.push("sr.status = ?"); params.push(filters.status); }
  if (filters.type) { where.push("sr.request_type = ?"); params.push(filters.type); }
  if (filters.q) { where.push("(ip.full_name LIKE ? OR ip.student_code LIKE ? OR sr.title LIKE ?)"); params.push(...Array(3).fill(`%${String(filters.q).replace(/[\\%_]/g, "\\$&")}%`)); }
  return { where, params };
}
async function listSupportRequests(internId, filters = {}, pagination = null) {
  const { where, params } = buildSupportRequestWhere(internId, filters);
  const joins = "FROM support_requests sr JOIN intern_profiles ip ON ip.id=sr.intern_id LEFT JOIN users u ON u.id=sr.handled_by";
  const order = "ORDER BY FIELD(sr.status, 'PENDING', 'IN_PROGRESS', 'RESOLVED', 'REJECTED', 'CANCELLED'), sr.created_at DESC, sr.id DESC";
  if (pagination) {
    const [countRows] = await requireDb().query(`SELECT COUNT(*) AS total ${joins} WHERE ${where.join(" AND ")}`, params);
    const [rows] = await requireDb().query(`SELECT ${SUPPORT_SELECT}, ip.full_name AS fullName, ip.student_code AS studentCode, ip.university ${joins} WHERE ${where.join(" AND ")} ${order} LIMIT ? OFFSET ?`, [...params, pagination.pageSize, (pagination.page - 1) * pagination.pageSize]);
    return { items: rows, total: Number(countRows[0].total) };
  }
  const [rows] = await requireDb().query(`SELECT ${SUPPORT_SELECT}, ip.full_name AS fullName, ip.student_code AS studentCode, ip.university ${joins} WHERE ${where.join(" AND ")} ${order}`, params);
  return rows;
}
async function supportSummary(internId) {
  const [rows] = await requireDb().query(`SELECT COUNT(*) total, SUM(status='PENDING') pending, SUM(status='IN_PROGRESS') inProgress,
    SUM(status='RESOLVED') resolved, SUM(status='REJECTED') rejected, SUM(status='CANCELLED') cancelled
    FROM support_requests ${internId ? "WHERE intern_id=?" : ""}`, internId ? [internId] : []);
  return Object.fromEntries(Object.entries(rows[0]).map(([k,v])=>[k, Number(v || 0)]));
}
async function createSupportRequest({ internId, requestType, title, description }) {
  return withTransaction(async (conn) => {
    await conn.query("SELECT id FROM intern_profiles WHERE id=? FOR UPDATE", [internId]);
    const [rows] = await conn.query("SELECT request_type,COUNT(*) n FROM support_requests WHERE intern_id=? AND status IN ('PENDING','IN_PROGRESS') GROUP BY request_type", [internId]);
    if (rows.reduce((n,r)=>n+Number(r.n),0) >= 10) return { outcome:"LIMIT" };
    if (rows.some(r=>r.request_type===requestType)) return { outcome:"DUPLICATE" };
    const [result] = await conn.query("INSERT INTO support_requests (intern_id,request_type,title,description) VALUES (?,?,?,?)", [internId,requestType,title,description]);
    return { outcome:"CREATED", id:result.insertId };
  });
}
async function findSupportRequest(id, internId) {
  const [rows] = await requireDb().query(`SELECT ${SUPPORT_SELECT}, ip.full_name AS fullName, ip.student_code AS studentCode, ip.university FROM support_requests sr JOIN intern_profiles ip ON ip.id=sr.intern_id LEFT JOIN users u ON u.id=sr.handled_by WHERE sr.id=? ${internId ? "AND sr.intern_id=?" : ""}`, internId ? [id,internId] : [id]);
  return rows[0] || null;
}
async function processSupportRequest(id, allowed, status, userId, note) {
  const [result] = await requireDb().query(`UPDATE support_requests SET status=?,handled_by=?,resolution_note=COALESCE(?,resolution_note),resolved_at=IF(? IN ('RESOLVED','REJECTED'),NOW(),resolved_at) WHERE id=? AND status IN (${allowed.map(()=>"?").join(",")})`, [status,userId,note||null,status,id,...allowed]);
  return result.affectedRows;
}
async function cancelSupportRequest(id, internId) {
  const [result]=await requireDb().query("UPDATE support_requests SET status='CANCELLED' WHERE id=? AND intern_id=? AND status='PENDING'",[id,internId]); return result.affectedRows;
}
async function insertSupportAttachment(row) {
  // Chỉ chèn khi yêu cầu còn đúng trạng thái (atomic, tránh lệch với START/RESOLVE của HR); trả 0 nếu không còn phù hợp.
  const [result] = await requireDb().query(
    `INSERT INTO support_request_attachments (request_id,kind,original_name,stored_name,mime_type,size_bytes,uploaded_by)
     SELECT id,?,?,?,?,?,? FROM support_requests WHERE id=? AND status=?`,
    [row.kind,row.originalName,row.storedName,row.mimeType,row.sizeBytes,row.uploadedBy,row.requestId,row.requiredStatus]);
  return result.affectedRows ? result.insertId : 0;
}
async function listSupportAttachments(requestId) {
  const [rows]=await requireDb().query("SELECT id,request_id AS requestId,kind,original_name AS originalName,stored_name AS storedName,mime_type AS mimeType,size_bytes AS sizeBytes FROM support_request_attachments WHERE request_id=? ORDER BY id",[requestId]); return rows;
}
async function listSupportAttachmentsByRequestIds(ids) {
  if (!ids.length) return [];
  const [rows]=await requireDb().query(`SELECT id,request_id AS requestId,kind,original_name AS originalName,stored_name AS storedName,mime_type AS mimeType,size_bytes AS sizeBytes FROM support_request_attachments WHERE request_id IN (${ids.map(()=>"?").join(",")}) ORDER BY id`,ids);
  return rows;
}
async function findSupportAttachment(id, requestId) {
  const [rows]=await requireDb().query("SELECT id,request_id AS requestId,kind,original_name AS originalName,stored_name AS storedName,mime_type AS mimeType,size_bytes AS sizeBytes FROM support_request_attachments WHERE id=? AND request_id=?",[id,requestId]); return rows[0]||null;
}
async function countSupportAttachments(requestId,kind) { const [r]=await requireDb().query("SELECT COUNT(*) n FROM support_request_attachments WHERE request_id=? AND kind=?",[requestId,kind]); return Number(r[0].n); }
async function deleteSupportAttachment(id, requestId, kind) { const [r]=await requireDb().query("DELETE FROM support_request_attachments WHERE id=? AND request_id=? AND kind=?",[id,requestId,kind]); return r.affectedRows; }

// US6: read-only membership rows. No GROUP BY: compatible with ONLY_FULL_GROUP_BY.
// program_interns is unique on (program_id, intern_id); service deduplicates overall totals.
async function getCompletionRateRows(filters = {}) {
  const conditions = [], params = [];
  if (filters.programId) { conditions.push("pi.program_id = ?"); params.push(filters.programId); }
  if (filters.status) {
    const statusCodes = { "Đang thực tập":"IN_PROGRESS", "Hoàn thành":"COMPLETED", "Tạm dừng":"PAUSED", "Không hoàn thành":"NOT_COMPLETED" };
    conditions.push("pi.completion_status = ?"); params.push(statusCodes[filters.status]);
  }
  if (filters.programStatus) { conditions.push("p.status = ?"); params.push(filters.programStatus); }
  // Period intersection, inclusive; unknown dates cannot establish intersection.
  if (filters.from) { conditions.push("p.end_date >= ?"); params.push(filters.from); }
  if (filters.to) { conditions.push("p.start_date <= ?"); params.push(filters.to); }
  const mentorName = "CASE WHEN pi.completion_status IN ('COMPLETED','NOT_COMPLETED') THEN pi.result_mentor_name ELSE COALESCE(m.full_name COLLATE utf8mb4_unicode_ci,i.mentor_name COLLATE utf8mb4_unicode_ci) END";
  if (filters.q) {
    const escaped = String(filters.q).replace(/([%_\\])/g, "\\$1");
    const columns = ["i.full_name","i.student_code","i.university",mentorName,"p.name"];
    conditions.push(`(${columns.map(column => `${column} LIKE ? ESCAPE '\\\\'`).join(" OR ")})`);
    params.push(...columns.map(() => `%${escaped}%`));
  }
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  const [rows] = await requireDb().query(`SELECT pi.id,i.id AS internId,i.full_name AS fullName,i.student_code AS studentCode,
    i.university,CASE pi.completion_status WHEN 'COMPLETED' THEN 'Hoàn thành' WHEN 'PAUSED' THEN 'Tạm dừng'
      WHEN 'NOT_COMPLETED' THEN 'Không hoàn thành' ELSE 'Đang thực tập' END AS status,
    i.status AS profileStatus,pi.completion_status AS completionStatus,pi.completed_at AS completedAt,
    pi.completed_by AS completedBy,pi.completion_note AS completionNote,pi.result_updated_at AS resultUpdatedAt,
    CASE WHEN pi.completion_status IN ('COMPLETED','NOT_COMPLETED') THEN pi.result_mentor_id ELSE i.mentor_id END AS mentorId,
    ${mentorName} AS mentorName,pi.program_id AS programId,p.name AS programName,p.status AS programStatus,
    p.start_date AS programStart,p.end_date AS programEnd
    FROM intern_profiles i LEFT JOIN mentors m ON m.id=i.mentor_id
    JOIN program_interns pi ON pi.intern_id=i.id JOIN internship_programs p ON p.id=pi.program_id
    ${where} ORDER BY pi.id`,params);
  return rows;
}
async function getCompletionRatePrograms() {
  const [rows] = await requireDb().query("SELECT id, name FROM internship_programs ORDER BY name, id");
  return rows;
}

module.exports = {
  setProgramCompletion,
  getCompletionRateRows,
  getCompletionRatePrograms,
  initDatabase,
  getPool,
  seedDepartmentsFromMentors,
  backfillInternMentorIds,
  closePool,
  findUserByEmail,
  findUserForLogin,
  insertUser,
  getAllUsers,
  deleteUser,
  insertCandidate,
  listApplications,
  findApplicationById,
  findApplicationsByEmails,
  reviewApplicationAtomic,
  getAllMentors,
  insertMentor,
  updateMentor,
  deleteMentor,
  getAllStudents,
  getStudentsForMentorEmail,
  listMentorInterns,
  listInternsNotOfMentor,
  listProgramDepartmentsForInterns,
  assignMentorToInterns,
  getInternFilterOptions,
  countInterns,
  assignInternMentor,
  insertStudent,
  updateStudent,
  deleteStudent,
  insertEmailLog,
  updateEmailLog,
  findEmailLogById,
  listPendingOrRetryingEmailLogs,
  listEmailLogs,
  findApplicationByUserIdOrEmail,
  findDocumentsByApplicationId,
  findDocumentById,
  findDocumentsByApplicationIds,
  createCandidateProfileForUser,
  saveDocumentIfPending,
  deleteDocumentIfPending,
  findInternProfileById,
  findInternProfileByEmail,
  listContractsByInternId,
  insertContract,
  findContractById,
  deleteContract,
  updateContractFields,
  confirmContractAtomic,
  listDepartments,
  findDepartmentByName,
  findDepartmentById,
  insertDepartment,
  deleteDepartment,
  listPrograms,
  findProgramById,
  listProgramInterns,
  listInternsNotInProgram,
  addProgramInterns,
  removeProgramIntern,
  assignProgramInternsMentor,
  saveProgramAtomic,
  deleteProgram,
  findMentorById,
  findMentorByEmail,
  insertInternTask,
  findInternTaskById,
  listInternTasksForMentor,
  listInternTasksForIntern,
  updateInternTask,
  updateInternTaskProgress,
  deleteInternTask,
  listTaskAttachmentsByTaskIds,
  findTaskAttachmentById,
  insertTaskAttachmentLimited,
  deleteTaskAttachment,
  findInternContractPeriod,
  listInternsWithPeriodForMentor,
  findWeeklyReportById,
  findWeeklyReportByWeek,
  upsertWeeklyReport,
  listWeeklyReportsForIntern,
  listWeeklyReportsForMentor,
  listWeeklyReportAttachmentsByReportIds,
  findWeeklyReportAttachmentById,
  insertWeeklyReportAttachmentLimited,
  deleteWeeklyReportAttachment,
  upsertWeeklyReportFeedback,
  deleteWeeklyReportFeedback,
  reapplyRejectedCandidate,
  hasConfirmedContract,
  countContractsOutsideProgramRange,
  getServerDateTime,
  findAttendanceByInternDate,
  findAttendanceById,
  findOpenAttendance,
  hasConfirmedContractOn,
  requestAttendanceCorrection,
  reviewAttendanceCorrection,
  listPendingAttendanceCorrections,
  insertAttendance,
  checkOutAttendance,
  listAttendance,
  listFinalReportInterns,
  getFinalReportFilterOptions,
  createFinalReport,
  listFinalReports,
  findFinalReportById,
  updateFinalReport,
  finalizeFinalReport,
  deleteFinalReport,
  recordFinalReportSend,
  listFinalReportSends,
  upsertFinalReportRecipients,
  listFinalReportRecipients,
  deleteFinalReportRecipient,
  findInternEvaluation,
  upsertInternEvaluation,
  listWorkSchedules,
  findWorkSchedule,
  saveWorkSchedule,
  deleteWorkSchedule,
  listWorkScheduleAssignments,
  createWorkScheduleAssignment,
  deleteWorkScheduleAssignment,
  workScheduleTargetExists,
  listWorkHolidays,
  addWorkHoliday,
  deleteWorkHoliday,
  loadWorkScheduleContext,
  listConfirmedContractsForInterns,
  listProgramMembershipsForInterns,
  listAttendanceForInterns,
  listLeaves,
  listLeavesForInterns,
  listLeavesForStaff,
  listPendingLeaves,
  createLeave,
  listActiveHrEmails,
  listActiveHrUserIds,
  findMentorUserId,
  createNotifications,
  findUserIdsByInternIds,
  listMilestonesStartingBetween,
  listTasksDueBetween,
  listNotifications,
  countUnreadNotifications,
  markNotificationRead,
  markAllNotificationsRead,
  findLeave,
  cancelLeave,
  reviewLeave,
  deleteInternEvaluation,
  listEvaluationsForMentor,
  listScheduleMilestones,
  insertScheduleMilestone,
  insertScheduleMilestonesAtomic,
  updateScheduleMilestone,
  deleteScheduleMilestone,
  findMilestoneById,
  getOverviewStats,
  listAllowancesByIntern,
  findAllowanceById,
  saveAllowanceAtomic,
  deleteAllowance,
  listAllowanceOverview,
  listSupportRequests, supportSummary, createSupportRequest, findSupportRequest, processSupportRequest,
  cancelSupportRequest, insertSupportAttachment, listSupportAttachments, listSupportAttachmentsByRequestIds, findSupportAttachment,
  countSupportAttachments, deleteSupportAttachment,
  getInternOriginCounts,
  getCandidateFunnelByUniversity,
  listInternsByOrigin,
};

